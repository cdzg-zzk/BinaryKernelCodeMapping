#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x367fcc51, "module_layout" },
	{ 0x3dd73347, "param_ops_bool" },
	{ 0x49a5d567, "param_ops_uint" },
	{ 0x62ae48af, "single_release" },
	{ 0xc4bcd79c, "seq_read" },
	{ 0xd823f987, "seq_lseek" },
	{ 0x87fba148, "debugfs_create_file" },
	{ 0x5f915748, "debugfs_create_dir" },
	{ 0x449ad0a7, "memcmp" },
	{ 0x599fb41c, "kvmalloc_node" },
	{ 0x922bcbf3, "matched_bch_init" },
	{ 0xded5a28f, "matched_bch_free" },
	{ 0xcb50e445, "matched_bch_encode" },
	{ 0x2cb73fc1, "matched_bch_decode" },
	{ 0x7661efcc, "vkso_bch_init" },
	{ 0xef89e59a, "vkso_bch_free" },
	{ 0xa0238232, "vkso_bch_encode" },
	{ 0xda11ea29, "vkso_bch_decode" },
	{ 0x1a267fa8, "bch_init" },
	{ 0xd3e3481, "bch_free" },
	{ 0xc303f52, "bch_encode" },
	{ 0x860a2eab, "bch_decode" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0x92997ed8, "_printk" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x800473f, "__cond_resched" },
	{ 0xb43f9365, "ktime_get" },
	{ 0x31549b2a, "__x86_indirect_thunk_r10" },
	{ 0x54b1fac6, "__ubsan_handle_load_invalid_value" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x7aa1756e, "kvfree" },
	{ 0xed02e030, "debugfs_remove" },
	{ 0x37a0cba, "kfree" },
	{ 0xb20dd93f, "seq_printf" },
	{ 0x5fa7d506, "seq_puts" },
	{ 0xc22aaf3c, "single_open" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x87a21cb3, "__ubsan_handle_out_of_bounds" },
	{ 0x7a2af7b4, "cpu_number" },
	{ 0x85b33882, "current_task" },
	{ 0x8810754a, "_find_first_bit" },
	{ 0x63c4d61f, "__bitmap_weight" },
	{ 0x17de3d5, "nr_cpu_ids" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xbdfb6dbb, "__fentry__" },
};

MODULE_INFO(depends, "bch_matched,vkso_bch,bch");


MODULE_INFO(srcversion, "2BF5D7F9A01C326F060E4C7");
