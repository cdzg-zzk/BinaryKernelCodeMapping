/home/zzk/BinaryKernelCodeMapping/test/evaluation/results/bch-heap-qemu-20260912-attempt01/build-source/kmod/bch_impl.o /home/zzk/BinaryKernelCodeMapping/test/evaluation/results/bch-heap-qemu-20260912-attempt01/build-source/kmod/module_meta.o

