#!/bin/bash
set -eu
cd /work/package
export LD_LIBRARY_PATH=/work/package
export PATH=/work/package/bin:$PATH
exec python3 -u maintenance_guest.py
