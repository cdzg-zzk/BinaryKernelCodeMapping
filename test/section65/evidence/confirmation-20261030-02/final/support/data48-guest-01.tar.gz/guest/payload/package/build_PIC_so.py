#!/usr/bin/env python3
"""
Sparse ELF64 shared-object builder for kernel code mapping.
"""

from __future__ import annotations

import argparse
import json
import sys
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Sequence, Set, Tuple

# -----------------------------------------------------------------------------
# ELF constants
# -----------------------------------------------------------------------------

EI_NIDENT = 16
ELFCLASS64 = 2
ELFDATA2LSB = 1
EV_CURRENT = 1

ET_REL = 1
ET_EXEC = 2
ET_DYN = 3
EM_X86_64 = 62

PT_LOAD = 1
PT_DYNAMIC = 2

PF_X = 1
PF_W = 2
PF_R = 4

SHT_NULL = 0
SHT_PROGBITS = 1
SHT_SYMTAB = 2
SHT_STRTAB = 3
SHT_RELA = 4
SHT_DYNAMIC = 6
SHT_NOBITS = 8
SHT_DYNSYM = 11
SHT_GNU_HASH = 0x6FFFFFF6

SHF_WRITE = 0x1
SHF_ALLOC = 0x2
SHF_EXECINSTR = 0x4

SHN_UNDEF = 0
SHN_ABS = 0xFFF1

STB_GLOBAL = 1
STT_NOTYPE = 0
STT_OBJECT = 1
STT_FUNC = 2

R_X86_64_64 = 1
R_X86_64_PC32 = 2
R_X86_64_PLT32 = 4
R_X86_64_RELATIVE = 8

DT_NULL = 0
DT_NEEDED = 1
DT_STRTAB = 5
DT_SYMTAB = 6
DT_RELA = 7
DT_RELASZ = 8
DT_RELAENT = 9
DT_STRSZ = 10
DT_SYMENT = 11
DT_GNU_HASH = 0x6FFFFEF5

# -----------------------------------------------------------------------------
# Layout configuration
# -----------------------------------------------------------------------------

PAGE_SIZE = 0x1000
TEXT_BASE_VADDR = 0x1000
TEXT_BASE_OFFSET = 0x1000
DEFAULT_EXPORT_STUB_SIZE = 0x10

LIB_SHIM = "libshim.so"
BUILTIN_THUNK_MODULE = "builtin_thunk"

INDIRECT_THUNK_PREFIX = "__x86_indirect_thunk_"
INDIRECT_THUNK_ARRAY = "__x86_indirect_thunk_array"
RETURN_THUNK_PREFIX = "__x86_return_thunk"

# The outer kernel call already pushed the real return address, so these
# built-in user-space thunks tail-jump to the register target.  RSP is omitted:
# entering a thunk with CALL has already changed RSP, so it cannot use the same
# two-byte implementation as the other general-purpose registers.
DIRECT_THUNK_ENCODINGS: Dict[str, bytes] = {
    "rax": b"\xff\xe0",
    "rcx": b"\xff\xe1",
    "rdx": b"\xff\xe2",
    "rbx": b"\xff\xe3",
    "rbp": b"\xff\xe5",
    "rsi": b"\xff\xe6",
    "rdi": b"\xff\xe7",
    "r8": b"\x41\xff\xe0",
    "r9": b"\x41\xff\xe1",
    "r10": b"\x41\xff\xe2",
    "r11": b"\x41\xff\xe3",
    "r12": b"\x41\xff\xe4",
    "r13": b"\x41\xff\xe5",
    "r14": b"\x41\xff\xe6",
    "r15": b"\x41\xff\xe7",
}

# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

def align(value: int, alignment: int) -> int:
    if alignment == 0:
        return value
    return (value + alignment - 1) & ~(alignment - 1)

def align_down(value: int, alignment: int) -> int:
    if alignment == 0:
        return value
    return value & ~(alignment - 1)

def parse_symbol_requests(path: Path) -> List[str]:
    names: List[str] = []
    seen: Set[str] = set()
    for raw in path.read_text().splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        token = line.split()[0]
        if not token or token in seen:
            continue
        seen.add(token)
        names.append(token)
    return names

def load_shim_symbols(path: Path | None) -> Set[str]:
    if path is None or not path.exists():
        return set()
    return set(parse_symbol_requests(path))

def load_shared_data_symbols(path: Path | None) -> Set[str]:
    """Load the explicit allow-list of writable kernel pages safe to share RO."""
    if path is None or not path.exists():
        return set()
    return set(parse_symbol_requests(path))

def load_reusable_text_symbols(path: Path | None) -> Set[str]:
    """Load native executable dependency roots that must remain reusable."""
    if path is None:
        return set()
    if not path.is_file():
        raise ValueError(f"{path}: reusable_text list does not exist")
    names = set(parse_symbol_requests(path))
    if not names:
        raise ValueError(f"{path}: reusable_text list is empty")
    return names

def indirect_thunk_register(name: str) -> str | None:
    if name == INDIRECT_THUNK_ARRAY:
        return "rax"
    if not name.startswith(INDIRECT_THUNK_PREFIX):
        return None
    register = name[len(INDIRECT_THUNK_PREFIX):]
    return register if register in DIRECT_THUNK_ENCODINGS else None

def split_builtin_thunk_shims(shim_symbols: Set[str]) -> tuple[Set[str], Set[str]]:
    builtin = {
        name for name in shim_symbols
        if indirect_thunk_register(name) is not None
    }
    return shim_symbols - builtin, builtin

def gnu_hash(name: str) -> int:
    h = 5381
    for ch in name:
        h = ((h * 33) + ord(ch)) & 0xFFFFFFFF
    return h

# -----------------------------------------------------------------------------
# KrgGraph loader
# -----------------------------------------------------------------------------

@dataclass(frozen=True)
class KrgResolvedSymbol:
    name: str
    address: int
    size: int
    kind: int
    module_id: int = 0
    module_name: str = "kernel"

class KrgGraph:
    _HEADER_V1 = struct.Struct("<8I")
    _HEADER_V2 = struct.Struct("<10I")
    _NODE_V1 = struct.Struct("<QIB3x")
    _NODE_V2 = struct.Struct("<QIHBx")

    def __init__(self, path: Path) -> None:
        data = path.read_bytes()
        self.path = path
        self.nodes: List[KrgResolvedSymbol] = []
        self.name_to_id: Dict[str, int] = {}
        self.node_count = 0
        self.row_ptr: List[int] = []
        self.col_idx: List[int] = []
        self.modules: List[str] = ["kernel"]
        self._load(memoryview(data))

    def _load(self, blob: memoryview) -> None:
        cursor = 0
        if len(blob) < self._HEADER_V1.size:
            raise ValueError(f"{self.path}: file too small for header")
        (
            magic, version, n_nodes, n_edges, name_blob_bytes,
            _arch, _is_runtime, _reserved,
        ) = self._HEADER_V1.unpack_from(blob, cursor)
        header_version = version
        n_modules = 1
        module_blob_bytes = 0
        if header_version >= 2:
            if len(blob) < self._HEADER_V2.size:
                raise ValueError(f"{self.path}: file too small for v2 header")
            (
                magic, version, n_nodes, n_edges, name_blob_bytes,
                _arch, _is_runtime, _reserved, n_modules, module_blob_bytes,
            ) = self._HEADER_V2.unpack_from(blob, 0)
            cursor = self._HEADER_V2.size
        else:
            cursor += self._HEADER_V1.size
        if magic != 0x3147524B or header_version not in (1, 2):
            raise ValueError(f"{self.path}: unsupported krg header")

        node_addresses: List[int] = []
        node_sizes: List[int] = []
        node_kinds: List[int] = []
        node_modules: List[int] = []
        node_struct = self._NODE_V2 if header_version >= 2 else self._NODE_V1
        self.node_count = n_nodes
        for _ in range(n_nodes):
            if cursor + node_struct.size > len(blob):
                raise ValueError(f"{self.path}: truncated node table")
            if header_version >= 2:
                addr, size, module_id, kind = node_struct.unpack_from(blob, cursor)
            else:
                addr, size, kind = node_struct.unpack_from(blob, cursor)
                module_id = 0
            cursor += node_struct.size
            node_addresses.append(addr)
            node_sizes.append(size)
            node_kinds.append(kind)
            node_modules.append(module_id)

        row_entries = n_nodes + 1
        row_ptr_size = row_entries * 4
        if cursor + row_ptr_size > len(blob):
            raise ValueError(f"{self.path}: truncated row_ptr table")
        if row_entries:
            self.row_ptr = list(struct.unpack_from(f"<{row_entries}I", blob, cursor))
        else:
            self.row_ptr = []
        cursor += row_ptr_size

        col_idx_size = n_edges * 4
        if cursor + col_idx_size > len(blob):
            raise ValueError(f"{self.path}: truncated col_idx table")
        if n_edges:
            self.col_idx = list(struct.unpack_from(f"<{n_edges}I", blob, cursor))
        else:
            self.col_idx = []
        cursor += col_idx_size

        name_off_size = n_nodes * 4
        if cursor + name_off_size > len(blob):
            raise ValueError(f"{self.path}: truncated name offsets")
        name_offsets = list(struct.unpack_from(f"<{n_nodes}I", blob, cursor))
        cursor += name_off_size

        if cursor + name_blob_bytes > len(blob):
            raise ValueError(f"{self.path}: truncated name blob")
        name_blob = bytes(blob[cursor : cursor + name_blob_bytes])
        cursor += name_blob_bytes

        modules: List[str] = ["kernel"]
        if header_version >= 2:
            module_offsets: List[int] = []
            if cursor + (n_modules * 4) > len(blob):
                raise ValueError(f"{self.path}: truncated module offsets")
            module_offsets = list(struct.unpack_from(f"<{n_modules}I", blob, cursor))
            cursor += n_modules * 4
            if cursor + module_blob_bytes > len(blob):
                raise ValueError(f"{self.path}: truncated module blob")
            module_blob = bytes(blob[cursor : cursor + module_blob_bytes])
            modules = []
            for off in module_offsets:
                if off >= len(module_blob):
                    raise ValueError(f"{self.path}: invalid module offset {off}")
                end = module_blob.find(b"\x00", off)
                if end == -1:
                    raise ValueError(f"{self.path}: unterminated module string at {off}")
                modules.append(module_blob[off:end].decode("utf-8", errors="ignore"))
        if not modules:
            modules = ["kernel"]
        self.modules = modules

        for idx, off in enumerate(name_offsets):
            if off >= len(name_blob):
                raise ValueError(f"{self.path}: invalid name offset {off}")
            end = name_blob.find(b"\x00", off)
            if end == -1:
                raise ValueError(f"{self.path}: unterminated string at offset {off}")
            name = name_blob[off:end].decode("utf-8", errors="ignore")
            module_name = "kernel"
            if node_modules[idx] < len(modules):
                module_name = modules[node_modules[idx]]
            self.nodes.append(
                KrgResolvedSymbol(
                    name=name, address=node_addresses[idx], size=node_sizes[idx],
                    kind=node_kinds[idx], module_id=node_modules[idx], module_name=module_name,
                )
            )
            self.name_to_id[name] = idx

    def closure(self, symbol_name: str, stop_names: Set[str] | None = None) -> List[KrgResolvedSymbol]:
        try:
            root = self.name_to_id[symbol_name]
        except KeyError as exc:
            raise KeyError(f"{symbol_name}: symbol not found in {self.path}") from exc
        seen = [0] * self.node_count
        stack = [root]
        seen[root] = 1
        while stack:
            node = stack.pop()
            if stop_names and self.nodes[node].name in stop_names:
                continue
            row_start = self.row_ptr[node]
            row_end = self.row_ptr[node + 1]
            for edge_idx in range(row_start, row_end):
                target = self.col_idx[edge_idx]
                if not seen[target]:
                    seen[target] = 1
                    stack.append(target)
        return [self.nodes[idx] for idx, flag in enumerate(seen) if flag]

    def lookup(self, symbol_name: str) -> KrgResolvedSymbol | None:
        idx = self.name_to_id.get(symbol_name)
        if idx is None:
            return None
        return self.nodes[idx]

# -----------------------------------------------------------------------------
# ELF64 relocatable (.ko) reader (pseudo-GOT extraction)
# -----------------------------------------------------------------------------

@dataclass(frozen=True)
class KoSection:
    index: int
    name: str
    sh_type: int
    sh_flags: int
    sh_offset: int
    sh_size: int
    sh_link: int
    sh_info: int
    sh_addralign: int
    sh_entsize: int

    @property
    def is_alloc(self) -> bool:
        return bool(self.sh_flags & SHF_ALLOC)

    @property
    def is_write(self) -> bool:
        return bool(self.sh_flags & SHF_WRITE)

    @property
    def is_exec(self) -> bool:
        return bool(self.sh_flags & SHF_EXECINSTR)

@dataclass(frozen=True)
class KoSymbol:
    name: str
    st_info: int
    st_other: int
    st_shndx: int
    st_value: int
    st_size: int

    @property
    def bind(self) -> int:
        return self.st_info >> 4

    @property
    def typ(self) -> int:
        return self.st_info & 0xF

    @property
    def is_undef(self) -> bool:
        return self.st_shndx == SHN_UNDEF

@dataclass(frozen=True)
class KoDataReloc:
    offset: int  
    sym_idx: int
    symbol_name: str
    sym_shndx: int
    sym_value: int
    addend: int
    r_type: int
    is_undef: bool

@dataclass(frozen=True)
class KoCoreLayout:
    section_offsets: Dict[int, int]
    text_start: int
    text_end: int
    ro_start: int
    ro_end: int
    data_start: int
    data_end: int
    ro_image: bytes
    data_image: bytes
    data_relocs: List[KoDataReloc]

    @property
    def text_size(self) -> int:
        return self.text_end - self.text_start

    @property
    def ro_size(self) -> int:
        return self.ro_end - self.ro_start

    @property
    def data_size(self) -> int:
        return self.data_end - self.data_start

def gnu_build_id_notes(data: bytes) -> List[str]:
    """Read GNU build IDs from little-endian ELF notes (four-byte alignment)."""
    ids: List[str] = []
    offset = 0
    while offset < len(data):
        if len(data) - offset < 12:
            if any(data[offset:]):
                raise ValueError("truncated ELF note header")
            break
        namesz, descsz, kind = struct.unpack_from("<III", data, offset)
        name_start = offset + 12
        desc_start = name_start + ((namesz + 3) & ~3)
        end = desc_start + ((descsz + 3) & ~3)
        if end > len(data):
            raise ValueError("truncated ELF note payload")
        if kind == 3 and data[name_start:name_start + namesz] == b"GNU\0":
            if not 1 <= descsz <= 64:
                raise ValueError("unsupported GNU build-id length")
            ids.append(data[desc_start:desc_start + descsz].hex())
        offset = end
    return ids


def elf_build_id(path: Path) -> str:
    """Extract the linker's identity without reading a whole debug vmlinux."""
    header = struct.Struct("<16sHHIQQQIHHHHHH")
    section = struct.Struct("<IIQQQQIIQQ")
    ids: List[str] = []
    with path.open("rb") as stream:
        file_size = path.stat().st_size
        raw = stream.read(header.size)
        if len(raw) != header.size:
            raise ValueError(f"{path}: truncated ELF header")
        fields = header.unpack(raw)
        ident, machine = fields[0], fields[2]
        shoff, shentsize, shnum = fields[6], fields[11], fields[12]
        if ident[:6] != b"\x7fELF\x02\x01" or machine != EM_X86_64:
            raise ValueError(f"{path}: expected little-endian x86-64 ELF")
        if shentsize != section.size or not shnum or shoff + shentsize * shnum > file_size:
            raise ValueError(f"{path}: invalid ELF section table")
        for index in range(shnum):
            stream.seek(shoff + index * shentsize)
            values = section.unpack(stream.read(section.size))
            if values[1] != 7: # SHT_NOTE
                continue
            offset, size = values[4], values[5]
            if offset + size > file_size:
                raise ValueError(f"{path}: truncated note section")
            stream.seek(offset)
            ids.extend(gnu_build_id_notes(stream.read(size)))
    if len(ids) != 1:
        raise ValueError(f"{path}: expected one GNU build-id, found {len(ids)}")
    return ids[0]


class KoFile:
    _EHDR = struct.Struct("<16sHHIQQQIHHHHHH")
    _SHDR = struct.Struct("<IIQQQQIIQQ")
    _SYMENT = struct.Struct("<IBBHQQ")
    _RELA = struct.Struct("<QQq")
    _NON_CORE_SECTION_PREFIXES = (
        ".modinfo",
        ".return_sites",
        ".retpoline_sites",
    )

    def __init__(self, path: Path) -> None:
        self.path = path
        self._blob = memoryview(path.read_bytes())
        self.sections: List[KoSection] = []
        self._sections_by_name: Dict[str, KoSection] = {}
        self.symbols: List[KoSymbol] = []
        self._sym_by_name: Dict[str, int] = {}
        self._load()

    def _load(self) -> None:
        blob = self._blob
        if len(blob) < self._EHDR.size:
            raise ValueError(f"{self.path}: file too small for ELF header")
        (e_ident, e_type, e_machine, _e_version, _e_entry, _e_phoff, e_shoff, _e_flags,
         _e_ehsize, _e_phentsize, _e_phnum, e_shentsize, e_shnum, e_shstrndx) = self._EHDR.unpack_from(blob, 0)
        if e_ident[0:4] != b"\x7fELF" or e_ident[4] != ELFCLASS64:
            raise ValueError(f"{self.path}: not an ELF64 file")
        if e_type != ET_REL:
            raise ValueError(f"{self.path}: expected ET_REL (.ko), got e_type={e_type}")
        if e_machine != EM_X86_64:
            raise ValueError(f"{self.path}: expected EM_X86_64, got e_machine={e_machine}")
        if e_shentsize != self._SHDR.size:
            raise ValueError(f"{self.path}: unexpected section header size {e_shentsize}")
        if e_shoff == 0 or e_shnum == 0:
            raise ValueError(f"{self.path}: missing section header table")

        raw_shdrs: List[tuple[int, int, int, int, int, int, int, int, int, int]] = []
        for idx in range(e_shnum):
            off = e_shoff + idx * e_shentsize
            if off + self._SHDR.size > len(blob):
                raise ValueError(f"{self.path}: truncated section header table")
            raw_shdrs.append(self._SHDR.unpack_from(blob, off))

        if e_shstrndx >= e_shnum:
            raise ValueError(f"{self.path}: invalid e_shstrndx {e_shstrndx}")
        shstr = raw_shdrs[e_shstrndx]
        shstr_off = shstr[4]
        shstr_size = shstr[5]
        if shstr_off + shstr_size > len(blob):
            raise ValueError(f"{self.path}: truncated shstrtab")
        shstr_blob = bytes(blob[shstr_off : shstr_off + shstr_size])

        self.sections.clear()
        self._sections_by_name.clear()
        for idx, sh in enumerate(raw_shdrs):
            sh_name, sh_type, _sh_flags, _sh_addr, sh_offset, sh_size, sh_link, sh_info, sh_addralign, sh_entsize = sh
            name = ""
            if sh_name < len(shstr_blob):
                end = shstr_blob.find(b"\x00", sh_name)
                if end != -1:
                    name = shstr_blob[sh_name:end].decode("utf-8", errors="ignore")
            sec = KoSection(
                index=idx, name=name, sh_type=sh_type, sh_flags=_sh_flags, sh_offset=sh_offset,
                sh_size=sh_size, sh_link=sh_link, sh_info=sh_info, sh_addralign=sh_addralign, sh_entsize=sh_entsize,
            )
            self.sections.append(sec)
            if name and name not in self._sections_by_name:
                self._sections_by_name[name] = sec

        symtab = self._sections_by_name.get(".symtab")
        if symtab is None or symtab.sh_entsize != self._SYMENT.size:
            raise ValueError(f"{self.path}: missing or unsupported .symtab")
        if symtab.sh_link >= len(self.sections):
            raise ValueError(f"{self.path}: invalid .symtab sh_link {symtab.sh_link}")
        strtab = self.sections[symtab.sh_link]
        if strtab.sh_offset + strtab.sh_size > len(blob):
            raise ValueError(f"{self.path}: truncated .strtab")
        str_blob = bytes(blob[strtab.sh_offset : strtab.sh_offset + strtab.sh_size])

        if symtab.sh_offset + symtab.sh_size > len(blob):
            raise ValueError(f"{self.path}: truncated .symtab")
        self.symbols.clear()
        self._sym_by_name.clear()
        for entry_off in range(symtab.sh_offset, symtab.sh_offset + symtab.sh_size, symtab.sh_entsize):
            st_name, st_info, st_other, st_shndx, st_value, st_size = self._SYMENT.unpack_from(
                blob, entry_off
            )
            name = ""
            if st_name < len(str_blob):
                end = str_blob.find(b"\x00", st_name)
                if end != -1:
                    name = str_blob[st_name:end].decode("utf-8", errors="ignore")
            sym = KoSymbol(
                name=name, st_info=st_info, st_other=st_other, st_shndx=st_shndx,
                st_value=st_value, st_size=st_size,
            )
            idx = len(self.symbols)
            self.symbols.append(sym)
            if name and name not in self._sym_by_name:
                self._sym_by_name[name] = idx

    def find_symbol(self, name: str) -> tuple[int, KoSymbol] | None:
        idx = self._sym_by_name.get(name)
        if idx is None:
            return None
        return idx, self.symbols[idx]

    def find_section(self, name: str) -> KoSection | None:
        return self._sections_by_name.get(name)

    def section_bytes(self, section: KoSection) -> bytes:
        if section.sh_type == SHT_NOBITS:
            return bytes(section.sh_size)
        end = section.sh_offset + section.sh_size
        if end > len(self._blob):
            raise ValueError(f"{self.path}: truncated section {section.name}")
        return bytes(self._blob[section.sh_offset:end])

    def relocations_for(self, target: KoSection) -> List[KoDataReloc]:
        relocations: List[KoDataReloc] = []
        for section in self.sections:
            if section.sh_type != SHT_RELA or section.sh_info != target.index:
                continue
            if section.sh_entsize != self._RELA.size:
                raise ValueError(
                    f"{self.path}: unsupported relocation entry size "
                    f"{section.sh_entsize} for {section.name}"
                )
            end = section.sh_offset + section.sh_size
            if end > len(self._blob):
                raise ValueError(
                    f"{self.path}: truncated relocation section {section.name}"
                )
            for offset in range(section.sh_offset, end, section.sh_entsize):
                r_offset, r_info, addend = self._RELA.unpack_from(
                    self._blob, offset
                )
                sym_idx = r_info >> 32
                r_type = r_info & 0xFFFFFFFF
                if sym_idx >= len(self.symbols):
                    raise ValueError(
                        f"{self.path}: relocation references invalid symbol "
                        f"index {sym_idx}"
                    )
                symbol = self.symbols[sym_idx]
                relocations.append(
                    KoDataReloc(
                        offset=r_offset,
                        sym_idx=sym_idx,
                        symbol_name=symbol.name,
                        sym_shndx=symbol.st_shndx,
                        sym_value=symbol.st_value,
                        addend=addend,
                        r_type=r_type,
                        is_undef=symbol.is_undef,
                    )
                )
        return relocations

    @staticmethod
    def _is_core_section(name: str) -> bool:
        if not name:
            return False
        if name.startswith(".init") or name.startswith(".exit"):
            return False
        for prefix in KoFile._NON_CORE_SECTION_PREFIXES:
            if name == prefix or name.startswith(prefix + "."):
                return False
        return True

    def compute_core_layout(self) -> KoCoreLayout:
        core_alloc = [s for s in self.sections if s.is_alloc and self._is_core_section(s.name)]
        text_secs = [s for s in core_alloc if s.is_exec]
        ro_secs = [s for s in core_alloc if (not s.is_exec) and (not s.is_write)]
        data_secs = [s for s in core_alloc if s.is_write]

        section_offsets: Dict[int, int] = {}
        cursor = 0
        text_start = cursor
        for sec in text_secs:
            cursor = align(cursor, max(1, sec.sh_addralign))
            section_offsets[sec.index] = cursor
            cursor += sec.sh_size
        cursor = align(cursor, PAGE_SIZE)
        text_end = cursor

        ro_start = cursor
        for sec in ro_secs:
            cursor = align(cursor, max(1, sec.sh_addralign))
            section_offsets[sec.index] = cursor
            cursor += sec.sh_size
        cursor = align(cursor, PAGE_SIZE)
        ro_end = cursor

        data_start = cursor
        # Linux 5.15 puts these writable ELF sections in a separate, page-ended
        # ro-after-init group before ordinary writable sections (module.c,
        # layout_sections). Keep them private here, but preserve that spacing:
        # shared RIP-relative accesses must reach the native .data/.bss offsets.
        ro_after_init = [s for s in data_secs if s.sh_flags & 0x00200000 or
                         s.name in (".data..ro_after_init", "__jump_table")]
        ordinary_data = [s for s in data_secs if s not in ro_after_init]
        for group in (ro_after_init, ordinary_data):
            for sec in group:
                cursor = align(cursor, max(1, sec.sh_addralign))
                section_offsets[sec.index] = cursor
                cursor += sec.sh_size
            cursor = align(cursor, PAGE_SIZE)
        cursor = align(cursor, PAGE_SIZE)
        data_end = cursor

        ro_size = ro_end - ro_start
        ro_image = bytearray(ro_size)
        for sec in ro_secs:
            if sec.sh_size == 0:
                continue
            dest_off = section_offsets[sec.index] - ro_start
            if sec.sh_type == SHT_NOBITS:
                continue
            end = sec.sh_offset + sec.sh_size
            if end > len(self._blob):
                raise ValueError(f"{self.path}: truncated section {sec.name}")
            ro_image[dest_off : dest_off + sec.sh_size] = bytes(
                self._blob[sec.sh_offset : end]
            )

        data_size = data_end - data_start
        data_image = bytearray(data_size)
        for sec in data_secs:
            # Keep kernel layout offsets while omitting management pointers.
            if sec.sh_size == 0 or sec.name == ".vkso_owner":
                continue
            dest_off = section_offsets[sec.index] - data_start
            if sec.sh_type == SHT_NOBITS:
                continue
            end = sec.sh_offset + sec.sh_size
            if end > len(self._blob):
                raise ValueError(f"{self.path}: truncated section {sec.name}")
            data_image[dest_off : dest_off + sec.sh_size] = bytes(
                self._blob[sec.sh_offset : end]
            )

        data_sec_indices = {sec.index for sec in data_secs if sec.name != ".vkso_owner"}
        data_relocs: List[KoDataReloc] = []
        for sec in self.sections:
            if sec.sh_type != SHT_RELA or not sec.name.startswith(".rela."):
                continue
            if sec.sh_info not in data_sec_indices:
                continue
            if sec.sh_entsize != self._RELA.size:
                raise ValueError(f"{self.path}: unexpected rela entsize in {sec.name}")
            target_base = section_offsets.get(sec.sh_info)
            if target_base is None:
                continue
            base_off = target_base - data_start
            end = sec.sh_offset + sec.sh_size
            if end > len(self._blob):
                raise ValueError(f"{self.path}: truncated relocation section {sec.name}")
            for entry_off in range(sec.sh_offset, end, sec.sh_entsize):
                r_offset, r_info, r_addend = self._RELA.unpack_from(self._blob, entry_off)
                sym_idx = (r_info >> 32) & 0xFFFFFFFF
                r_type = r_info & 0xFFFFFFFF
                sym_name = ""
                is_undef = False
                sym_shndx = 0
                sym_value = 0
                if sym_idx < len(self.symbols):
                    sym = self.symbols[sym_idx]
                    sym_name = sym.name
                    is_undef = sym.is_undef
                    sym_shndx = sym.st_shndx
                    sym_value = sym.st_value
                data_relocs.append(
                    KoDataReloc(
                        offset=base_off + r_offset, sym_idx=sym_idx, symbol_name=sym_name,
                        sym_shndx=sym_shndx, sym_value=sym_value, addend=r_addend,
                        r_type=r_type, is_undef=is_undef,
                    )
                )

        return KoCoreLayout(
            section_offsets=section_offsets, text_start=text_start, text_end=text_end,
            ro_start=ro_start, ro_end=ro_end, data_start=data_start, data_end=data_end,
            ro_image=bytes(ro_image), data_image=bytes(data_image), data_relocs=data_relocs,
        )


class KernelElfSymbols:
    """Minimal ELF64 symbol reader for built-in objects omitted from a KRG."""

    _EHDR = struct.Struct("<16sHHIQQQIHHHHHH")
    _SHDR = struct.Struct("<IIQQQQIIQQ")
    _SYMENT = struct.Struct("<IBBHQQ")

    def __init__(self, path: Path) -> None:
        self.path = path
        self._symbols: Dict[str, KoSymbol] = {}
        self._load(memoryview(path.read_bytes()))

    def _load(self, blob: memoryview) -> None:
        if len(blob) < self._EHDR.size:
            raise ValueError(f"{self.path}: file too small for ELF header")
        (e_ident, e_type, e_machine, _e_version, _e_entry, _e_phoff, e_shoff,
         _e_flags, _e_ehsize, _e_phentsize, _e_phnum, e_shentsize, e_shnum,
         _e_shstrndx) = self._EHDR.unpack_from(blob, 0)
        if (e_ident[0:4] != b"\x7fELF" or e_ident[4] != ELFCLASS64 or
                e_ident[5] != ELFDATA2LSB):
            raise ValueError(f"{self.path}: expected little-endian ELF64")
        if e_type not in (ET_EXEC, ET_DYN):
            raise ValueError(f"{self.path}: expected ET_EXEC/ET_DYN vmlinux, got e_type={e_type}")
        if e_machine != EM_X86_64:
            raise ValueError(f"{self.path}: expected EM_X86_64, got e_machine={e_machine}")
        if e_shentsize != self._SHDR.size or e_shoff == 0 or e_shnum == 0:
            raise ValueError(f"{self.path}: missing or unsupported section table")

        sections = []
        for idx in range(e_shnum):
            offset = e_shoff + idx * e_shentsize
            if offset + self._SHDR.size > len(blob):
                raise ValueError(f"{self.path}: truncated section table")
            sections.append(self._SHDR.unpack_from(blob, offset))

        symtabs = [section for section in sections if section[1] == SHT_SYMTAB]
        if not symtabs:
            raise ValueError(f"{self.path}: .symtab is required")
        for symtab in symtabs:
            _name, _type, _flags, _addr, offset, size, link, _info, _align, entsize = symtab
            if entsize != self._SYMENT.size or link >= len(sections):
                raise ValueError(f"{self.path}: unsupported symbol table")
            strtab = sections[link]
            str_offset, str_size = strtab[4], strtab[5]
            if offset + size > len(blob) or str_offset + str_size > len(blob):
                raise ValueError(f"{self.path}: truncated symbol/string table")
            strings = bytes(blob[str_offset:str_offset + str_size])
            for entry_offset in range(offset, offset + size, entsize):
                st_name, st_info, st_other, st_shndx, st_value, st_size = \
                    self._SYMENT.unpack_from(blob, entry_offset)
                if st_name >= len(strings) or st_shndx == SHN_UNDEF:
                    continue
                end = strings.find(b"\x00", st_name)
                if end < 0:
                    continue
                name = strings[st_name:end].decode("utf-8", errors="ignore")
                if not name:
                    continue
                candidate = KoSymbol(name, st_info, st_other, st_shndx, st_value, st_size)
                current = self._symbols.get(name)
                # Prefer a global definition, then the definition with useful size.
                if current is None or (candidate.bind, bool(candidate.st_size)) > \
                        (current.bind, bool(current.st_size)):
                    self._symbols[name] = candidate

    def find_symbol(self, name: str) -> KoSymbol | None:
        return self._symbols.get(name)

# -----------------------------------------------------------------------------
# Symbol classification
# -----------------------------------------------------------------------------

@dataclass
class ResolvedSymbol:
    name: str
    source: str
    defined: bool
    st_type: int
    module_id: int = 0
    module_name: str = "kernel"
    exported: bool = False
    size: int = 0
    address: int = 0
    virtual_address: int = 0
    section_name: str | None = None
    export_order: int = 0
    original_order: int = 0
    dynsym_index: int = 0
    got_offset: int = 0
    gnu_hash_value: int = 0
    gnu_bucket: int = 0
    replace_from_kernel: bool = True
    reuse_kind: str | None = None

    @property
    def is_import(self) -> bool:
        return not self.defined


def add_private_wrapper_object(
    object_path: Path,
    resolved: List[ResolvedSymbol],
    owner_lib: str,
    owner_module: str,
    text_min_page: int,
    synthetic_text_pages: Dict[int, bytes],
) -> tuple[bytes, int]:
    """Add one user-owned PIC wrapper page and its private context data.

    The object deliberately has a narrow contract: one executable section
    named .vkso.user.text and one writable section named .vkso.user.data.
    Calls and RIP-relative data references are resolved locally while the DSO
    is built, so wrappers never acquire a PLT/GOT dependency on shared core
    symbols.  The executable page contains real file bytes and is therefore
    excluded from page-cache replacement.
    """

    wrapper = KoFile(object_path)
    text = wrapper.find_section(".vkso.user.text")
    data = wrapper.find_section(".vkso.user.data")
    if text is None or not text.is_alloc or not text.is_exec:
        raise ValueError(
            f"{object_path}: missing executable .vkso.user.text section"
        )
    if data is None or not data.is_alloc or not data.is_write:
        raise ValueError(
            f"{object_path}: missing writable .vkso.user.data section"
        )
    if text.sh_size > PAGE_SIZE:
        raise ValueError(
            f"{object_path}: wrapper text exceeds one page ({text.sh_size} bytes)"
        )
    if data.sh_size > PAGE_SIZE:
        raise ValueError(
            f"{object_path}: wrapper data exceeds one page ({data.sh_size} bytes)"
        )

    occupied_end = max(
        (
            sym.address + max(sym.size, 1)
            for sym in resolved
            if sym.defined and sym.address
        ),
        default=text_min_page,
    )
    if synthetic_text_pages:
        occupied_end = max(
            occupied_end,
            max(synthetic_text_pages) + PAGE_SIZE,
        )
    text_kernel_page = align(occupied_end, PAGE_SIZE)
    text_vaddr = TEXT_BASE_VADDR + (text_kernel_page - text_min_page)
    data_vaddr = align(text_vaddr + PAGE_SIZE, PAGE_SIZE)

    by_name = {sym.name: sym for sym in resolved}

    def dso_address(symbol: KoSymbol) -> int:
        if symbol.st_shndx == text.index:
            return text_vaddr + symbol.st_value
        if symbol.st_shndx == data.index:
            return data_vaddr + symbol.st_value
        if symbol.st_shndx == SHN_ABS:
            return symbol.st_value
        if symbol.is_undef:
            target = by_name.get(symbol.name)
            if target is None or not target.defined:
                raise ValueError(
                    f"{object_path}: unresolved wrapper dependency "
                    f"{symbol.name}"
                )
            return TEXT_BASE_VADDR + (target.address - text_min_page)
        raise ValueError(
            f"{object_path}: wrapper symbol {symbol.name or '<anonymous>'} "
            f"uses unsupported section index {symbol.st_shndx}"
        )

    text_image = bytearray(wrapper.section_bytes(text))
    for relocation in wrapper.relocations_for(text):
        if relocation.r_type not in (R_X86_64_PC32, R_X86_64_PLT32):
            raise ValueError(
                f"{object_path}: unsupported wrapper text relocation "
                f"type {relocation.r_type} for {relocation.symbol_name}"
            )
        symbol = wrapper.symbols[relocation.sym_idx]
        place = text_vaddr + relocation.offset
        value = dso_address(symbol) + relocation.addend - place
        if not -(1 << 31) <= value < (1 << 31):
            raise ValueError(
                f"{object_path}: wrapper relocation to {symbol.name} "
                "does not fit rel32"
            )
        if relocation.offset + 4 > len(text_image):
            raise ValueError(
                f"{object_path}: wrapper relocation falls outside text"
            )
        struct.pack_into("<i", text_image, relocation.offset, value)

    page = bytearray(PAGE_SIZE)
    page[:len(text_image)] = text_image
    if text_kernel_page in synthetic_text_pages:
        raise ValueError(
            f"{object_path}: private wrapper page overlaps synthetic page "
            f"0x{text_kernel_page:x}"
        )
    synthetic_text_pages[text_kernel_page] = bytes(page)

    export_order = max(
        (sym.export_order for sym in resolved if sym.exported),
        default=-1,
    ) + 1
    for symbol in wrapper.symbols:
        if (
            symbol.bind != STB_GLOBAL
            or symbol.typ != STT_FUNC
            or symbol.st_shndx != text.index
            or not symbol.name
        ):
            continue
        if symbol.name in by_name:
            raise ValueError(
                f"{object_path}: wrapper export conflicts with "
                f"{symbol.name}"
            )
        exported = ResolvedSymbol(
            name=symbol.name,
            source=owner_lib,
            defined=True,
            exported=True,
            st_type=STT_FUNC,
            size=symbol.st_size,
            address=text_kernel_page + symbol.st_value,
            export_order=export_order,
            original_order=len(resolved),
            module_name=owner_module,
            replace_from_kernel=False,
            reuse_kind="text",
        )
        resolved.append(exported)
        by_name[symbol.name] = exported
        export_order += 1

    return wrapper.section_bytes(data), data_vaddr


def private_wrapper_dependencies(object_path: Path) -> List[str]:
    """Return kernel symbols referenced by the private executable veneer.

    These are dependency roots, not DSO exports.  Keeping the distinction here
    lets a feature list only its public kernel-backed API while the generic
    builder owns the private-wrapper closure.
    """

    wrapper = KoFile(object_path)
    text = wrapper.find_section(".vkso.user.text")
    if text is None or not text.is_alloc or not text.is_exec:
        raise ValueError(
            f"{object_path}: missing executable .vkso.user.text section"
        )
    dependencies: List[str] = []
    seen: Set[str] = set()
    for relocation in wrapper.relocations_for(text):
        symbol = wrapper.symbols[relocation.sym_idx]
        if not symbol.is_undef or not symbol.name or symbol.name in seen:
            continue
        seen.add(symbol.name)
        dependencies.append(symbol.name)
    return dependencies


def role_for_symbol(sym: ResolvedSymbol, owner_module: str) -> str:
    if not sym.replace_from_kernel:
        return "synthetic"
    if not sym.defined:
        return "import"
    return "export" if sym.exported else "internal"

def build_builtin_thunk_pages(
    symbols: Sequence[ResolvedSymbol], configured_thunks: Set[str],
    reusable_text_names: Set[str] | None = None,
) -> Dict[int, bytes]:
    """Build direct-jump thunk pages selected through shim.txt.

    Kernel callers contain fixed rel32 calls to the thunk virtual addresses, so
    the generated code must remain at those same relative addresses.  The whole
    page becomes synthetic because page-cache replacement operates per page.
    A page containing an explicit reusable-text root stays native in its
    entirety, even when it also contains a configured built-in thunk.
    """
    reusable_text_names = reusable_text_names or set()
    reusable_pages = {
        align_down(sym.address, PAGE_SIZE)
        for sym in symbols
        if sym.defined and sym.address and sym.name in reusable_text_names
    }
    configured_registers = {
        register
        for name in configured_thunks
        if (register := indirect_thunk_register(name)) is not None
    }
    selected = [
        sym for sym in symbols
        if (sym.defined and
            indirect_thunk_register(sym.name) in configured_registers and
            align_down(sym.address, PAGE_SIZE) not in reusable_pages)
    ]
    if not selected:
        return {}

    synthetic_page_addrs = {align_down(sym.address, PAGE_SIZE) for sym in selected}
    pages = {page: bytearray(b"\xcc" * PAGE_SIZE) for page in synthetic_page_addrs}

    for sym in symbols:
        page = align_down(sym.address, PAGE_SIZE) if sym.defined and sym.address else None
        if page not in synthetic_page_addrs:
            continue

        register = indirect_thunk_register(sym.name)
        is_return_thunk = sym.name.startswith(RETURN_THUNK_PREFIX)
        if register is None and not is_return_thunk:
            raise ValueError(
                f"cannot synthesize thunk page 0x{page:x}: "
                f"non-thunk dependency {sym.name} shares the page"
            )
        if register is not None and register not in configured_registers:
            raise ValueError(
                f"cannot synthesize thunk page 0x{page:x}: "
                f"{sym.name} is required but is not enabled in shim.txt"
            )

        offset = sym.address - page
        code = b"\xc3" if is_return_thunk else DIRECT_THUNK_ENCODINGS[register]
        if offset + len(code) > PAGE_SIZE:
            raise ValueError(f"{sym.name}: synthetic thunk crosses a page boundary")
        pages[page][offset:offset + len(code)] = code
        sym.module_name = BUILTIN_THUNK_MODULE
        sym.source = BUILTIN_THUNK_MODULE
        sym.replace_from_kernel = False

    return {page: bytes(data) for page, data in pages.items()}

def resolve_requested_symbols(
    requested_names: Sequence[str], graph: KrgGraph, shim_symbols: Set[str],
    exported_names: Sequence[str] | None = None,
) -> tuple[List[ResolvedSymbol], List[str], str, str, List[str]]:
    if not requested_names:
        raise ValueError("at least one symbol is required")

    if exported_names is None:
        exported_names = requested_names
    export_order = {name: idx for idx, name in enumerate(exported_names)}
    # An explicitly requested API is a native export even when the same name is
    # listed as a user-space replacement for dependency closure traversal.
    dependency_shim_symbols = shim_symbols - set(export_order)
    resolved: Dict[str, ResolvedSymbol] = {}
    ordered: List[ResolvedSymbol] = []
    missing: List[str] = []
    needed_libs: List[str] = []
    dep_modules: List[str] = []
    owner_module: str | None = None

    def module_to_lib(module: str) -> str:
        if module == "shim": return LIB_SHIM
        base = Path(module).name
        for ext in (".ko.xz", ".ko.gz", ".ko.zst", ".ko"):
            if base.endswith(ext):
                base = base[: -len(ext)]
                break
        return f"lib{base}.so"

    def module_for_entry(entry: KrgResolvedSymbol) -> str:
        if entry.name in dependency_shim_symbols: return "shim"
        return entry.module_name or "kernel"

    first_lookup = graph.lookup(requested_names[0])
    if first_lookup is None:
        raise ValueError(f"{requested_names[0]}: symbol not found in {graph.path}")
    owner_module = module_for_entry(first_lookup)
    for name in requested_names:
        entry = graph.lookup(name)
        if entry is None: continue
        mod = module_for_entry(entry)
        if mod != owner_module:
            raise ValueError(f"export set crosses modules: {owner_module} vs {mod}")

    for name in requested_names:
        try:
            closure = graph.closure(name, stop_names=dependency_shim_symbols)
        except KeyError as exc:
            missing.append(name)
            print(str(exc), file=sys.stderr)
            continue
        if not closure:
            raise ValueError(f"{name}: empty dependency set returned by {graph.path}")
        for entry in closure:
            sym = resolved.get(entry.name)
            expected_type = STT_FUNC if entry.kind == 0 else STT_OBJECT
            module_name = module_for_entry(entry)
            lib_name = module_to_lib(module_name)
            is_export = entry.name in export_order
            is_shim = module_name == "shim"
            if sym is None:
                sym = ResolvedSymbol(
                    name=entry.name, source=module_to_lib(owner_module or module_name),
                    defined=not is_shim, exported=is_export, st_type=expected_type,
                    size=entry.size, address=entry.address,
                    export_order=export_order.get(entry.name, len(ordered)),
                    original_order=len(ordered), module_id=entry.module_id, module_name=module_name,
                )
                resolved[entry.name] = sym
                ordered.append(sym)
            if is_shim:
                if LIB_SHIM not in needed_libs: needed_libs.append(LIB_SHIM)
                if module_name not in dep_modules: dep_modules.append(module_name)
        if name not in resolved:
            missing.append(name)
            print(f"{name}: symbol missing after resolution", file=sys.stderr)

    if missing and len(missing) == len(requested_names):
        raise ValueError("None of the requested symbols were found; cannot build shared object")
    owner_module = owner_module or "kernel"
    owner_lib = module_to_lib(owner_module)
    return ordered, needed_libs, owner_module, owner_lib, dep_modules

def dump_symbol_addresses_all(module_symbols: Sequence[tuple[str, Sequence[ResolvedSymbol]]], output_path: Path) -> None:
    lines: List[str] = []
    for owner_module, symbols in module_symbols:
        for sym in symbols:
            lines.append(f"{sym.name},0x{sym.address:x},0x{sym.size:x},{sym.module_name},{role_for_symbol(sym, owner_module)}\n")
    output_path.write_text("".join(lines))

def format_module_deps(owner_module: str, dep_modules: Sequence[str], symbols: Sequence[ResolvedSymbol]) -> List[str]:
    dep_to_symbols: Dict[str, List[str]] = {}
    for sym in symbols:
        if sym.module_name == owner_module: continue
        dep_to_symbols.setdefault(sym.module_name, []).append(sym.name)
    lines: List[str] = []
    for mod in dep_modules:
        syms = dep_to_symbols.get(mod, [])
        sym_list = " ".join(sorted(set(syms)))
        lines.append(f"{owner_module} -> {mod}: {sym_list}\n")
    return lines

def dump_dep_symbol_lists(dep_modules: Sequence[str], symbols: Sequence[ResolvedSymbol], base_dir: Path) -> None:
    for mod in dep_modules:
        names = sorted({sym.name for sym in symbols if sym.module_name == mod})
        if not names: continue
        target = base_dir / f"symbols_{mod}.txt"
        target.write_text("\n".join(names) + "\n")

# -----------------------------------------------------------------------------
# Manual ELF builder
# -----------------------------------------------------------------------------

@dataclass
class Region:
    name: str
    start: int
    end: int

    @property
    def size(self) -> int: return self.end - self.start

@dataclass
class SectionDef:
    name: str
    sh_type: int
    sh_flags: int
    align: int
    data: bytes = b""
    size: int | None = None
    link: int = 0
    info: int = 0
    entsize: int = 0
    offset: int | None = None
    addr: int | None = None

    @property
    def content_size(self) -> int: return self.size if self.size is not None else len(self.data)

    @property
    def is_alloc(self) -> bool: return bool(self.sh_flags & SHF_ALLOC)

@dataclass(frozen=True)
class DataRelocation:
    offset: int  
    symbol: ResolvedSymbol | None
    addend: int = 0
    r_type: int = R_X86_64_64

class ManualElfBuilder:
    def __init__(
        self, symbols: List[ResolvedSymbol], needed_libraries: List[str],
        export_stub_size: int = DEFAULT_EXPORT_STUB_SIZE, ro_bytes: bytes = b"",
        data_bytes: bytes = b"", data_relocations: List[DataRelocation] | None = None,
        rw_base_vaddr: int | None = None, extra_text_ranges: List[tuple[int, int]] | None = None,
        extra_ro_ranges: List[tuple[int, int]] | None = None,
        extra_shared_data_ranges: List[tuple[int, int]] | None = None,
        owner_module_name: str | None = None,
        include_data: bool = True, text_min_override: int | None = None,
        synthetic_text_pages: Dict[int, bytes] | None = None,
    ) -> None:
        self.symbols = symbols
        self.defined_symbols = [sym for sym in symbols if sym.defined]
        self.exports = [sym for sym in self.defined_symbols if sym.exported]
        self.imports = [sym for sym in symbols if sym.is_import]
        self.needed_libraries = needed_libraries
        self.export_stub_size = export_stub_size
        self.ro_bytes = ro_bytes
        self.data_bytes = data_bytes
        self.data_relocations = data_relocations or []
        self.rw_base_vaddr = rw_base_vaddr
        self.extra_text_ranges = extra_text_ranges or []
        self.extra_ro_ranges = extra_ro_ranges or []
        self.extra_shared_data_ranges = extra_shared_data_ranges or []
        self.owner_module_name = owner_module_name
        self.include_data = include_data
        self.text_min_override = text_min_override
        self.synthetic_text_pages = dict(synthetic_text_pages or {})
        for page, data in self.synthetic_text_pages.items():
            if page % PAGE_SIZE:
                raise ValueError(f"synthetic text page 0x{page:x} is not page-aligned")
            if len(data) != PAGE_SIZE:
                raise ValueError(f"synthetic text page 0x{page:x} is not {PAGE_SIZE} bytes")
        self.sections: Dict[str, SectionDef] = {}
        self.section_order: List[str] = []
        self.section_indices: Dict[str, int] = {}
        self.shstr_offsets: Dict[str, int] = {}
        self.dynstr_offsets: Dict[str, int] = {}
        self.dynstr_needed_offsets: Dict[str, int] = {}
        self.strtab_offsets: Dict[str, int] = {}
        reloc_syms: List[ResolvedSymbol] = [
            reloc.symbol for reloc in (data_relocations or []) if reloc.symbol is not None
        ]
        dynsyms_ordered: List[ResolvedSymbol] = []
        seen_ids = set()
        for sym in self.exports + self.imports + reloc_syms:
            sid = id(sym)
            if sid in seen_ids: continue
            dynsyms_ordered.append(sym)
            seen_ids.add(sid)
        self.dynamic_symbols: List[ResolvedSymbol] = dynsyms_ordered
        self.gnu_nbuckets = max(3, len(self.dynamic_symbols)) if self.dynamic_symbols else 1
        self.gnu_bloom_size = max(1, (len(self.dynamic_symbols) + 63) // 64) if self.dynamic_symbols else 1
        self.gnu_bloom_shift = 6
        self.text_size = PAGE_SIZE
        self.section_headers_offset = 0
        self.text_regions: List[Region] = []
        self.text_section_names: List[str] = []
        self.ro_regions: List[Region] = []
        self.ro_section_names: List[str] = []
        self.shared_data_regions: List[Region] = []
        self.shared_data_section_names: List[str] = []
        self.region_by_name: Dict[str, Region] = {}
        self.rw_segment_start_offset = 0
        self.rw_segment_start_addr = 0
        self.rw_segment_file_end = 0
        self.rw_segment_mem_end = 0
        self.text_min_page = TEXT_BASE_VADDR

    def write(self, output_path: Path, page_map_path: Path | None = None) -> None:
        self._prepare_symbol_virtual_addresses()
        self._derive_section_order()
        self._reorder_symbols_for_hash()
        self._build_content_sections()
        self._assign_offsets_and_addresses()
        self.build_relocations()
        self._finalize_dynamic_section()
        ph_entries = self._build_program_headers()
        with open(output_path, "wb") as f:
            self._write_elf_header(f, len(ph_entries))
            f.seek(64)
            for ph in ph_entries:
                f.write(ph)
            for name in self.section_order:
                section = self.sections[name]
                if section.sh_type == SHT_NOBITS or section.content_size == 0:
                    continue
                if section.data:
                    f.seek(section.offset)
                    f.write(section.data)
            f.seek(self.section_headers_offset)
            f.write(bytes(64))
            for name in self.section_order:
                section = self.sections[name]
                sh_name = self.shstr_offsets.get(name, 0)
                shdr = struct.pack(
                    "<IIQQQQIIQQ", sh_name, section.sh_type, section.sh_flags,
                    section.addr or 0, section.offset or 0, section.content_size,
                    section.link, section.info, section.align, section.entsize,
                )
                f.write(shdr)
            total_size = self.section_headers_offset + (len(self.section_order) + 1) * 64
            f.truncate(total_size)
        if page_map_path is not None:
            self.write_reusable_page_map(page_map_path)

    def reusable_page_mappings(self) -> List[tuple[int, int, str, str]]:
        """Return exact DSO-file-page to runtime-kernel-page mappings.

        Only sparse reusable text/rodata/shared-data pages belong here.
        Synthetic text pages contain real file payload, and writable/private
        ELF sections are owned by the user-space DSO, so neither may be
        replaced.  A shared-data kernel page is writable in the kernel but is
        deliberately emitted in a read-only, non-executable user segment.
        """
        mappings: List[tuple[int, int, str, str]] = []
        seen_offsets: Set[int] = set()
        seen_kernel_pages: Set[int] = set()
        for kind, names in (("text", self.text_section_names),
                            ("rodata", self.ro_section_names),
                            ("shared_data", self.shared_data_section_names)):
            for name in names:
                section = self.sections[name]
                region = self.region_by_name[name]
                if section.offset is None:
                    raise ValueError(f"{name}: section offset has not been assigned")
                for relative in range(0, region.size, PAGE_SIZE):
                    file_offset = section.offset + relative
                    kernel_vaddr = region.start + relative
                    if kernel_vaddr in self.synthetic_text_pages:
                        continue
                    if file_offset in seen_offsets:
                        raise ValueError(f"duplicate reusable file page 0x{file_offset:x}")
                    if kernel_vaddr in seen_kernel_pages:
                        raise ValueError(f"duplicate reusable kernel page 0x{kernel_vaddr:x}")
                    seen_offsets.add(file_offset)
                    seen_kernel_pages.add(kernel_vaddr)
                    mappings.append((file_offset, kernel_vaddr, kind, name))
        return mappings

    def write_reusable_page_map(self, output_path: Path) -> None:
        mappings = self.reusable_page_mappings()
        if not mappings:
            raise ValueError("generated DSO has no reusable kernel pages")
        lines = ["# file_offset,kernel_vaddr,kind,section\n"]
        lines.extend(
            f"0x{file_offset:x},0x{kernel_vaddr:x},{kind},{section}\n"
            for file_offset, kernel_vaddr, kind, section in mappings
        )
        output_path.write_text("".join(lines))

    def _prepare_symbol_virtual_addresses(self) -> None:
        def keep(sym: ResolvedSymbol) -> bool:
            if self.owner_module_name is None: return True
            return sym.module_name == self.owner_module_name

        code_symbols = [sym for sym in self.defined_symbols if sym.st_type == STT_FUNC and keep(sym)]
        ro_symbols = [
            sym for sym in self.defined_symbols
            if sym.st_type == STT_OBJECT and keep(sym)
            and (sym.reuse_kind == "rodata" or sym.name.startswith(".rodata"))
        ]
        shared_data_symbols = [
            sym for sym in self.defined_symbols
            if sym.st_type == STT_OBJECT and keep(sym)
            and sym.reuse_kind == "shared_data"
        ]
        data_symbols = [
            sym for sym in self.defined_symbols
            if sym.st_type == STT_OBJECT and keep(sym)
            and sym not in ro_symbols and sym not in shared_data_symbols
        ]
        shared_pages: Set[int] = set()
        for sym in shared_data_symbols:
            if (not sym.address or sym.address % PAGE_SIZE or
                    sym.size < PAGE_SIZE or sym.size % PAGE_SIZE):
                raise ValueError(
                    f"{sym.name}: shared_data must be page-aligned and occupy "
                    f"whole pages (address=0x{sym.address:x}, size=0x{sym.size:x})"
                )
            shared_pages.update(
                range(sym.address, sym.address + sym.size, PAGE_SIZE)
            )
        for sym in data_symbols:
            size = max(sym.size, 1)
            first_page = align_down(sym.address, PAGE_SIZE)
            last_page = align_down(sym.address + size - 1, PAGE_SIZE)
            if any(page in shared_pages
                   for page in range(first_page, last_page + PAGE_SIZE, PAGE_SIZE)):
                raise ValueError(
                    f"{sym.name}: ordinary writable object overlaps a shared_data page"
                )

        cursor = TEXT_BASE_VADDR
        for sym in self.defined_symbols:
            if sym.size == 0: sym.size = self.export_stub_size
            if sym.address == 0:
                sym.address = cursor
                cursor += self.export_stub_size

        overall_min_page = (align_down(min(sym.address for sym in self.defined_symbols), PAGE_SIZE) if self.defined_symbols else TEXT_BASE_VADDR)
        if self.text_min_override is not None:
            self.text_min_page = align_down(self.text_min_override, PAGE_SIZE)
        else:
            candidate_text_min = None
            if code_symbols: candidate_text_min = min(sym.address for sym in code_symbols)
            if self.extra_text_ranges:
                extra_min = min(start for start, _ in self.extra_text_ranges)
                candidate_text_min = extra_min if candidate_text_min is None else min(candidate_text_min, extra_min)
            if candidate_text_min is not None: self.text_min_page = align_down(candidate_text_min, PAGE_SIZE)
            else: self.text_min_page = overall_min_page
        for sym in self.defined_symbols:
            sym.virtual_address = TEXT_BASE_VADDR + (sym.address - self.text_min_page)

        self.region_by_name.clear()
        self.text_regions = self._build_regions(code_symbols, ".text", self.extra_text_ranges)
        self.ro_regions = self._build_regions(ro_symbols, ".rodata", self.extra_ro_ranges)
        self.shared_data_regions = self._build_regions(
            shared_data_symbols, ".shared_data", self.extra_shared_data_ranges
        )
        for region in self.text_regions + self.ro_regions + self.shared_data_regions:
            self.region_by_name[region.name] = region
        self.text_section_names = [region.name for region in self.text_regions]
        self.ro_section_names = [region.name for region in self.ro_regions]
        self.shared_data_section_names = [
            region.name for region in self.shared_data_regions
        ]
        self._assign_symbol_sections(code_symbols, self.text_regions)
        self._assign_symbol_sections(ro_symbols, self.ro_regions)
        self._assign_symbol_sections(shared_data_symbols, self.shared_data_regions)
        for sym in data_symbols: sym.section_name = ".data"

    def _build_regions(self, symbols: List[ResolvedSymbol], base_name: str, extra_ranges: List[tuple[int, int]] | None = None) -> List[Region]:
        if not symbols: symbols = []
        intervals: List[tuple[int, int]] = []
        for sym in symbols:
            size = max(sym.size, 1)
            start = align_down(sym.address, PAGE_SIZE)
            end = align(sym.address + size, PAGE_SIZE)
            if end == start: end += PAGE_SIZE
            intervals.append((start, end))
        for start, end in (extra_ranges or []):
            s = align_down(start, PAGE_SIZE)
            e = align(end, PAGE_SIZE)
            if e == s: e += PAGE_SIZE
            intervals.append((s, e))
        if not intervals: return []
        intervals.sort()
        merged: List[List[int]] = []
        for start, end in intervals:
            if not merged or start > merged[-1][1]: merged.append([start, end])
            else: merged[-1][1] = max(merged[-1][1], end)
        regions: List[Region] = []
        if len(merged) == 1: names = [base_name]
        else: names = [f"{base_name}{idx + 1}" for idx in range(len(merged))]
        for name, bounds in zip(names, merged):
            start, end = bounds
            region = Region(name=name, start=start, end=end)
            regions.append(region)
            self.region_by_name[name] = region
        return regions

    def _assign_symbol_sections(self, symbols: List[ResolvedSymbol], regions: List[Region]) -> None:
        if not symbols: return
        for sym in symbols:
            region = self._find_region_for_address(sym.address, regions)
            if region is None: raise ValueError(f"{sym.name}: no region covers address 0x{sym.address:x}")
            sym.section_name = region.name

    @staticmethod
    def _find_region_for_address(address: int, regions: List[Region]) -> Region | None:
        for region in regions:
            if region.start <= address < region.end: return region
        return None

    def _derive_section_order(self) -> None:
        order: List[str] = []
        order.extend(self.text_section_names)
        order.extend(self.ro_section_names)
        order.extend(self.shared_data_section_names)
        if self.include_data: order.append(".data")
        order.extend([".dynstr", ".dynsym", ".gnu.hash"])
        if self.include_data and self.data_relocations: order.append(".rela.dyn")
        order.extend([".dynamic", ".strtab", ".symtab", ".shstrtab"])
        self.section_order = order
        names_with_null = [".null"] + order
        self.section_indices = {name: idx for idx, name in enumerate(names_with_null)}

    def _reorder_symbols_for_hash(self) -> None:
        for sym in self.dynamic_symbols:
            sym.gnu_hash_value = gnu_hash(sym.name)
            sym.gnu_bucket = sym.gnu_hash_value % self.gnu_nbuckets
        self.dynamic_symbols.sort(key=lambda sym: (sym.gnu_bucket, 0 if sym.defined else 1, sym.export_order, sym.original_order))

    def _build_content_sections(self) -> None:
        for region in self.text_regions:
            region_data: bytearray | None = None
            for page, data in self.synthetic_text_pages.items():
                if not (region.start <= page and page + PAGE_SIZE <= region.end):
                    continue
                if region_data is None:
                    region_data = bytearray(region.size)
                offset = page - region.start
                region_data[offset:offset + PAGE_SIZE] = data
            self.sections[region.name] = SectionDef(
                name=region.name, sh_type=SHT_PROGBITS,
                sh_flags=SHF_ALLOC | SHF_EXECINSTR, align=PAGE_SIZE,
                data=bytes(region_data) if region_data is not None else b"",
                size=region.size,
            )
        for region in self.ro_regions:
            self.sections[region.name] = SectionDef(name=region.name, sh_type=SHT_PROGBITS, sh_flags=SHF_ALLOC, align=PAGE_SIZE, data=b"", size=region.size)
        for region in self.shared_data_regions:
            self.sections[region.name] = SectionDef(
                name=region.name, sh_type=SHT_PROGBITS,
                sh_flags=SHF_ALLOC, align=PAGE_SIZE, data=b"", size=region.size
            )
        if self.include_data:
            self.sections[".data"] = SectionDef(name=".data", sh_type=SHT_PROGBITS, sh_flags=SHF_ALLOC | SHF_WRITE, align=8, data=self.data_bytes, size=len(self.data_bytes))
        dynstr = self._build_dynstr()
        dynsym = self._build_dynsym()
        gnu_hash_data = self._build_gnu_hash()
        dynamic_guess_entries = len(self.needed_libraries) + 10
        self.sections[".dynstr"] = SectionDef(name=".dynstr", sh_type=SHT_STRTAB, sh_flags=SHF_ALLOC, align=1, data=dynstr)
        self.sections[".dynsym"] = SectionDef(name=".dynsym", sh_type=SHT_DYNSYM, sh_flags=SHF_ALLOC, align=8, data=dynsym, link=self.section_indices.get(".dynstr", 0), info=1, entsize=24)
        self.sections[".gnu.hash"] = SectionDef(name=".gnu.hash", sh_type=SHT_GNU_HASH, sh_flags=SHF_ALLOC, align=8, data=gnu_hash_data, link=self.section_indices.get(".dynsym", 0))
        if ".rela.dyn" in self.section_order:
            rela_size = len(self.data_relocations) * 24
            self.sections[".rela.dyn"] = SectionDef(name=".rela.dyn", sh_type=SHT_RELA, sh_flags=SHF_ALLOC, align=8, data=bytes(rela_size), size=rela_size, link=self.section_indices.get(".dynsym", 0), info=0, entsize=24)
        self.sections[".dynamic"] = SectionDef(name=".dynamic", sh_type=SHT_DYNAMIC, sh_flags=SHF_ALLOC | SHF_WRITE, align=8, data=bytes(dynamic_guess_entries * 16), entsize=16, link=self.section_indices.get(".dynstr", 0))
        strtab = self._build_strtab()
        symtab = self._build_symtab()
        self.sections[".strtab"] = SectionDef(name=".strtab", sh_type=SHT_STRTAB, sh_flags=0, align=1, data=strtab)
        self.sections[".symtab"] = SectionDef(name=".symtab", sh_type=SHT_SYMTAB, sh_flags=0, align=8, data=symtab, link=self.section_indices.get(".strtab", 0), info=1, entsize=24)
        shstrtab = self._build_shstrtab()
        self.sections[".shstrtab"] = SectionDef(name=".shstrtab", sh_type=SHT_STRTAB, sh_flags=0, align=1, data=shstrtab)

    def _build_dynstr(self) -> bytes:
        data = bytearray(b"\x00")
        for sym in self.dynamic_symbols:
            if sym.name not in self.dynstr_offsets:
                self.dynstr_offsets[sym.name] = len(data)
                data.extend(sym.name.encode("ascii") + b"\x00")
        for lib in self.needed_libraries:
            if lib not in self.dynstr_offsets:
                self.dynstr_offsets[lib] = len(data)
                data.extend(lib.encode("ascii") + b"\x00")
            self.dynstr_needed_offsets[lib] = self.dynstr_offsets[lib]
        return bytes(data)

    def _build_dynsym(self) -> bytes:
        entries = [self._pack_sym_entry(0, STT_NOTYPE, SHN_UNDEF, 0, 0, 0)]
        for idx, sym in enumerate(self.dynamic_symbols, start=1):
            st_name = self.dynstr_offsets[sym.name]
            st_info = (STB_GLOBAL << 4) | sym.st_type
            if sym.section_name is None: st_shndx = SHN_ABS if sym.defined else SHN_UNDEF
            else: st_shndx = self.section_indices.get(sym.section_name, SHN_UNDEF)
            entries.append(self._pack_sym_entry(st_name=st_name, st_type=st_info, st_shndx=st_shndx, st_value=(sym.virtual_address if sym.defined else 0) & 0xFFFFFFFFFFFFFFFF, st_size=sym.size))
            sym.dynsym_index = idx
        return b"".join(entries)

    def _build_gnu_hash(self) -> bytes:
        if not self.dynamic_symbols: return b""
        first_sym = 1
        symbol_count = len(self.dynamic_symbols)
        bloom = [0] * self.gnu_bloom_size
        buckets = [0] * self.gnu_nbuckets
        chains = [0] * symbol_count
        prev_bucket = None
        last_index = None
        for dyn_index, sym in enumerate(self.dynamic_symbols, start=first_sym):
            h = sym.gnu_hash_value
            bucket_idx = sym.gnu_bucket
            word = (h // 64) % self.gnu_bloom_size
            bitmask = (1 << (h % 64)) | (1 << ((h >> self.gnu_bloom_shift) % 64))
            bloom[word] |= bitmask
            if buckets[bucket_idx] == 0:
                buckets[bucket_idx] = dyn_index
                if prev_bucket is not None and last_index is not None: chains[last_index - first_sym] |= 1
            elif bucket_idx != prev_bucket and prev_bucket is not None and last_index is not None:
                chains[last_index - first_sym] |= 1
            chains[dyn_index - first_sym] = h & ~1
            prev_bucket = bucket_idx
            last_index = dyn_index
        if last_index is not None: chains[last_index - first_sym] |= 1
        payload = bytearray()
        payload.extend(struct.pack("<IIII", self.gnu_nbuckets, first_sym, self.gnu_bloom_size, self.gnu_bloom_shift))
        for word in bloom: payload.extend(struct.pack("<Q", word))
        for bucket in buckets: payload.extend(struct.pack("<I", bucket))
        for chain in chains: payload.extend(struct.pack("<I", chain))
        return bytes(payload)

    def _build_strtab(self) -> bytes:
        data = bytearray(b"\x00")
        for sym in self.symbols:
            if sym.name not in self.strtab_offsets:
                self.strtab_offsets[sym.name] = len(data)
                data.extend(sym.name.encode("ascii") + b"\x00")
        return bytes(data)

    def _build_symtab(self) -> bytes:
        entries = [self._pack_sym_entry(0, STT_NOTYPE, SHN_UNDEF, 0, 0, 0)]
        for sym in self.symbols:
            st_name = self.strtab_offsets[sym.name]
            st_info = (STB_GLOBAL << 4) | sym.st_type
            if sym.section_name is None: st_shndx = SHN_ABS if sym.defined else SHN_UNDEF
            else: st_shndx = self.section_indices.get(sym.section_name, SHN_UNDEF)
            entries.append(self._pack_sym_entry(st_name=st_name, st_type=st_info, st_shndx=st_shndx, st_value=(sym.virtual_address if sym.defined else 0) & 0xFFFFFFFFFFFFFFFF, st_size=sym.size))
        return b"".join(entries)

    def _build_shstrtab(self) -> bytes:
        names = [""]
        names.extend(self.section_order)
        data = bytearray()
        for name in names:
            self.shstr_offsets[name] = len(data)
            data.extend(name.encode("ascii") + b"\x00")
        return bytes(data)

    def _assign_offsets_and_addresses(self) -> None:
        current_offset = TEXT_BASE_OFFSET
        text_end_addr = TEXT_BASE_VADDR
        for idx, name in enumerate(self.text_section_names):
            section = self.sections[name]
            if idx == 0: section.offset = TEXT_BASE_OFFSET
            else:
                current_offset = align(current_offset, PAGE_SIZE)
                section.offset = current_offset
            region = self.region_by_name[name]
            section.addr = TEXT_BASE_VADDR + (region.start - self.text_min_page)
            current_offset = section.offset + section.content_size
            text_end_addr = max(text_end_addr, section.addr + section.content_size)

        ro_end_addr = text_end_addr
        for name in self.ro_section_names:
            section = self.sections[name]
            current_offset = align(current_offset, PAGE_SIZE)
            section.offset = current_offset
            region = self.region_by_name[name]
            section.addr = TEXT_BASE_VADDR + (region.start - self.text_min_page)
            current_offset += section.content_size
            ro_end_addr = max(ro_end_addr, section.addr + section.content_size)

        shared_data_end_addr = ro_end_addr
        for name in self.shared_data_section_names:
            section = self.sections[name]
            current_offset = align(current_offset, PAGE_SIZE)
            section.offset = current_offset
            region = self.region_by_name[name]
            section.addr = TEXT_BASE_VADDR + (region.start - self.text_min_page)
            current_offset += section.content_size
            shared_data_end_addr = max(
                shared_data_end_addr, section.addr + section.content_size
            )

        last_alloc_addr = shared_data_end_addr

        reusable_sections = set(
            self.text_section_names + self.ro_section_names +
            self.shared_data_section_names
        )
        rw_sections = [
            name for name in self.section_order
            if self.sections[name].is_alloc and name not in reusable_sections
        ]

        cursor_offset = align(current_offset, PAGE_SIZE)
        cursor_addr_default = align(last_alloc_addr, PAGE_SIZE)
        cursor_addr = cursor_addr_default
        if self.rw_base_vaddr is not None: cursor_addr = align(self.rw_base_vaddr, PAGE_SIZE)

        rw_start_offset: int | None = None
        rw_start_addr: int | None = None

        for name in rw_sections:
            section = self.sections[name]
            cursor_offset = align(cursor_offset, max(1, section.align))
            cursor_addr = align(cursor_addr, max(1, section.align))
            if rw_start_offset is None:
                rw_start_offset = cursor_offset
                rw_start_addr = cursor_addr
            section.offset = cursor_offset
            section.addr = cursor_addr
            cursor_offset += section.content_size
            cursor_addr += section.content_size

        if rw_start_offset is None:
            self.rw_segment_start_offset = 0
            self.rw_segment_start_addr = 0
            self.rw_segment_file_end = cursor_offset
            self.rw_segment_mem_end = cursor_addr
        else:
            self.rw_segment_start_offset = rw_start_offset
            self.rw_segment_start_addr = rw_start_addr or 0
            self.rw_segment_file_end = cursor_offset
            self.rw_segment_mem_end = cursor_addr

        non_alloc_cursor = cursor_offset
        for name in [".strtab", ".symtab", ".shstrtab"]:
            section = self.sections[name]
            non_alloc_cursor = align(non_alloc_cursor, max(1, section.align))
            section.offset = non_alloc_cursor
            section.addr = 0
            non_alloc_cursor += section.content_size

        self.section_headers_offset = align(non_alloc_cursor, 8)

    def build_relocations(self) -> None:
        if not self.data_relocations: return
        rela_sec = self.sections.get(".rela.dyn")
        if rela_sec is None: raise ValueError("internal error: data relocations present but .rela.dyn missing")
        data_sec = self.sections[".data"]
        if data_sec.addr is None: raise ValueError(".data has no assigned address")
        rela_entries: List[bytes] = []
        for reloc in self.data_relocations:
            r_offset = data_sec.addr + reloc.offset
            if reloc.r_type == R_X86_64_RELATIVE: sym_index = 0
            else:
                if reloc.symbol is None: raise ValueError(f"relocation at .data+0x{reloc.offset:x} missing symbol")
                sym_index = reloc.symbol.dynsym_index
            r_info = (sym_index << 32) | reloc.r_type
            rela_entries.append(struct.pack("<QQq", r_offset, r_info, reloc.addend))
        rela_sec.data = b"".join(rela_entries)
        rela_sec.size = len(rela_sec.data)

    def _finalize_dynamic_section(self) -> None:
        dynamic = self.sections[".dynamic"]
        entries: List[tuple[int, int]] = []
        for lib in self.needed_libraries: entries.append((DT_NEEDED, self.dynstr_needed_offsets[lib]))
        entries.extend([
            (DT_GNU_HASH, self.sections[".gnu.hash"].addr or 0),
            (DT_STRTAB, self.sections[".dynstr"].addr or 0),
            (DT_SYMTAB, self.sections[".dynsym"].addr or 0),
        ])
        rela_sec = self.sections.get(".rela.dyn")
        if rela_sec is not None and rela_sec.content_size:
            entries.extend([
                (DT_RELA, rela_sec.addr or 0),
                (DT_RELASZ, rela_sec.content_size),
                (DT_RELAENT, 24),
            ])
        entries.extend([
            (DT_STRSZ, self.sections[".dynstr"].content_size),
            (DT_SYMENT, 24),
            (DT_NULL, 0),
        ])
        payload = bytearray()
        for tag, value in entries: payload.extend(struct.pack("<QQ", tag, value))
        dynamic.data = bytes(payload)
        dynamic.size = len(dynamic.data)

    def _build_program_headers(self) -> List[bytes]:
        entries: List[bytes] = []
        for name in self.text_section_names:
            section = self.sections[name]
            entries.append(self._make_ph_load(offset=section.offset or 0, addr=section.addr or 0, file_size=section.content_size, mem_size=section.content_size, flags=PF_R | PF_X))
        for name in self.ro_section_names:
            section = self.sections[name]
            entries.append(self._make_ph_load(offset=section.offset or 0, addr=section.addr or 0, file_size=section.content_size, mem_size=section.content_size, flags=PF_R))
        for name in self.shared_data_section_names:
            section = self.sections[name]
            entries.append(self._make_ph_load(
                offset=section.offset or 0, addr=section.addr or 0,
                file_size=section.content_size, mem_size=section.content_size,
                flags=PF_R
            ))
        if self.rw_segment_file_end > self.rw_segment_start_offset:
            file_size = max(0, self.rw_segment_file_end - self.rw_segment_start_offset)
            mem_size = self.rw_segment_mem_end - self.rw_segment_start_addr
            entries.append(self._make_ph_load(offset=self.rw_segment_start_offset, addr=self.rw_segment_start_addr, file_size=file_size, mem_size=mem_size, flags=PF_R | PF_W))
        entries.append(self._make_ph_dynamic())
        return entries

    def _make_ph_load(self, offset: int, addr: int, file_size: int, mem_size: int, flags: int) -> bytes:
        return struct.pack("<IIQQQQQQ", PT_LOAD, flags, offset, addr, addr, file_size, mem_size, PAGE_SIZE)

    def _make_ph_dynamic(self) -> bytes:
        dynamic = self.sections[".dynamic"]
        return struct.pack("<IIQQQQQQ", PT_DYNAMIC, PF_R | PF_W, dynamic.offset or 0, dynamic.addr or 0, dynamic.addr or 0, dynamic.content_size, dynamic.content_size, 8)

    @staticmethod
    def _pack_sym_entry(st_name: int, st_type: int, st_shndx: int, st_value: int, st_size: int, st_other: int = 0) -> bytes:
        return struct.pack("<IBBHQQ", st_name, st_type, st_other, st_shndx, st_value, st_size)

    def _write_elf_header(self, f, ph_count: int) -> None:
        e_ident = bytearray(EI_NIDENT)
        e_ident[0:4] = b"\x7fELF"
        e_ident[4] = ELFCLASS64
        e_ident[5] = ELFDATA2LSB
        e_ident[6] = EV_CURRENT
        e_ident[7] = 0
        e_ident[8] = 0
        ehdr = struct.pack(
            "<16sHHIQQQIHHHHHH", bytes(e_ident), ET_DYN, EM_X86_64, EV_CURRENT,
            TEXT_BASE_VADDR, 64, self.section_headers_offset, 0, 64, 56, ph_count, 64,
            len(self.section_order) + 1, self.section_indices.get(".shstrtab", 0)
        )
        f.write(ehdr)

# -----------------------------------------------------------------------------
# CLI glue
# -----------------------------------------------------------------------------

def validate_executable_shim_bindings(
    ko: KoFile, symbols: Sequence[ResolvedSymbol], owner_module: str,
) -> None:
    """Reject Shim bindings that would require rewriting shared owner code.

    This is a module binding check, not certification of the final runtime
    control closure. Private data-slot relocations are handled separately.
    """
    imports = {symbol.name for symbol in symbols
               if not symbol.defined and symbol.module_name == "shim"}
    if not imports:
        return
    try:
        from capstone import Cs, CS_ARCH_X86, CS_MODE_64, CS_GRP_CALL, CS_GRP_JUMP
        from capstone.x86 import X86_OP_IMM
    except ImportError as error:
        raise ValueError("capstone is required to validate executable Shim bindings") from error
    decoder = Cs(CS_ARCH_X86, CS_MODE_64)
    decoder.detail = True
    local_imports = [symbol for symbol in ko.symbols
                     if symbol.name in imports and not symbol.is_undef
                     and symbol.typ == STT_FUNC]
    conflicts: List[str] = []
    for selected in symbols:
        if (not selected.defined or selected.module_name != owner_module
                or selected.st_type != STT_FUNC or not selected.replace_from_kernel):
            continue
        found = ko.find_symbol(selected.name)
        if found is None:
            raise ValueError(f"{ko.path}: cannot locate shared function {selected.name}")
        _, symbol = found
        if symbol.is_undef or symbol.st_shndx >= len(ko.sections):
            raise ValueError(f"{ko.path}: invalid shared function {selected.name}")
        section = ko.sections[symbol.st_shndx]
        start, end = symbol.st_value, symbol.st_value + symbol.st_size
        if (not section.is_exec or not section.is_alloc or symbol.st_size <= 0
                or end > section.sh_size):
            raise ValueError(f"{ko.path}: cannot bound shared function {selected.name}")
        relocations = [relocation for relocation in ko.relocations_for(section)
                       if start <= relocation.offset < end]
        for relocation in relocations:
            if relocation.symbol_name in imports:
                conflicts.append(f"{selected.name}+0x{relocation.offset - start:x}: "
                    f"{relocation.symbol_name} (executable relocation type {relocation.r_type})")
        cursor = start
        for instruction in decoder.disasm(ko.section_bytes(section)[start:end], start):
            if instruction.address != cursor:
                raise ValueError(f"{ko.path}: incomplete decoding of {selected.name}")
            cursor += instruction.size
            if (not (instruction.group(CS_GRP_CALL) or instruction.group(CS_GRP_JUMP))
                    or not instruction.operands or instruction.operands[0].type != X86_OP_IMM):
                continue
            if any(instruction.address <= relocation.offset < cursor for relocation in relocations):
                continue  # A relocation already supplies the target identity above.
            target = instruction.operands[0].imm
            for imported in local_imports:
                if imported.st_shndx != symbol.st_shndx:
                    continue
                if (target == imported.st_value or
                        imported.st_value <= target < imported.st_value + imported.st_size):
                    conflicts.append(f"{selected.name}+0x{instruction.address - start:x}: "
                                     f"{imported.name} (resolved local direct branch)")
        if cursor != end:
            raise ValueError(f"{ko.path}: incomplete decoding of {selected.name}")
    if conflicts:
        raise ValueError(
            "unsupported executable Shim binding: shared instruction bytes retain "
            "their native target; an undefined DSO symbol cannot redirect them. "
            "Provide a supported private data-slot binding or validate a complete "
            "native dependency closure. " + "; ".join(sorted(set(conflicts)))
        )

def module_referenced_ro_ranges(
    ko: KoFile, layout: KoCoreLayout, symbols: Sequence[ResolvedSymbol],
    owner_module: str, module_base: int,
) -> List[tuple[int, int]]:
    """Keep readonly sections referenced by the selected module code/data.

    KRG can omit local literals and zero-sized section symbols. Their ET_REL
    relocations still identify the containing section, including targets reached
    through an addend. Keep that section in full because those symbols do not
    provide an object extent. Unreferenced readonly sections remain sparse.
    This collects pages only; it does not rewrite pointers in shared rodata.
    """
    referenced: Set[int] = set()
    pending: List[int] = []

    def include(reloc: KoDataReloc) -> None:
        index = reloc.sym_shndx
        if reloc.is_undef or index not in layout.section_offsets:
            return
        section = ko.sections[index]
        if (section.is_alloc and not section.is_exec and not section.is_write
                and section.sh_size and index not in referenced):
            referenced.add(index)
            pending.append(index)

    for selected in symbols:
        if (not selected.defined or selected.module_name != owner_module
                or selected.st_type != STT_FUNC or not selected.replace_from_kernel):
            continue
        found = ko.find_symbol(selected.name)
        if found is None:
            continue  # Synthetic relocation symbols have no named ELF entry.
        symbol = found[1]
        if symbol.is_undef or symbol.st_shndx not in layout.section_offsets:
            continue
        section = ko.sections[symbol.st_shndx]
        if not section.is_exec:
            continue
        for reloc in ko.relocations_for(section):
            if symbol.st_value <= reloc.offset < symbol.st_value + symbol.st_size:
                include(reloc)
    for reloc in layout.data_relocs:
        include(reloc)
    while pending:
        for reloc in ko.relocations_for(ko.sections[pending.pop()]):
            include(reloc)
    return sorted((module_base + layout.section_offsets[index],
                   module_base + layout.section_offsets[index] + ko.sections[index].sh_size)
                  for index in referenced)


def infer_default_krg_path() -> Path | None:
    script_path = Path(__file__).resolve()
    for parent in script_path.parents:
        candidate = parent / "KernelCodeMappingFinal/kernel-cgd/src/out.krg"
        if candidate.exists(): return candidate
    return None

def private_data_bindings(ko: KoFile, layout: KoCoreLayout, path: Path | None,
                          shim_symbols: Set[str]) -> Dict[int, dict]:
    """Validate explicit user targets for complete owner pointer objects.

    Keys are offsets in the private data image, never executable locations.
    The original kernel relocation and source text remain unchanged.
    """
    if path is None:
        return {}
    contract = json.loads(path.read_text())
    if contract.get("format") != "vkso-private-data-bindings-v1":
        raise ValueError(f"{path}: unsupported data binding format")
    records = contract.get("bindings")
    if not isinstance(records, list) or not records:
        raise ValueError(f"{path}: bindings must be a nonempty list")
    bound: Dict[int, dict] = {}
    for record in records:
        if not isinstance(record, dict) or any(not isinstance(record.get(key), str) or not record[key]
                for key in ("slot", "kernel_symbol", "user_symbol", "user_library", "signature")):
            raise ValueError(f"{path}: incomplete private binding record")
        if record['user_library'] != LIB_SHIM or record['user_symbol'] == record['kernel_symbol']:
            raise ValueError(f"{path}: binding requires a distinct target in {LIB_SHIM}")
        if record['kernel_symbol'] not in shim_symbols:
            raise ValueError(f"{path}: kernel target must be an explicit Shim dependency")
        matches = [sym for sym in ko.symbols if sym.name == record['slot'] and not sym.is_undef]
        if len(matches) != 1:
            raise ValueError(f"{record['slot']}: expected exactly one defined slot")
        symbol = matches[0]
        if not 0 < symbol.st_shndx < len(ko.sections):
            raise ValueError(f"{record['slot']}: slot has no ordinary data section")
        section = ko.sections[symbol.st_shndx]
        if (symbol.typ != STT_OBJECT or symbol.st_size != 8 or symbol.st_value % 8
                or not section.is_alloc or not section.is_write or section.is_exec
                or section.sh_type != SHT_PROGBITS or section.index not in layout.section_offsets
                or symbol.st_value + 8 > section.sh_size):
            raise ValueError(f"{record['slot']}: binding requires a complete aligned private 8-byte data object")
        offset = layout.section_offsets[section.index] + symbol.st_value - layout.data_start
        if offset < 0 or offset + 8 > len(layout.data_image):
            raise ValueError(f"{record['slot']}: slot lies outside private data")
        overlaps = [reloc for reloc in layout.data_relocs if offset - 7 <= reloc.offset < offset + 8]
        if (len(overlaps) != 1 or overlaps[0].offset != offset
                or overlaps[0].r_type != R_X86_64_64 or overlaps[0].addend != 0
                or not overlaps[0].is_undef or overlaps[0].symbol_name != record['kernel_symbol']):
            raise ValueError(f"{record['slot']}: kernel initializer must be one exact R_X86_64_64 binding")
        if any(abs(offset - other) < 8 for other in bound):
            raise ValueError(f"{record['slot']}: duplicate or overlapping private binding")
        bound[offset] = {**record, "data_offset": offset, "section": section.name,
                         "section_offset": symbol.st_value}
    return bound


def build_shared_object(
    symbols_path: Path, krg_path: Path, export_stub_size: int = DEFAULT_EXPORT_STUB_SIZE,
    symbol_dump_path: Path | None = None, shim_list_path: Path | None = None,
    ko_path: Path | None = None, page_map_path: Path | None = None,
    shared_data_list_path: Path | None = None, vmlinux_path: Path | None = None,
    private_wrapper_object: Path | None = None,
    reusable_text_list_path: Path | None = None,
    data_bindings_path: Path | None = None,
    data_bindings_report_path: Path | None = None,
) -> None:
    graph = KrgGraph(krg_path)
    shim_symbols = load_shim_symbols(shim_list_path)
    requested = parse_symbol_requests(symbols_path)
    shared_data_names = load_shared_data_symbols(shared_data_list_path)
    reusable_text_names = load_reusable_text_symbols(reusable_text_list_path)
    overlap = shared_data_names & reusable_text_names
    if overlap:
        raise ValueError(
            "symbols cannot be both shared_data and reusable_text: "
            + ", ".join(sorted(overlap))
        )
    exported_code_names = [
        name for name in requested if name not in shared_data_names
    ]
    # KRG intentionally describes executable dependency closure and may omit a
    # page-sized data object.  Resolve such explicitly allowed exports below.
    graph_requested = list(exported_code_names)
    for name in sorted(reusable_text_names):
        if name not in graph_requested:
            graph_requested.append(name)
    if private_wrapper_object is not None:
        for name in private_wrapper_dependencies(private_wrapper_object):
            if name in shared_data_names or name in graph_requested:
                continue
            graph_requested.append(name)
    if not graph_requested:
        raise ValueError("at least one KRG-resolved code symbol is required")
    # shim.txt defines dependency boundaries, not replacements for APIs the
    # user explicitly asked this DSO to export.
    native_code_names = set(exported_code_names) | reusable_text_names
    shim_symbols.difference_update(native_code_names)
    if (INDIRECT_THUNK_ARRAY in native_code_names or
            f"{INDIRECT_THUNK_PREFIX}rax" in native_code_names):
        shim_symbols.discard(INDIRECT_THUNK_ARRAY)
        shim_symbols.discard(f"{INDIRECT_THUNK_PREFIX}rax")
    shim_symbols, builtin_thunk_shims = split_builtin_thunk_shims(shim_symbols)
    resolved, needed_libs, owner_module, owner_lib, dep_modules = resolve_requested_symbols(
        graph_requested, graph, shim_symbols,
        exported_names=exported_code_names,
    )
    by_name = {sym.name: sym for sym in resolved}
    for name in sorted(reusable_text_names):
        sym = by_name.get(name)
        if (sym is None or not sym.defined or
                sym.module_name != owner_module or sym.st_type != STT_FUNC):
            raise ValueError(
                f"{name}: reusable_text must be defined executable code "
                f"owned by {owner_module}"
            )

    data_bytes = b""
    data_relocations: List[DataRelocation] = []
    bindings: Dict[int, dict] = {}
    rw_base_vaddr: int | None = None
    extra_ro_ranges: List[tuple[int, int]] = []
    if data_bindings_path is not None and ko_path is None:
        raise ValueError("--data-bindings requires an owner --ko")

    def compute_text_min_page(symbols: Sequence[ResolvedSymbol]) -> int:
        addrs = [sym.address for sym in symbols if sym.defined and sym.st_type == STT_FUNC and sym.address]
        if not addrs: addrs = [sym.address for sym in symbols if sym.defined and sym.address]
        if not addrs: return TEXT_BASE_VADDR
        return align_down(min(addrs), PAGE_SIZE)

    if ko_path is not None:
        ko = KoFile(ko_path)
        layout = ko.compute_core_layout()
        management = ko.find_section(".vkso_owner")
        if management is not None:
            if not management.is_write or management.is_exec or management.sh_size != PAGE_SIZE or management.sh_addralign != PAGE_SIZE:
                raise ValueError("owner descriptor must occupy one writable non-executable management page")
            for name in requested:
                found = ko.find_symbol(name)
                if found is not None and found[1].st_shndx == management.index:
                    raise ValueError("owner management symbols cannot be exported to user space")
        bindings = private_data_bindings(ko, layout, data_bindings_path, shim_symbols)

        def infer_module_core_base_kernel() -> int:
            for name in requested:
                found = ko.find_symbol(name)
                if found is None: continue
                _, ko_sym = found
                if ko_sym.is_undef: continue
                sec_off = layout.section_offsets.get(ko_sym.st_shndx)
                if sec_off is None: continue
                entry = graph.lookup(name)
                if entry is None: continue
                return entry.address - (sec_off + ko_sym.st_value)
            raise ValueError(f"{ko_path}: unable to anchor module layout to out.krg; no common symbol found")

        module_core_base_kernel = infer_module_core_base_kernel()
        ro_kernel_start = module_core_base_kernel + layout.ro_start
        ro_kernel_end = module_core_base_kernel + layout.ro_end
        data_kernel_start = module_core_base_kernel + layout.data_start
        data_kernel_end = module_core_base_kernel + layout.data_end
        data_bytes = layout.data_image
        export_order = {name: idx for idx, name in enumerate(requested)}
        by_name: Dict[str, ResolvedSymbol] = {sym.name: sym for sym in resolved}

        def add_krg_closure(root_name: str) -> None:
            try: closure = graph.closure(root_name, stop_names=shim_symbols)
            except KeyError as exc: raise ValueError(f"{ko_path}: relocation references {root_name} but out.krg has no such symbol") from exc
            for entry in closure:
                module_name = "shim" if entry.name in shim_symbols else (entry.module_name or "kernel")
                is_shim = module_name == "shim"
                expected_type = STT_FUNC if entry.kind == 0 else STT_OBJECT
                is_export = entry.name in export_order
                sym = by_name.get(entry.name)
                if sym is None:
                    sym = ResolvedSymbol(
                        name=entry.name, source=LIB_SHIM if is_shim else owner_lib, defined=not is_shim,
                        exported=is_export, st_type=expected_type, size=entry.size,
                        address=entry.address if not is_shim else 0,
                        export_order=export_order.get(entry.name, len(resolved)), original_order=len(resolved),
                        module_id=entry.module_id, module_name=module_name,
                    )
                    resolved.append(sym)
                    by_name[entry.name] = sym
                else:
                    if is_export and not sym.exported:
                        sym.exported = True
                        sym.export_order = export_order[entry.name]
                if is_shim and LIB_SHIM not in needed_libs: needed_libs.append(LIB_SHIM)

        # 核心修复 1&2：扩展依赖闭包，包括外部 undef 和内部 data/bss/rodata
        for reloc in layout.data_relocs:
            if reloc.r_type != R_X86_64_64: continue
            
            name = reloc.symbol_name
            if not name:
                if reloc.sym_shndx is not None and reloc.sym_shndx < len(ko.sections):
                    sec_name = ko.sections[reloc.sym_shndx].name or ".internal"
                    name = f"{sec_name}+0x{reloc.sym_value:x}"
                else:
                    name = f".internal+0x{reloc.sym_value:x}"

            if reloc.is_undef:
                if name in shim_symbols:
                    if name not in by_name:
                        sym = ResolvedSymbol(
                            name=name, source=LIB_SHIM, defined=False, exported=False,
                            st_type=STT_FUNC, module_name="shim",
                            export_order=export_order.get(name, len(resolved)), original_order=len(resolved)
                        )
                        resolved.append(sym)
                        by_name[name] = sym
                    if LIB_SHIM not in needed_libs: needed_libs.append(LIB_SHIM)
                elif name not in by_name:
                    add_krg_closure(name)
            else:
                # 处理内部已定义符号的绝对地址重定位
                if name not in by_name:
                    sec_off = layout.section_offsets.get(reloc.sym_shndx, 0)
                    addr = module_core_base_kernel + sec_off + reloc.sym_value
                    st_type_extra = STT_OBJECT
                    if reloc.sym_shndx is not None and reloc.sym_shndx < len(ko.sections):
                        if ko.sections[reloc.sym_shndx].sh_flags & SHF_EXECINSTR:
                            st_type_extra = STT_FUNC
                    sym = ResolvedSymbol(
                        name=name, source=owner_lib, defined=True, exported=False,
                        st_type=st_type_extra, size=0, address=addr, module_name=owner_module,
                        export_order=len(resolved), original_order=len(resolved),
                    )
                    resolved.append(sym)
                    by_name[name] = sym

        for sym in resolved:
            if not sym.defined or sym.module_name != owner_module:
                continue
            found = ko.find_symbol(sym.name)
            if found is not None and found[1].st_shndx in layout.section_offsets:
                expected = (module_core_base_kernel +
                            layout.section_offsets[found[1].st_shndx] + found[1].st_value)
                if sym.address != expected:
                    raise ValueError(f"{ko_path}: runtime layout mismatch for {sym.name}: "
                                     f"KRG=0x{sym.address:x}, ELF layout=0x{expected:x}")
            if sym.st_type == STT_FUNC:
                sym.reuse_kind = "text"
            elif ro_kernel_start <= sym.address < ro_kernel_end:
                sym.reuse_kind = "rodata"
            elif data_kernel_start <= sym.address < data_kernel_end:
                sym.reuse_kind = "data"

        text_min_page = compute_text_min_page(resolved)
        rw_base_vaddr = TEXT_BASE_VADDR + (data_kernel_start - text_min_page)

        # 核心修复 3：生成 .so 重定位，将内部/外部目标全部无差别写入 .rela.dyn
        for reloc in layout.data_relocs:
            if reloc.r_type != R_X86_64_64:
                raise ValueError(f"{ko_path}: unsupported pseudo-GOT relocation type {reloc.r_type}")
            name = reloc.symbol_name
            if not name:
                if reloc.sym_shndx is not None and reloc.sym_shndx < len(ko.sections):
                    name = f"{ko.sections[reloc.sym_shndx].name}+0x{reloc.sym_value:x}"
                else:
                    name = f".internal+0x{reloc.sym_value:x}"
            if reloc.offset in bindings:
                binding = bindings[reloc.offset]
                name = binding['user_symbol']
                if name not in by_name:
                    target = ResolvedSymbol(name=name, source=LIB_SHIM, defined=False,
                        exported=False, st_type=STT_FUNC, module_name="shim",
                        export_order=len(resolved), original_order=len(resolved))
                    resolved.append(target)
                    by_name[name] = target
                elif by_name[name].defined or by_name[name].st_type != STT_FUNC:
                    raise ValueError(f"{name}: private binding conflicts with a defined/non-function symbol")
                if LIB_SHIM not in needed_libs:
                    needed_libs.append(LIB_SHIM)
            target = by_name[name]
            data_relocations.append(DataRelocation(offset=reloc.offset, symbol=target, addend=reloc.addend, r_type=R_X86_64_64))

    if shared_data_names:
        by_name = {sym.name: sym for sym in resolved}
        missing_shared = sorted(shared_data_names - set(by_name))
        if missing_shared:
            if owner_module != "kernel":
                raise ValueError("vmlinux shared_data is only valid for the built-in kernel DSO")
            if vmlinux_path is None:
                raise ValueError(
                    "shared-data symbols omitted by KRG require --vmlinux: "
                    + ", ".join(missing_shared)
                )
            kernel_symbols = KernelElfSymbols(vmlinux_path)
            slide: int | None = None
            for anchor_name in graph_requested:
                graph_anchor = graph.lookup(anchor_name)
                elf_anchor = kernel_symbols.find_symbol(anchor_name)
                if graph_anchor is not None and elf_anchor is not None:
                    slide = graph_anchor.address - elf_anchor.st_value
                    break
            if slide is None:
                raise ValueError(f"{vmlinux_path}: cannot determine runtime KASLR slide")
            export_order = {name: idx for idx, name in enumerate(requested)}
            for name in missing_shared:
                elf_sym = kernel_symbols.find_symbol(name)
                if elf_sym is None:
                    raise ValueError(f"{name}: symbol not found in {vmlinux_path}")
                sym = ResolvedSymbol(
                    name=name, source=owner_lib, defined=True,
                    exported=name in export_order, st_type=elf_sym.typ,
                    size=elf_sym.st_size, address=elf_sym.st_value + slide,
                    export_order=export_order.get(name, len(resolved)),
                    original_order=len(resolved), module_name=owner_module,
                )
                resolved.append(sym)
                by_name[name] = sym
        for name in sorted(shared_data_names):
            sym = by_name[name]
            if name in requested:
                sym.exported = True
                sym.export_order = requested.index(name)
            if (not sym.defined or sym.module_name != owner_module or
                    sym.st_type != STT_OBJECT):
                raise ValueError(
                    f"{name}: shared_data must be a defined object owned by {owner_module}"
                )
            if sym.address % PAGE_SIZE or sym.size < PAGE_SIZE or sym.size % PAGE_SIZE:
                raise ValueError(
                    f"{name}: shared_data must be page-aligned and occupy whole pages "
                    f"(address=0x{sym.address:x}, size=0x{sym.size:x})"
                )
            sym.reuse_kind = "shared_data"

    synthetic_text_pages = build_builtin_thunk_pages(
        resolved, builtin_thunk_shims, reusable_text_names
    )
    if private_wrapper_object is not None:
        if data_bytes:
            raise ValueError(
                "--private-wrapper-object cannot be combined with an existing "
                "writable module image"
            )
        text_min_page = compute_text_min_page(resolved)
        data_bytes, rw_base_vaddr = add_private_wrapper_object(
            private_wrapper_object,
            resolved,
            owner_lib,
            owner_module,
            text_min_page,
            synthetic_text_pages,
        )

    if ko_path is not None:
        validate_executable_shim_bindings(ko, resolved, owner_module)
        extra_ro_ranges = module_referenced_ro_ranges(
            ko, layout, resolved, owner_module, module_core_base_kernel)

    dep_modules = ["shim"] if LIB_SHIM in needed_libs else []
    module_deps_path = symbols_path.parent / "module_deps.txt"
    module_deps_path.write_text("".join(format_module_deps(owner_module, dep_modules, resolved)))
    if symbol_dump_path is not None:
        dump_symbol_addresses_all([(owner_module, resolved)], symbol_dump_path)

    owner_manifest = page_map_path.with_name("owner_descriptors.txt")
    owner_lines = []
    if ko_path is not None and ko.find_section(".vkso_owner") is not None:
        candidates = [sym for sym in ko.symbols
                      if sym.st_shndx == ko.find_section(".vkso_owner").index
                      and sym.bind == STB_GLOBAL and sym.typ == STT_OBJECT
                      and sym.st_value == 0 and sym.st_size == PAGE_SIZE]
        if len(candidates) != 1:
            raise ValueError("owner requires one global full-page descriptor object")
        descriptor_name = candidates[0].name
        modinfo = ko.find_section(".modinfo")
        versions = [x.split(b"=", 1)[1].decode("ascii") for x in ko.section_bytes(modinfo).split(b"\0")
                    if x.startswith(b"srcversion=")] if modinfo else []
        if len(versions) != 1 or not 1 <= len(versions[0]) <= 24:
            raise ValueError("owner requires a module srcversion")
        names = [x.split(b"=", 1)[1].decode("ascii") for x in ko.section_bytes(modinfo).split(b"\0")
                 if x.startswith(b"name=")]
        if len(names) != 1 or not names[0] or any(not (c.isascii() and (c.isalnum() or c == "_")) for c in names[0]):
            raise ValueError("owner requires one valid module name")
        owner_lines.append(f"{descriptor_name} {versions[0]} {names[0]} {elf_build_id(ko_path)}\n")

    kernel_identity = elf_build_id(vmlinux_path) if vmlinux_path else None

    builder = ManualElfBuilder(
        symbols=resolved, needed_libraries=needed_libs, export_stub_size=export_stub_size,
        data_bytes=data_bytes, data_relocations=data_relocations, rw_base_vaddr=rw_base_vaddr,
        synthetic_text_pages=synthetic_text_pages,
        extra_ro_ranges=extra_ro_ranges,
    )
    builder.write(Path(owner_lib), page_map_path=page_map_path)
    owner_manifest.write_text("# descriptor_symbol module_srcversion module_name gnu_build_id\n" + "".join(owner_lines))
    page_map_path.with_name("kernel_identity.txt").write_text(
        "# vmlinux GNU build-id; required for registration\n" +
        (f"kernel {kernel_identity}\n" if kernel_identity else ""))
    if data_bindings_report_path is not None:
        data_bindings_report_path.write_text(json.dumps({
            "format": "vkso-private-data-bindings-resolved-v1",
            "owner": str(ko_path) if ko_path else None,
            "bindings": [{**binding, "dso_vaddr": builder.sections['.data'].addr + offset}
                         for offset, binding in sorted(bindings.items())],
        }, indent=2) + "\n")

def main() -> None:
    parser = argparse.ArgumentParser(description="Build a sparse kernel-mapped .so")
    parser.add_argument("--symbols", type=Path, default=Path("symbols.txt"))
    parser.add_argument("--symbol-addresses", type=Path, default=Path("resolved_symbol_addresses.txt"))
    parser.add_argument("--page-map", type=Path, default=Path("page_mappings.txt"))
    parser.add_argument("--skip-symbol-addresses", action="store_true")
    parser.add_argument("--krg", type=Path, default=None)
    parser.add_argument("--export-stub-size", type=lambda x: int(x, 0), default=DEFAULT_EXPORT_STUB_SIZE)
    parser.add_argument("--shim-list", type=Path, default=Path("shim.txt"))
    parser.add_argument("--ko", type=Path, default=None)
    parser.add_argument("--data-bindings", type=Path, default=None)
    parser.add_argument("--data-bindings-report", type=Path, default=None)
    parser.add_argument(
        "--shared-data-list", type=Path, default=Path("shared_data.txt"),
        help="explicit allow-list of page-aligned kernel objects mapped user R--/NX",
    )
    parser.add_argument(
        "--reusable-text-list", type=Path, default=None,
        help="native executable dependency roots whose kernel text pages are reused",
    )
    parser.add_argument(
        "--vmlinux", type=Path, default=None,
        help="matching vmlinux used to resolve explicit shared_data omitted by KRG",
    )
    parser.add_argument(
        "--private-wrapper-object", type=Path, default=None,
        help=(
            "PIC ET_REL object containing one private .vkso.user.text page "
            "and per-process .vkso.user.data"
        ),
    )
    args = parser.parse_args()
    krg_path = args.krg
    if krg_path is None:
        krg_path = infer_default_krg_path()
        if krg_path is None: parser.error("Unable to locate out.krg automatically; provide --krg")
    if not krg_path.exists(): parser.error(f"{krg_path} does not exist")
    symbol_dump_path = None if args.skip_symbol_addresses else args.symbol_addresses
    build_shared_object(
        symbols_path=args.symbols,
        krg_path=krg_path,
        export_stub_size=args.export_stub_size,
        symbol_dump_path=symbol_dump_path,
        shim_list_path=args.shim_list,
        ko_path=args.ko,
        page_map_path=args.page_map,
        shared_data_list_path=args.shared_data_list,
        vmlinux_path=args.vmlinux,
        private_wrapper_object=args.private_wrapper_object,
        reusable_text_list_path=args.reusable_text_list,
        data_bindings_path=args.data_bindings,
        data_bindings_report_path=args.data_bindings_report,
    )

if __name__ == "__main__":
    main()
