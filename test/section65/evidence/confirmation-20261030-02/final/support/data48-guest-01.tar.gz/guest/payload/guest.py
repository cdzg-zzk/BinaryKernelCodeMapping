import subprocess
raise SystemExit(subprocess.call(['bash','/work/package/run.sh','--functional',
    '--blocks','1','--repeats','1','--client-cpu','0','--server-cpu','1','--output','/work/evidence']))
