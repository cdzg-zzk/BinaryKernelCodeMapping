set pagination off
set confirm off
hbreak *vkso_xz_dec_run
commands
silent
printf "XZ_SHARED_EXECUTION rdi=%p rsi=%p\n", $rdi, $rsi
x/6gx $rsi
bt 8
disable 1
detach
quit
end
python open('/var/tmp/vkso-section65-optimization-20261030-hBcg9Y/data48-simultaneous-01/xz-breakpoint-ready', "w").close()
continue
