
#include "xz_services.h"
struct sq_xz_services sq_xz_services;
void sq_bind_xz(const struct sq_xz_services *services)
{
    sq_xz_services = *services;
}
void *sq_xz_support_address(void) { return &sq_xz_services; }
uint32_t vkso_xz_crc32(const uint8_t *buf, size_t size, uint32_t crc)
{
    return sq_xz_services.crc32(buf, size, crc);
}
