cmd_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/xz_support.o := gcc -Wp,-MMD,/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/.xz_support.o.d -nostdinc -isystem /usr/lib/gcc/x86_64-linux-gnu/11/include -I/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include -I./arch/x86/include/generated -I/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include -I./include -I/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi -I./arch/x86/include/generated/uapi -I/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi -I./include/generated/uapi -include /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler-version.h -include /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kconfig.h -include /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler_types.h -D__KERNEL__ -fmacro-prefix-map=/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/= -Wall -Wundef -Werror=strict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -fshort-wchar -fno-PIE -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Wno-format-security -std=gnu89 -mno-sse -mno-mmx -mno-sse2 -mno-3dnow -mno-avx -fcf-protection=none -m64 -falign-jumps=1 -falign-loops=1 -mno-80387 -mno-fp-ret-in-387 -mpreferred-stack-boundary=3 -mskip-rax-setup -mtune=generic -mno-red-zone -Wno-sign-compare -fno-asynchronous-unwind-tables -mindirect-branch=thunk-extern -mindirect-branch-register -mindirect-branch-cs-prefix -mfunction-return=thunk-extern -fno-jump-tables -mharden-sls=all -fno-delete-null-pointer-checks -Wno-frame-address -Wno-format-truncation -Wno-format-overflow -Wno-address-of-packed-member -O2 -fno-allow-store-data-races -Wframe-larger-than=1024 -Wimplicit-fallthrough=5 -Wno-main -Wno-unused-but-set-variable -Wno-unused-const-variable -fno-omit-frame-pointer -fno-optimize-sibling-calls -fno-stack-clash-protection -falign-functions=16 -Wdeclaration-after-statement -Wvla -Wno-pointer-sign -Wno-stringop-truncation -Wno-zero-length-bounds -Wno-array-bounds -Wno-stringop-overflow -Wno-restrict -Wno-maybe-uninitialized -Wno-alloc-size-larger-than -fno-strict-overflow -fno-stack-check -fconserve-stack -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -fno-builtin-wcslen -Wno-packed-not-aligned -mcmodel=small -fpie -fno-stack-protector -fno-sanitize=all -fno-jump-tables -mfunction-return=keep -mindirect-branch=keep -mpreferred-stack-boundary=4 -mincoming-stack-boundary=3 -D__NO_FORTIFY -include /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/xz_names.h  -DMODULE  -DKBUILD_BASENAME='"xz_support"' -DKBUILD_MODNAME='"vkso_sq_core"' -D__KBUILD_MODNAME=kmod_vkso_sq_core -c -o /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/xz_support.o /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/xz_support.c

source_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/xz_support.o := /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/xz_support.c

deps_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/xz_support.o := \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler_types.h \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler_attributes.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler-gcc.h \
    $(wildcard include/config/RETPOLINE) \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/KCOV) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/xz_names.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/xz_services.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/sq_xz_api.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/xz_names.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/stddef.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/stddef.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/types.h \
  arch/x86/include/generated/uapi/asm/types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/int-ll64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/int-ll64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/bitsperlong.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitsperlong.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/bitsperlong.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/posix_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/posix_types.h \
    $(wildcard include/config/X86_32) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/posix_types_64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/posix_types.h \

/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/xz_support.o: $(deps_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/xz_support.o)

$(deps_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/xz_support.o):
