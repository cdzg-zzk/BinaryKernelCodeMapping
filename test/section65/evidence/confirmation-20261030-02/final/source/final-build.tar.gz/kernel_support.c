// SPDX-License-Identifier: GPL-2.0-or-later
/* Linux 5.15.198 SquashFS functions; original notices retained in generated source files. */
#include <linux/slab.h>
#include <linux/blkdev.h>
#include <linux/bio.h>
#include <linux/fs_context.h>
#include <linux/pagemap.h>
#include <linux/magic.h>
#include <linux/xattr.h>
#include "squashfs_fs.h"
#include "squashfs_fs_sb.h"
#include "squashfs_fs_i.h"
#include "squashfs.h"
#include "decompressor.h"
#include "page_actor.h"
#include "xattr.h"

static void *sq_kernel_array(size_t n, size_t size, gfp_t g) { return kcalloc(n,size,g); }
static void sq_kernel_mutex_init(struct mutex *m) { mutex_init(m); }
static void sq_kernel_insert(struct inode *i) { insert_inode_hash(i); }
static void sq_kernel_uid(struct inode *i, uid_t u) { i_uid_write(i,u); }
static void sq_kernel_gid(struct inode *i, gid_t g) { i_gid_write(i,g); }
static void sq_kernel_nohighmem(struct inode *i) { inode_nohighmem(i); }
static loff_t sq_kernel_device_size(struct super_block *s) { return i_size_read(s->s_bdev->bd_inode); }
static struct squashfs_page_actor *sq_kernel_actor(void **p, int n, int l) { return squashfs_page_actor_init(p,n,l); }
static void sq_kernel_fatal(const char *s) { panic("%s", s); }
static void sq_kernel_error(struct fs_context *fc, const char *fmt, ...)
{
    va_list ap;
    struct va_format vaf;
    va_start(ap,fmt); vaf.fmt=fmt; vaf.va=&ap;
    errorf(fc,"%pV",&vaf);
    va_end(ap);
}
extern const struct super_operations squashfs_super_ops;
extern const struct xattr_handler *squashfs_xattr_handler(int);
extern int squashfs_bio_read(struct super_block *, u64, int, struct bio **, int *);
extern int sq_kernel_input_byte(struct bio *, int);
extern void sq_kernel_free_raw(struct bio *);
extern int copy_bio_to_actor(struct bio *, struct squashfs_page_actor *, int, int);
static const struct sq_support bindings = {
    .alloc = __kmalloc,
    .alloc_array = sq_kernel_array,
    .free = kfree,
    .mutex_init = sq_kernel_mutex_init,
    .mutex_lock = mutex_lock,
    .mutex_unlock = mutex_unlock,
    .cache_init = squashfs_cache_init,
    .cache_delete = squashfs_cache_delete,
    .cache_get = squashfs_cache_get,
    .cache_put = squashfs_cache_put,
    .actor_init = sq_kernel_actor,
    .iget = squashfs_iget,
    .new_inode = new_inode,
    .bad_inode = make_bad_inode,
    .insert_inode = sq_kernel_insert,
    .iput = iput,
    .nlink = set_nlink,
    .uid = sq_kernel_uid,
    .gid = sq_kernel_gid,
    .special_inode = init_special_inode,
    .nohighmem = sq_kernel_nohighmem,
    .blocksize = sb_min_blocksize,
    .device_size = sq_kernel_device_size,
    .make_root = d_make_root,
    .splice_alias = d_splice_alias,
    .lookup_decompressor = squashfs_lookup_decompressor,
    .max_decompressors = squashfs_max_decompressors,
    .decompressor_create = squashfs_decompressor_create,
    .decompressor_destroy = squashfs_decompressor_destroy,
    .read_raw = squashfs_bio_read,
    .input_byte = sq_kernel_input_byte,
    .free_raw = sq_kernel_free_raw,
    .decompress = squashfs_decompress,
    .copy_raw = copy_bio_to_actor,
    .error = sq_kernel_error,
    .print = _printk,
    .dynamic_debug = __dynamic_pr_debug,
    .fatal = sq_kernel_fatal,
    .memcpy = memcpy,
    .memset = memset,
    .memcmp = memcmp,
    .strcmp = strcmp,
    .strncmp = strncmp,
    .strncpy = strncpy,
    .strlen = strlen,
    .xattr_handler = squashfs_xattr_handler,
    .super_ops = &squashfs_super_ops,
    .export_ops = &squashfs_export_ops,
    .xattr_handlers = squashfs_xattr_handlers,
    .ro_fops = &generic_ro_fops,
    .inode_ops = &squashfs_inode_ops,
    .dir_inode_ops = &squashfs_dir_inode_ops,
    .dir_ops = &squashfs_dir_ops,
    .symlink_ops = &squashfs_symlink_inode_ops,
    .symlink_aops = &squashfs_symlink_aops,
    .aops = &squashfs_aops,
};

extern int vkso_LZ4_decompress_safe(const char *,char *,int,int);
extern void sq_bind_lz4(void *(*)(void *,const void *,size_t),
                        void *(*)(void *,const void *,size_t),
                        void *(*)(void *,int,size_t));

#include <linux/vmalloc.h>
#include <linux/crc32.h>
#include "xz_services.h"
static void *sq_xz_alloc(size_t n) { return kmalloc(n, GFP_KERNEL); }
static uint32_t sq_xz_crc(const uint8_t *buf, size_t n, uint32_t crc)
{ return ~crc32_le(~crc, buf, n); }
static const struct sq_xz_services xz_bindings = {
    .alloc=sq_xz_alloc, .valloc=vmalloc, .free=kfree, .vfree=vfree,
    .copy=memcpy, .move=memmove, .set=memset, .compare=memcmp, .crc32=sq_xz_crc,
};
void sq_owner_bind(void) { sq_bind_support(&bindings); sq_bind_lz4(memcpy,memmove,memset); sq_bind_xz(&xz_bindings); }
