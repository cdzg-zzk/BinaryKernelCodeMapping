#undef kmalloc
#define kmalloc(...) sq_support.alloc(__VA_ARGS__)
#undef kfree
#define kfree(...) sq_support.free(__VA_ARGS__)
#undef kcalloc
#define kcalloc(...) sq_support.alloc_array(__VA_ARGS__)
#undef mutex_lock
#define mutex_lock(...) sq_support.mutex_lock(__VA_ARGS__)
#undef mutex_unlock
#define mutex_unlock(...) sq_support.mutex_unlock(__VA_ARGS__)
#undef squashfs_cache_init
#define squashfs_cache_init(...) sq_support.cache_init(__VA_ARGS__)
#undef squashfs_cache_delete
#define squashfs_cache_delete(...) sq_support.cache_delete(__VA_ARGS__)
#undef squashfs_cache_get
#define squashfs_cache_get(...) sq_support.cache_get(__VA_ARGS__)
#undef squashfs_cache_put
#define squashfs_cache_put(...) sq_support.cache_put(__VA_ARGS__)
#undef squashfs_page_actor_init
#define squashfs_page_actor_init(...) sq_support.actor_init(__VA_ARGS__)
#undef squashfs_iget
#define squashfs_iget(...) sq_support.iget(__VA_ARGS__)
#undef new_inode
#define new_inode(...) sq_support.new_inode(__VA_ARGS__)
#undef make_bad_inode
#define make_bad_inode(...) sq_support.bad_inode(__VA_ARGS__)
#undef insert_inode_hash
#define insert_inode_hash(...) sq_support.insert_inode(__VA_ARGS__)
#undef iput
#define iput(...) sq_support.iput(__VA_ARGS__)
#undef set_nlink
#define set_nlink(...) sq_support.nlink(__VA_ARGS__)
#undef i_uid_write
#define i_uid_write(...) sq_support.uid(__VA_ARGS__)
#undef i_gid_write
#define i_gid_write(...) sq_support.gid(__VA_ARGS__)
#undef init_special_inode
#define init_special_inode(...) sq_support.special_inode(__VA_ARGS__)
#undef inode_nohighmem
#define inode_nohighmem(...) sq_support.nohighmem(__VA_ARGS__)
#undef sb_min_blocksize
#define sb_min_blocksize(...) sq_support.blocksize(__VA_ARGS__)
#undef d_make_root
#define d_make_root(...) sq_support.make_root(__VA_ARGS__)
#undef d_splice_alias
#define d_splice_alias(...) sq_support.splice_alias(__VA_ARGS__)
#undef squashfs_lookup_decompressor
#define squashfs_lookup_decompressor(...) sq_support.lookup_decompressor(__VA_ARGS__)
#undef squashfs_max_decompressors
#define squashfs_max_decompressors(...) sq_support.max_decompressors(__VA_ARGS__)
#undef squashfs_decompressor_create
#define squashfs_decompressor_create(...) sq_support.decompressor_create(__VA_ARGS__)
#undef squashfs_decompressor_destroy
#define squashfs_decompressor_destroy(...) sq_support.decompressor_destroy(__VA_ARGS__)
#undef squashfs_bio_read
#define squashfs_bio_read(...) sq_support.read_raw(__VA_ARGS__)
#undef squashfs_decompress
#define squashfs_decompress(...) sq_support.decompress(__VA_ARGS__)
#undef copy_bio_to_actor
#define copy_bio_to_actor(...) sq_support.copy_raw(__VA_ARGS__)
#undef errorf
#define errorf(...) sq_support.error(__VA_ARGS__)
#undef printk
#define printk(...) sq_support.print(__VA_ARGS__)
#undef __dynamic_pr_debug
#define __dynamic_pr_debug(...) sq_support.dynamic_debug(__VA_ARGS__)
#undef memcmp
#define memcmp(...) sq_support.memcmp(__VA_ARGS__)
#undef strcmp
#define strcmp(...) sq_support.strcmp(__VA_ARGS__)
#undef strncmp
#define strncmp(...) sq_support.strncmp(__VA_ARGS__)
#undef strncpy
#define strncpy(...) sq_support.strncpy(__VA_ARGS__)
#undef strlen
#define strlen(...) sq_support.strlen(__VA_ARGS__)
#undef squashfs_xattr_handler
#define squashfs_xattr_handler(...) sq_support.xattr_handler(__VA_ARGS__)
#define kzalloc(n,g) sq_support.alloc((n),(g)|__GFP_ZERO)
#undef mutex_init
#define mutex_init(m) sq_support.mutex_init(m)
#undef memcpy
#define memcpy(d,s,n) ((__builtin_constant_p(n) && (size_t)(n) <= 128) ? __builtin_memcpy((d),(s),(n)) : sq_support.memcpy((d),(s),(n)))
#undef memset
#define memset(d,s,n) ((__builtin_constant_p(n) && (size_t)(n) <= 128) ? __builtin_memset((d),(s),(n)) : sq_support.memset((d),(s),(n)))
#define squashfs_super_ops (*sq_support.super_ops)
#define squashfs_export_ops (*sq_support.export_ops)
#define squashfs_xattr_handlers (sq_support.xattr_handlers)
#define generic_ro_fops (*sq_support.ro_fops)
#define squashfs_inode_ops (*sq_support.inode_ops)
#define squashfs_dir_inode_ops (*sq_support.dir_inode_ops)
#define squashfs_dir_ops (*sq_support.dir_ops)
#define squashfs_symlink_inode_ops (*sq_support.symlink_ops)
#define squashfs_symlink_aops (*sq_support.symlink_aops)
#define squashfs_aops (*sq_support.aops)
