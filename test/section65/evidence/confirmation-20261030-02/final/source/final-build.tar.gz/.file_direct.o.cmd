cmd_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/file_direct.o := gcc -Wp,-MMD,/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/.file_direct.o.d -nostdinc -isystem /usr/lib/gcc/x86_64-linux-gnu/11/include -I/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include -I./arch/x86/include/generated -I/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include -I./include -I/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi -I./arch/x86/include/generated/uapi -I/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi -I./include/generated/uapi -include /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler-version.h -include /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kconfig.h -include /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler_types.h -D__KERNEL__ -fmacro-prefix-map=/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/= -Wall -Wundef -Werror=strict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -fshort-wchar -fno-PIE -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Wno-format-security -std=gnu89 -mno-sse -mno-mmx -mno-sse2 -mno-3dnow -mno-avx -fcf-protection=none -m64 -falign-jumps=1 -falign-loops=1 -mno-80387 -mno-fp-ret-in-387 -mpreferred-stack-boundary=3 -mskip-rax-setup -mtune=generic -mno-red-zone -mcmodel=kernel -Wno-sign-compare -fno-asynchronous-unwind-tables -mindirect-branch=thunk-extern -mindirect-branch-register -mindirect-branch-cs-prefix -mfunction-return=thunk-extern -fno-jump-tables -mharden-sls=all -fno-delete-null-pointer-checks -Wno-frame-address -Wno-format-truncation -Wno-format-overflow -Wno-address-of-packed-member -O2 -fno-allow-store-data-races -Wframe-larger-than=1024 -fstack-protector-strong -Wimplicit-fallthrough=5 -Wno-main -Wno-unused-but-set-variable -Wno-unused-const-variable -fno-omit-frame-pointer -fno-optimize-sibling-calls -fno-stack-clash-protection -falign-functions=16 -Wdeclaration-after-statement -Wvla -Wno-pointer-sign -Wno-stringop-truncation -Wno-zero-length-bounds -Wno-array-bounds -Wno-stringop-overflow -Wno-restrict -Wno-maybe-uninitialized -Wno-alloc-size-larger-than -fno-strict-overflow -fno-stack-check -fconserve-stack -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -fno-builtin-wcslen -Wno-packed-not-aligned  -DMODULE  -DKBUILD_BASENAME='"file_direct"' -DKBUILD_MODNAME='"vkso_squashfs"' -D__KBUILD_MODNAME=kmod_vkso_squashfs -c -o /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/file_direct.o /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/file_direct.c

source_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/file_direct.o := /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/file_direct.c

deps_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/file_direct.o := \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler_types.h \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler_attributes.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler-gcc.h \
    $(wildcard include/config/RETPOLINE) \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/KCOV) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/fs.h \
    $(wildcard include/config/READ_ONLY_THP_FOR_FS) \
    $(wildcard include/config/SMP) \
    $(wildcard include/config/FS_POSIX_ACL) \
    $(wildcard include/config/SECURITY) \
    $(wildcard include/config/CGROUP_WRITEBACK) \
    $(wildcard include/config/IMA) \
    $(wildcard include/config/FILE_LOCKING) \
    $(wildcard include/config/FSNOTIFY) \
    $(wildcard include/config/FS_ENCRYPTION) \
    $(wildcard include/config/FS_VERITY) \
    $(wildcard include/config/PREEMPTION) \
    $(wildcard include/config/EPOLL) \
    $(wildcard include/config/UNICODE) \
    $(wildcard include/config/COMPAT) \
    $(wildcard include/config/MMU) \
    $(wildcard include/config/QUOTA) \
    $(wildcard include/config/FS_DAX) \
    $(wildcard include/config/BLOCK) \
    $(wildcard include/config/DEBUG_LOCK_ALLOC) \
    $(wildcard include/config/MIGRATION) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/linkage.h \
    $(wildcard include/config/FUNCTION_ALIGNMENT) \
    $(wildcard include/config/ARCH_USE_SYM_ANNOTATIONS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/stringify.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/export.h \
    $(wildcard include/config/MODVERSIONS) \
    $(wildcard include/config/MODULE_REL_CRCS) \
    $(wildcard include/config/HAVE_ARCH_PREL32_RELOCATIONS) \
    $(wildcard include/config/MODULES) \
    $(wildcard include/config/TRIM_UNUSED_KSYMS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler.h \
    $(wildcard include/config/TRACE_BRANCH_PROFILING) \
    $(wildcard include/config/PROFILE_ALL_BRANCHES) \
    $(wildcard include/config/STACK_VALIDATION) \
    $(wildcard include/config/CFI_CLANG) \
    $(wildcard include/config/64BIT) \
  arch/x86/include/generated/asm/rwonce.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/rwonce.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kasan-checks.h \
    $(wildcard include/config/KASAN_GENERIC) \
    $(wildcard include/config/KASAN_SW_TAGS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/types.h \
  arch/x86/include/generated/uapi/asm/types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/int-ll64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/int-ll64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/bitsperlong.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitsperlong.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/bitsperlong.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/posix_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/stddef.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/stddef.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/posix_types.h \
    $(wildcard include/config/X86_32) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/posix_types_64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/posix_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kcsan-checks.h \
    $(wildcard include/config/KCSAN) \
    $(wildcard include/config/KCSAN_IGNORE_ATOMICS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/linkage.h \
    $(wildcard include/config/RETHUNK) \
    $(wildcard include/config/SLS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/wait_bit.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/wait.h \
    $(wildcard include/config/LOCKDEP) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/list.h \
    $(wildcard include/config/DEBUG_LIST) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/poison.h \
    $(wildcard include/config/ILLEGAL_POINTER_VALUE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/const.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/const.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/const.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kernel.h \
    $(wildcard include/config/PREEMPT_VOLUNTARY) \
    $(wildcard include/config/PREEMPT_DYNAMIC) \
    $(wildcard include/config/PREEMPT_) \
    $(wildcard include/config/DEBUG_ATOMIC_SLEEP) \
    $(wildcard include/config/PROVE_LOCKING) \
    $(wildcard include/config/TRACING) \
    $(wildcard include/config/FTRACE_MCOUNT_RECORD) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/stdarg.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/align.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/array_size.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/limits.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/limits.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/limits.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/bitops.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/bits.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/bits.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/build_bug.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/typecheck.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/kernel.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/sysinfo.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/bitops.h \
    $(wildcard include/config/X86_64) \
    $(wildcard include/config/X86_CMOV) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/alternative.h \
    $(wildcard include/config/MITIGATION_ITS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/asm.h \
    $(wildcard include/config/KPROBES) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/extable_fixup_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/bug.h \
    $(wildcard include/config/GENERIC_BUG) \
    $(wildcard include/config/DEBUG_BUGVERBOSE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/instrumentation.h \
    $(wildcard include/config/DEBUG_ENTRY) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bug.h \
    $(wildcard include/config/BUG) \
    $(wildcard include/config/GENERIC_BUG_RELATIVE_POINTERS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/once_lite.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/panic.h \
    $(wildcard include/config/PANIC_TIMEOUT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/printk.h \
    $(wildcard include/config/MESSAGE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_QUIET) \
    $(wildcard include/config/EARLY_PRINTK) \
    $(wildcard include/config/PRINTK) \
    $(wildcard include/config/PRINTK_INDEX) \
    $(wildcard include/config/DYNAMIC_DEBUG) \
    $(wildcard include/config/DYNAMIC_DEBUG_CORE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/init.h \
    $(wildcard include/config/STRICT_KERNEL_RWX) \
    $(wildcard include/config/STRICT_MODULE_RWX) \
    $(wildcard include/config/LTO_CLANG) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kern_levels.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/cache.h \
    $(wildcard include/config/ARCH_HAS_CACHE_LINE_SIZE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/cache.h \
    $(wildcard include/config/X86_L1_CACHE_SHIFT) \
    $(wildcard include/config/X86_INTERNODE_CACHE_SHIFT) \
    $(wildcard include/config/X86_VSMP) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/ratelimit_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/param.h \
  arch/x86/include/generated/uapi/asm/param.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/param.h \
    $(wildcard include/config/HZ) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/param.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/spinlock_types.h \
    $(wildcard include/config/PREEMPT_RT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/spinlock_types_raw.h \
    $(wildcard include/config/DEBUG_SPINLOCK) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/spinlock_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/qspinlock_types.h \
    $(wildcard include/config/NR_CPUS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/qrwlock_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/byteorder.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/byteorder/little_endian.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/byteorder/little_endian.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/swab.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/swab.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/swab.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/byteorder/generic.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/lockdep_types.h \
    $(wildcard include/config/PROVE_RAW_LOCK_NESTING) \
    $(wildcard include/config/PREEMPT_LOCK) \
    $(wildcard include/config/LOCK_STAT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rwlock_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/dynamic_debug.h \
    $(wildcard include/config/JUMP_LABEL) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/jump_label.h \
    $(wildcard include/config/HAVE_ARCH_JUMP_LABEL_RELATIVE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/jump_label.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/nops.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/rmwcc.h \
    $(wildcard include/config/CC_HAS_ASM_GOTO) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/barrier.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/barrier.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/find.h \
    $(wildcard include/config/GENERIC_FIND_FIRST_BIT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/sched.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/arch_hweight.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/cpufeatures.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/required-features.h \
    $(wildcard include/config/X86_MINIMUM_CPU_FAMILY) \
    $(wildcard include/config/MATH_EMULATION) \
    $(wildcard include/config/X86_PAE) \
    $(wildcard include/config/X86_CMPXCHG64) \
    $(wildcard include/config/X86_USE_3DNOW) \
    $(wildcard include/config/X86_P6_NOP) \
    $(wildcard include/config/MATOM) \
    $(wildcard include/config/PARAVIRT_XXL) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/disabled-features.h \
    $(wildcard include/config/X86_SMAP) \
    $(wildcard include/config/X86_UMIP) \
    $(wildcard include/config/X86_INTEL_MEMORY_PROTECTION_KEYS) \
    $(wildcard include/config/X86_5LEVEL) \
    $(wildcard include/config/PAGE_TABLE_ISOLATION) \
    $(wildcard include/config/CPU_UNRET_ENTRY) \
    $(wildcard include/config/X86_SGX) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/const_hweight.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/instrumented-atomic.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/instrumented.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/instrumented-non-atomic.h \
    $(wildcard include/config/KCSAN_ASSUME_PLAIN_WRITES_ATOMIC) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/instrumented-lock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/le.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kstrtox.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/log2.h \
    $(wildcard include/config/ARCH_HAS_ILOG2_U32) \
    $(wildcard include/config/ARCH_HAS_ILOG2_U64) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/math.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/div64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/div64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/minmax.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/static_call_types.h \
    $(wildcard include/config/HAVE_STATIC_CALL) \
    $(wildcard include/config/HAVE_STATIC_CALL_INLINE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/spinlock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/preempt.h \
    $(wildcard include/config/PREEMPT_COUNT) \
    $(wildcard include/config/DEBUG_PREEMPT) \
    $(wildcard include/config/TRACE_PREEMPT_TOGGLE) \
    $(wildcard include/config/PREEMPT_NOTIFIERS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/cleanup.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/preempt.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/percpu.h \
    $(wildcard include/config/X86_64_SMP) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/percpu.h \
    $(wildcard include/config/HAVE_SETUP_PER_CPU_AREA) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/threads.h \
    $(wildcard include/config/BASE_SMALL) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/percpu-defs.h \
    $(wildcard include/config/DEBUG_FORCE_WEAK_PER_CPU) \
    $(wildcard include/config/AMD_MEM_ENCRYPT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/thread_info.h \
    $(wildcard include/config/THREAD_INFO_IN_TASK) \
    $(wildcard include/config/GENERIC_ENTRY) \
    $(wildcard include/config/HAVE_ARCH_WITHIN_STACK_FRAMES) \
    $(wildcard include/config/HARDENED_USERCOPY) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/bug.h \
    $(wildcard include/config/BUG_ON_DATA_CORRUPTION) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/restart_block.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/time64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/math64.h \
    $(wildcard include/config/ARCH_SUPPORTS_INT128) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/math64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/time64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/time.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/time_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/errno.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/errno.h \
  arch/x86/include/generated/uapi/asm/errno.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/errno.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/errno-base.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/current.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/thread_info.h \
    $(wildcard include/config/VM86) \
    $(wildcard include/config/X86_IOPL_IOPERM) \
    $(wildcard include/config/FRAME_POINTER) \
    $(wildcard include/config/IA32_EMULATION) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/page.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/page_types.h \
    $(wildcard include/config/PHYSICAL_START) \
    $(wildcard include/config/PHYSICAL_ALIGN) \
    $(wildcard include/config/DYNAMIC_PHYSICAL_MASK) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mem_encrypt.h \
    $(wildcard include/config/ARCH_HAS_MEM_ENCRYPT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/mem_encrypt.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/cc_platform.h \
    $(wildcard include/config/ARCH_HAS_CC_PLATFORM) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/bootparam.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/screen_info.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/screen_info.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/apm_bios.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/apm_bios.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/ioctl.h \
  arch/x86/include/generated/uapi/asm/ioctl.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/ioctl.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/ioctl.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/edd.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/edd.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/ist.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/ist.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/video/edid.h \
    $(wildcard include/config/X86) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/video/edid.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/page_64_types.h \
    $(wildcard include/config/KASAN) \
    $(wildcard include/config/DYNAMIC_MEMORY_LAYOUT) \
    $(wildcard include/config/RANDOMIZE_BASE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/kaslr.h \
    $(wildcard include/config/RANDOMIZE_MEMORY) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/page_64.h \
    $(wildcard include/config/DEBUG_VIRTUAL) \
    $(wildcard include/config/FLATMEM) \
    $(wildcard include/config/X86_VSYSCALL_EMULATION) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/range.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/memory_model.h \
    $(wildcard include/config/SPARSEMEM_VMEMMAP) \
    $(wildcard include/config/SPARSEMEM) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/pfn.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/getorder.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/cpufeature.h \
    $(wildcard include/config/X86_FEATURE_NAMES) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/processor.h \
    $(wildcard include/config/X86_VMX_FEATURE_NAMES) \
    $(wildcard include/config/STACKPROTECTOR) \
    $(wildcard include/config/X86_DEBUGCTLMSR) \
    $(wildcard include/config/CPU_SUP_AMD) \
    $(wildcard include/config/XEN) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/processor-flags.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/processor-flags.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/math_emu.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/ptrace.h \
    $(wildcard include/config/PARAVIRT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/segment.h \
    $(wildcard include/config/XEN_PV) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/ptrace.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/ptrace-abi.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/paravirt_types.h \
    $(wildcard include/config/PGTABLE_LEVELS) \
    $(wildcard include/config/PARAVIRT_DEBUG) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/desc_defs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/pgtable_types.h \
    $(wildcard include/config/MEM_SOFT_DIRTY) \
    $(wildcard include/config/HAVE_ARCH_USERFAULTFD_WP) \
    $(wildcard include/config/PROC_FS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/pgtable_64_types.h \
    $(wildcard include/config/DEBUG_KMAP_LOCAL_FORCE_MAP) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/sparsemem.h \
    $(wildcard include/config/NUMA_KEEP_MEMINFO) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/nospec-branch.h \
    $(wildcard include/config/CPU_SRSO) \
    $(wildcard include/config/CPU_IBPB_ENTRY) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/static_key.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/objtool.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/msr-index.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/unwind_hints.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/orc_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/GEN-for-each-reg.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/proto.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/ldt.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/sigcontext.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/msr.h \
    $(wildcard include/config/TRACEPOINTS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/msr-index.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/cpumask.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/cpumask.h \
    $(wildcard include/config/CPUMASK_OFFSTACK) \
    $(wildcard include/config/HOTPLUG_CPU) \
    $(wildcard include/config/DEBUG_PER_CPU_MAPS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/bitmap.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/string.h \
    $(wildcard include/config/BINARY_PRINTF) \
    $(wildcard include/config/FORTIFY_SOURCE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/err.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/overflow.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/string.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/string.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/string_64.h \
    $(wildcard include/config/ARCH_HAS_UACCESS_FLUSHCACHE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/fortify-string.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/atomic.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/atomic.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/cmpxchg.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/cmpxchg_64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/atomic64_64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/atomic/atomic-arch-fallback.h \
    $(wildcard include/config/GENERIC_ATOMIC64) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/atomic/atomic-long.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/atomic/atomic-instrumented.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/msr.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/tracepoint-defs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/paravirt.h \
    $(wildcard include/config/PARAVIRT_SPINLOCKS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/frame.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/special_insns.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/irqflags.h \
    $(wildcard include/config/TRACE_IRQFLAGS) \
    $(wildcard include/config/IRQSOFF_TRACER) \
    $(wildcard include/config/PREEMPT_TRACER) \
    $(wildcard include/config/DEBUG_IRQFLAGS) \
    $(wildcard include/config/TRACE_IRQFLAGS_SUPPORT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/irqflags.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/fpu/types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/vmxfeatures.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/vdso/processor.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/personality.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/personality.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/bottom_half.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/lockdep.h \
    $(wildcard include/config/DEBUG_LOCKING_API_SELFTESTS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/smp.h \
    $(wildcard include/config/UP_LATE_INIT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/smp_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/llist.h \
    $(wildcard include/config/ARCH_HAVE_NMI_SAFE_CMPXCHG) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/smp.h \
    $(wildcard include/config/X86_LOCAL_APIC) \
    $(wildcard include/config/DEBUG_NMI_SELFTEST) \
  arch/x86/include/generated/asm/mmiowb.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/mmiowb.h \
    $(wildcard include/config/MMIOWB) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/spinlock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/qspinlock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/qspinlock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/qrwlock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/qrwlock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rwlock.h \
    $(wildcard include/config/PREEMPT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/spinlock_api_smp.h \
    $(wildcard include/config/INLINE_SPIN_LOCK) \
    $(wildcard include/config/INLINE_SPIN_LOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK_BH) \
    $(wildcard include/config/UNINLINE_SPIN_UNLOCK) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/GENERIC_LOCKBREAK) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rwlock_api_smp.h \
    $(wildcard include/config/INLINE_READ_LOCK) \
    $(wildcard include/config/INLINE_WRITE_LOCK) \
    $(wildcard include/config/INLINE_READ_LOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_LOCK_BH) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_READ_TRYLOCK) \
    $(wildcard include/config/INLINE_WRITE_TRYLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_BH) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQRESTORE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/wait.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kdev_t.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/kdev_t.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/dcache.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rculist.h \
    $(wildcard include/config/PROVE_RCU_LIST) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rcupdate.h \
    $(wildcard include/config/PREEMPT_RCU) \
    $(wildcard include/config/TINY_RCU) \
    $(wildcard include/config/TASKS_RCU_GENERIC) \
    $(wildcard include/config/RCU_STALL_COMMON) \
    $(wildcard include/config/NO_HZ_FULL) \
    $(wildcard include/config/RCU_NOCB_CPU) \
    $(wildcard include/config/TASKS_RCU) \
    $(wildcard include/config/TASKS_TRACE_RCU) \
    $(wildcard include/config/TASKS_RUDE_RCU) \
    $(wildcard include/config/TREE_RCU) \
    $(wildcard include/config/DEBUG_OBJECTS_RCU_HEAD) \
    $(wildcard include/config/PROVE_RCU) \
    $(wildcard include/config/ARCH_WEAK_RELEASE_ACQUIRE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rcutree.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rculist_bl.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/list_bl.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/bit_spinlock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/seqlock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mutex.h \
    $(wildcard include/config/MUTEX_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_MUTEXES) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/osq_lock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/debug_locks.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/ww_mutex.h \
    $(wildcard include/config/DEBUG_RT_MUTEXES) \
    $(wildcard include/config/DEBUG_WW_MUTEX_SLOWPATH) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rtmutex.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rbtree_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/lockref.h \
    $(wildcard include/config/ARCH_USE_CMPXCHG_LOCKREF) \
  include/generated/bounds.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/stringhash.h \
    $(wildcard include/config/DCACHE_WORD_ACCESS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/hash.h \
    $(wildcard include/config/HAVE_ARCH_HASH) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/path.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/stat.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/stat.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/stat.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/time.h \
    $(wildcard include/config/POSIX_TIMERS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/time32.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/timex.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/timex.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/timex.h \
    $(wildcard include/config/X86_TSC) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/tsc.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/time32.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/time.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/uidgid.h \
    $(wildcard include/config/MULTIUSER) \
    $(wildcard include/config/USER_NS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/highuid.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/list_lru.h \
    $(wildcard include/config/MEMCG_KMEM) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/nodemask.h \
    $(wildcard include/config/HIGHMEM) \
    $(wildcard include/config/NUMA) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/numa.h \
    $(wildcard include/config/NODES_SHIFT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/shrinker.h \
    $(wildcard include/config/MEMCG) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/radix-tree.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/percpu.h \
    $(wildcard include/config/NEED_PER_CPU_EMBED_FIRST_CHUNK) \
    $(wildcard include/config/NEED_PER_CPU_PAGE_FIRST_CHUNK) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mmdebug.h \
    $(wildcard include/config/DEBUG_VM) \
    $(wildcard include/config/DEBUG_VM_PGFLAGS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/xarray.h \
    $(wildcard include/config/XARRAY_MULTI) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/gfp.h \
    $(wildcard include/config/ZONE_DMA) \
    $(wildcard include/config/ZONE_DMA32) \
    $(wildcard include/config/ZONE_DEVICE) \
    $(wildcard include/config/COMPACTION) \
    $(wildcard include/config/PM_SLEEP) \
    $(wildcard include/config/CONTIG_ALLOC) \
    $(wildcard include/config/CMA) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mmzone.h \
    $(wildcard include/config/FORCE_MAX_ZONEORDER) \
    $(wildcard include/config/MEMORY_ISOLATION) \
    $(wildcard include/config/ZSMALLOC) \
    $(wildcard include/config/SHADOW_CALL_STACK) \
    $(wildcard include/config/SWAP) \
    $(wildcard include/config/TRANSPARENT_HUGEPAGE) \
    $(wildcard include/config/MEMORY_HOTPLUG) \
    $(wildcard include/config/PAGE_EXTENSION) \
    $(wildcard include/config/DEFERRED_STRUCT_PAGE_INIT) \
    $(wildcard include/config/HAVE_MEMORYLESS_NODES) \
    $(wildcard include/config/SPARSEMEM_EXTREME) \
    $(wildcard include/config/HAVE_ARCH_PFN_VALID) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/pageblock-flags.h \
    $(wildcard include/config/HUGETLB_PAGE) \
    $(wildcard include/config/HUGETLB_PAGE_SIZE_VARIABLE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/page-flags-layout.h \
    $(wildcard include/config/KASAN_HW_TAGS) \
    $(wildcard include/config/NUMA_BALANCING) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mm_types.h \
    $(wildcard include/config/HAVE_ALIGNED_STRUCT_PAGE) \
    $(wildcard include/config/ARCH_WANT_HUGE_PMD_SHARE) \
    $(wildcard include/config/USERFAULTFD) \
    $(wildcard include/config/HAVE_ARCH_COMPAT_MMAP_BASES) \
    $(wildcard include/config/MEMBARRIER) \
    $(wildcard include/config/AIO) \
    $(wildcard include/config/MMU_NOTIFIER) \
    $(wildcard include/config/ARCH_WANT_BATCHED_UNMAP_TLB_FLUSH) \
    $(wildcard include/config/IOMMU_SUPPORT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mm_types_task.h \
    $(wildcard include/config/SPLIT_PTLOCK_CPUS) \
    $(wildcard include/config/ARCH_ENABLE_SPLIT_PMD_PTLOCK) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/tlbbatch.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/auxvec.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/auxvec.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/auxvec.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rbtree.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rwsem.h \
    $(wildcard include/config/RWSEM_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_RWSEMS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/completion.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/swait.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/uprobes.h \
    $(wildcard include/config/UPROBES) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/workqueue.h \
    $(wildcard include/config/DEBUG_OBJECTS_WORK) \
    $(wildcard include/config/FREEZER) \
    $(wildcard include/config/SYSFS) \
    $(wildcard include/config/WQ_WATCHDOG) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/timer.h \
    $(wildcard include/config/DEBUG_OBJECTS_TIMERS) \
    $(wildcard include/config/NO_HZ_COMMON) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/ktime.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/jiffies.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/jiffies.h \
  include/generated/timeconst.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/ktime.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/timekeeping.h \
    $(wildcard include/config/GENERIC_CMOS_UPDATE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/clocksource_ids.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/debugobjects.h \
    $(wildcard include/config/DEBUG_OBJECTS) \
    $(wildcard include/config/DEBUG_OBJECTS_FREE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/mmu.h \
    $(wildcard include/config/MODIFY_LDT_SYSCALL) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/page-flags.h \
    $(wildcard include/config/ARCH_USES_PG_UNCACHED) \
    $(wildcard include/config/MEMORY_FAILURE) \
    $(wildcard include/config/PAGE_IDLE_FLAG) \
    $(wildcard include/config/THP_SWAP) \
    $(wildcard include/config/KSM) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/local_lock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/local_lock_internal.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/memory_hotplug.h \
    $(wildcard include/config/ARCH_HAS_ADD_PAGES) \
    $(wildcard include/config/HAVE_ARCH_NODEDATA_EXTENSION) \
    $(wildcard include/config/MEMORY_HOTREMOVE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/notifier.h \
    $(wildcard include/config/TREE_SRCU) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/srcu.h \
    $(wildcard include/config/TINY_SRCU) \
    $(wildcard include/config/SRCU) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rcu_segcblist.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/srcutree.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rcu_node_tree.h \
    $(wildcard include/config/RCU_FANOUT) \
    $(wildcard include/config/RCU_FANOUT_LEAF) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/mmzone.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/mmzone_64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/topology.h \
    $(wildcard include/config/USE_PERCPU_NUMA_NODE_ID) \
    $(wildcard include/config/SCHED_SMT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/arch_topology.h \
    $(wildcard include/config/GENERIC_ARCH_TOPOLOGY) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/topology.h \
    $(wildcard include/config/SCHED_MC_PRIO) \
    $(wildcard include/config/ACPI_CPPC_LIB) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/mpspec.h \
    $(wildcard include/config/EISA) \
    $(wildcard include/config/X86_MPPARSE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/mpspec_def.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/x86_init.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/apicdef.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/topology.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kconfig.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sched/mm.h \
    $(wildcard include/config/ARCH_HAS_MEMBARRIER_CALLBACKS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sched.h \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING_NATIVE) \
    $(wildcard include/config/SCHED_INFO) \
    $(wildcard include/config/SCHEDSTATS) \
    $(wildcard include/config/FAIR_GROUP_SCHED) \
    $(wildcard include/config/RT_GROUP_SCHED) \
    $(wildcard include/config/RT_MUTEXES) \
    $(wildcard include/config/UCLAMP_TASK) \
    $(wildcard include/config/UCLAMP_BUCKETS_COUNT) \
    $(wildcard include/config/KMAP_LOCAL) \
    $(wildcard include/config/SCHED_CORE) \
    $(wildcard include/config/CGROUP_SCHED) \
    $(wildcard include/config/BLK_DEV_IO_TRACE) \
    $(wildcard include/config/COMPAT_BRK) \
    $(wildcard include/config/CGROUPS) \
    $(wildcard include/config/BLK_CGROUP) \
    $(wildcard include/config/PSI) \
    $(wildcard include/config/PAGE_OWNER) \
    $(wildcard include/config/EVENTFD) \
    $(wildcard include/config/ARCH_HAS_SCALED_CPUTIME) \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING_GEN) \
    $(wildcard include/config/POSIX_CPUTIMERS) \
    $(wildcard include/config/POSIX_CPU_TIMERS_TASK_WORK) \
    $(wildcard include/config/KEYS) \
    $(wildcard include/config/SYSVIPC) \
    $(wildcard include/config/DETECT_HUNG_TASK) \
    $(wildcard include/config/IO_URING) \
    $(wildcard include/config/AUDIT) \
    $(wildcard include/config/AUDITSYSCALL) \
    $(wildcard include/config/UBSAN) \
    $(wildcard include/config/UBSAN_TRAP) \
    $(wildcard include/config/TASK_XACCT) \
    $(wildcard include/config/CPUSETS) \
    $(wildcard include/config/X86_CPU_RESCTRL) \
    $(wildcard include/config/FUTEX) \
    $(wildcard include/config/PERF_EVENTS) \
    $(wildcard include/config/RSEQ) \
    $(wildcard include/config/TASK_DELAY_ACCT) \
    $(wildcard include/config/FAULT_INJECTION) \
    $(wildcard include/config/LATENCYTOP) \
    $(wildcard include/config/KUNIT) \
    $(wildcard include/config/FUNCTION_GRAPH_TRACER) \
    $(wildcard include/config/BCACHE) \
    $(wildcard include/config/VMAP_STACK) \
    $(wildcard include/config/LIVEPATCH) \
    $(wildcard include/config/BPF_SYSCALL) \
    $(wildcard include/config/GCC_PLUGIN_STACKLEAK) \
    $(wildcard include/config/X86_MCE) \
    $(wildcard include/config/KRETPROBES) \
    $(wildcard include/config/ARCH_HAS_PARANOID_L1D_FLUSH) \
    $(wildcard include/config/ARCH_TASK_STRUCT_ON_STACK) \
    $(wildcard include/config/DEBUG_RSEQ) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/sched.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/pid.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/refcount.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sem.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/sem.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/ipc.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rhashtable-types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/ipc.h \
  arch/x86/include/generated/uapi/asm/ipcbuf.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/ipcbuf.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/sembuf.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/shm.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/shm.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/hugetlb_encode.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/shmbuf.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/shmbuf.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/shmparam.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/plist.h \
    $(wildcard include/config/DEBUG_PLIST) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/hrtimer.h \
    $(wildcard include/config/HIGH_RES_TIMERS) \
    $(wildcard include/config/TIME_LOW_RES) \
    $(wildcard include/config/TIMERFD) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/hrtimer_defs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/timerqueue.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/seccomp.h \
    $(wildcard include/config/SECCOMP) \
    $(wildcard include/config/HAVE_ARCH_SECCOMP_FILTER) \
    $(wildcard include/config/SECCOMP_FILTER) \
    $(wildcard include/config/CHECKPOINT_RESTORE) \
    $(wildcard include/config/SECCOMP_CACHE_DEBUG) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/seccomp.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/seccomp.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/unistd.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/unistd.h \
  arch/x86/include/generated/uapi/asm/unistd_64.h \
  arch/x86/include/generated/asm/unistd_64_x32.h \
  arch/x86/include/generated/asm/unistd_32_ia32.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/seccomp.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/unistd.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/resource.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/resource.h \
  arch/x86/include/generated/uapi/asm/resource.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/resource.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/resource.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/latencytop.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sched/prio.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sched/types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/signal_types.h \
    $(wildcard include/config/OLD_SIGACTION) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/signal.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/signal.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/signal.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/signal-defs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/siginfo.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/siginfo.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/syscall_user_dispatch.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/task_io_accounting.h \
    $(wildcard include/config/TASK_IO_ACCOUNTING) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/posix-timers.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/alarmtimer.h \
    $(wildcard include/config/RTC_CLASS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/task_work.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/rseq.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kcsan.h \
  arch/x86/include/generated/asm/kmap_size.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/kmap_size.h \
    $(wildcard include/config/DEBUG_KMAP_LOCAL) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sync_core.h \
    $(wildcard include/config/ARCH_HAS_SYNC_CORE_BEFORE_USERMODE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/sync_core.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/capability.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/capability.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/semaphore.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/fcntl.h \
    $(wildcard include/config/ARCH_32BIT_OFF_T) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/fcntl.h \
  arch/x86/include/generated/uapi/asm/fcntl.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/fcntl.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/openat2.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/migrate_mode.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/percpu-rwsem.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rcuwait.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sched/signal.h \
    $(wildcard include/config/SCHED_AUTOGROUP) \
    $(wildcard include/config/BSD_PROCESS_ACCT) \
    $(wildcard include/config/TASKSTATS) \
    $(wildcard include/config/STACK_GROWSUP) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/signal.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sched/jobctl.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sched/task.h \
    $(wildcard include/config/HAVE_EXIT_THREAD) \
    $(wildcard include/config/ARCH_WANTS_DYNAMIC_TASK_STRUCT) \
    $(wildcard include/config/HAVE_ARCH_THREAD_STRUCT_WHITELIST) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/uaccess.h \
    $(wildcard include/config/SET_FS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/fault-inject-usercopy.h \
    $(wildcard include/config/FAULT_INJECTION_USERCOPY) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/uaccess.h \
    $(wildcard include/config/CC_HAS_ASM_GOTO_OUTPUT) \
    $(wildcard include/config/CC_ASM_GOTO_OUTPUT) \
    $(wildcard include/config/CC_HAS_ASM_GOTO_TIED_OUTPUT) \
    $(wildcard include/config/ARCH_HAS_COPY_MC) \
    $(wildcard include/config/X86_INTEL_USERCOPY) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/smap.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/extable.h \
    $(wildcard include/config/BPF_JIT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/uaccess_64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/cred.h \
    $(wildcard include/config/DEBUG_CREDENTIALS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/key.h \
    $(wildcard include/config/KEY_NOTIFICATIONS) \
    $(wildcard include/config/NET) \
    $(wildcard include/config/SYSCTL) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sysctl.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/sysctl.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/assoc_array.h \
    $(wildcard include/config/ASSOCIATIVE_ARRAY) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sched/user.h \
    $(wildcard include/config/WATCH_QUEUE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/percpu_counter.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/ratelimit.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rcu_sync.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/delayed_call.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/uuid.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/uuid.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/errseq.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/ioprio.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sched/rt.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/iocontext.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/ioprio.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/fs_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mount.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mnt_idmapping.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/fs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/quota.h \
    $(wildcard include/config/QUOTA_NETLINK_INTERFACE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/dqblk_xfs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/dqblk_v1.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/dqblk_v2.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/dqblk_qtree.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/projid.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/quota.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/nfs_fs_i.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/vfs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/statfs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/statfs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/statfs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/statfs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/slab.h \
    $(wildcard include/config/DEBUG_SLAB) \
    $(wildcard include/config/FAILSLAB) \
    $(wildcard include/config/HAVE_HARDENED_USERCOPY_ALLOCATOR) \
    $(wildcard include/config/SLAB) \
    $(wildcard include/config/SLUB) \
    $(wildcard include/config/SLOB) \
    $(wildcard include/config/CC_IS_GCC) \
    $(wildcard include/config/CLANG_VERSION) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/percpu-refcount.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kasan.h \
    $(wildcard include/config/KASAN_STACK) \
    $(wildcard include/config/KASAN_VMALLOC) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/pagemap.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mm.h \
    $(wildcard include/config/HAVE_ARCH_MMAP_RND_BITS) \
    $(wildcard include/config/HAVE_ARCH_MMAP_RND_COMPAT_BITS) \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/ARCH_USES_HIGH_VMA_FLAGS) \
    $(wildcard include/config/ARCH_HAS_PKEYS) \
    $(wildcard include/config/PPC) \
    $(wildcard include/config/PARISC) \
    $(wildcard include/config/IA64) \
    $(wildcard include/config/SPARC64) \
    $(wildcard include/config/ARM64) \
    $(wildcard include/config/ARM64_MTE) \
    $(wildcard include/config/HAVE_ARCH_USERFAULTFD_MINOR) \
    $(wildcard include/config/SHMEM) \
    $(wildcard include/config/DEV_PAGEMAP_OPS) \
    $(wildcard include/config/DEVICE_PRIVATE) \
    $(wildcard include/config/PCI_P2PDMA) \
    $(wildcard include/config/ARCH_HAS_PTE_SPECIAL) \
    $(wildcard include/config/ARCH_HAS_PTE_DEVMAP) \
    $(wildcard include/config/DEBUG_VM_RB) \
    $(wildcard include/config/PAGE_POISONING) \
    $(wildcard include/config/INIT_ON_ALLOC_DEFAULT_ON) \
    $(wildcard include/config/INIT_ON_FREE_DEFAULT_ON) \
    $(wildcard include/config/DEBUG_PAGEALLOC) \
    $(wildcard include/config/HUGETLBFS) \
    $(wildcard include/config/MAPPING_DIRTY_HELPERS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mmap_lock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/page_ext.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/stacktrace.h \
    $(wildcard include/config/STACKTRACE) \
    $(wildcard include/config/ARCH_STACKWALK) \
    $(wildcard include/config/HAVE_RELIABLE_STACKTRACE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/stackdepot.h \
    $(wildcard include/config/STACKDEPOT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/page_ref.h \
    $(wildcard include/config/DEBUG_PAGE_REF) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/memremap.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/ioport.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sizes.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/pgtable.h \
    $(wildcard include/config/HIGHPTE) \
    $(wildcard include/config/GUP_GET_PTE_LOW_HIGH) \
    $(wildcard include/config/HAVE_ARCH_TRANSPARENT_HUGEPAGE_PUD) \
    $(wildcard include/config/HAVE_ARCH_SOFT_DIRTY) \
    $(wildcard include/config/ARCH_ENABLE_THP_MIGRATION) \
    $(wildcard include/config/HAVE_ARCH_HUGE_VMAP) \
    $(wildcard include/config/X86_ESPFIX64) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/pgtable.h \
    $(wildcard include/config/DEBUG_WX) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/pkru.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/fpu/xstate.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/fpu/api.h \
    $(wildcard include/config/X86_DEBUG_FPU) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/user.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/user_64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/pgtable_uffd.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/pgtable_64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/fixmap.h \
    $(wildcard include/config/PROVIDE_OHCI1394_DMA_INIT) \
    $(wildcard include/config/X86_IO_APIC) \
    $(wildcard include/config/PCI_MMCONFIG) \
    $(wildcard include/config/ACPI_APEI_GHES) \
    $(wildcard include/config/INTEL_TXT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/vsyscall.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/fixmap.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/pgtable-invert.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/huge_mm.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sched/coredump.h \
    $(wildcard include/config/CORE_DUMP_DEFAULT_ELF_HEADERS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/vmstat.h \
    $(wildcard include/config/VM_EVENT_COUNTERS) \
    $(wildcard include/config/DEBUG_TLBFLUSH) \
    $(wildcard include/config/DEBUG_VM_VMACACHE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/vm_event_item.h \
    $(wildcard include/config/MEMORY_BALLOON) \
    $(wildcard include/config/BALLOON_COMPACTION) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/highmem.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/hardirq.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/context_tracking_state.h \
    $(wildcard include/config/CONTEXT_TRACKING) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/ftrace_irq.h \
    $(wildcard include/config/HWLAT_TRACER) \
    $(wildcard include/config/OSNOISE_TRACER) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/vtime.h \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING) \
    $(wildcard include/config/IRQ_TIME_ACCOUNTING) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/hardirq.h \
    $(wildcard include/config/KVM_INTEL) \
    $(wildcard include/config/HAVE_KVM) \
    $(wildcard include/config/X86_THERMAL_VECTOR) \
    $(wildcard include/config/X86_MCE_THRESHOLD) \
    $(wildcard include/config/X86_MCE_AMD) \
    $(wildcard include/config/X86_HV_CALLBACK_VECTOR) \
    $(wildcard include/config/HYPERV) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/cacheflush.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/cacheflush.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/highmem-internal.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/hugetlb_inline.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/squashfs_fs.h \
    $(wildcard include/config/SQUASHFS_FRAGMENT_CACHE_SIZE) \
    $(wildcard include/config/SQUASHFS_4K_DEVBLK_SIZE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/squashfs_fs_sb.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/squashfs_fs_i.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/squashfs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/shared_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/page_actor.h \
    $(wildcard include/config/SQUASHFS_FILE_DIRECT) \

/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/file_direct.o: $(deps_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/file_direct.o)

$(deps_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/file_direct.o):
