cmd_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/vkso_sq_core.mod.o := gcc -Wp,-MMD,/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/.vkso_sq_core.mod.o.d -nostdinc -isystem /usr/lib/gcc/x86_64-linux-gnu/11/include -I/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include -I./arch/x86/include/generated -I/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include -I./include -I/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi -I./arch/x86/include/generated/uapi -I/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi -I./include/generated/uapi -include /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler-version.h -include /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kconfig.h -include /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler_types.h -D__KERNEL__ -fmacro-prefix-map=/home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/= -Wall -Wundef -Werror=strict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -fshort-wchar -fno-PIE -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Wno-format-security -std=gnu89 -mno-sse -mno-mmx -mno-sse2 -mno-3dnow -mno-avx -fcf-protection=none -m64 -falign-jumps=1 -falign-loops=1 -mno-80387 -mno-fp-ret-in-387 -mpreferred-stack-boundary=3 -mskip-rax-setup -mtune=generic -mno-red-zone -mcmodel=kernel -Wno-sign-compare -fno-asynchronous-unwind-tables -mindirect-branch=thunk-extern -mindirect-branch-register -mindirect-branch-cs-prefix -mfunction-return=thunk-extern -fno-jump-tables -mharden-sls=all -fno-delete-null-pointer-checks -Wno-frame-address -Wno-format-truncation -Wno-format-overflow -Wno-address-of-packed-member -O2 -fno-allow-store-data-races -Wframe-larger-than=1024 -fstack-protector-strong -Wimplicit-fallthrough=5 -Wno-main -Wno-unused-but-set-variable -Wno-unused-const-variable -fno-omit-frame-pointer -fno-optimize-sibling-calls -fno-stack-clash-protection -falign-functions=16 -Wdeclaration-after-statement -Wvla -Wno-pointer-sign -Wno-stringop-truncation -Wno-zero-length-bounds -Wno-array-bounds -Wno-stringop-overflow -Wno-restrict -Wno-maybe-uninitialized -Wno-alloc-size-larger-than -fno-strict-overflow -fno-stack-check -fconserve-stack -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -fno-builtin-wcslen -Wno-packed-not-aligned -DMODULE -DKBUILD_BASENAME='"vkso_sq_core.mod"' -DKBUILD_MODNAME='"vkso_sq_core"' -D__KBUILD_MODNAME=kmod_vkso_sq_core -c -o /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/vkso_sq_core.mod.o /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/vkso_sq_core.mod.c

source_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/vkso_sq_core.mod.o := /home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/vkso_sq_core.mod.c

deps_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/vkso_sq_core.mod.o := \
    $(wildcard include/config/MODULE_UNLOAD) \
    $(wildcard include/config/RETPOLINE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler_types.h \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler_attributes.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler-gcc.h \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/KCOV) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/module.h \
    $(wildcard include/config/MODULES) \
    $(wildcard include/config/SYSFS) \
    $(wildcard include/config/MODULES_TREE_LOOKUP) \
    $(wildcard include/config/LIVEPATCH) \
    $(wildcard include/config/STACKTRACE_BUILD_ID) \
    $(wildcard include/config/CFI_CLANG) \
    $(wildcard include/config/MODULE_SIG) \
    $(wildcard include/config/GENERIC_BUG) \
    $(wildcard include/config/KALLSYMS) \
    $(wildcard include/config/SMP) \
    $(wildcard include/config/TRACEPOINTS) \
    $(wildcard include/config/TREE_SRCU) \
    $(wildcard include/config/BPF_EVENTS) \
    $(wildcard include/config/DEBUG_INFO_BTF_MODULES) \
    $(wildcard include/config/JUMP_LABEL) \
    $(wildcard include/config/TRACING) \
    $(wildcard include/config/EVENT_TRACING) \
    $(wildcard include/config/FTRACE_MCOUNT_RECORD) \
    $(wildcard include/config/KPROBES) \
    $(wildcard include/config/HAVE_STATIC_CALL_INLINE) \
    $(wildcard include/config/PRINTK_INDEX) \
    $(wildcard include/config/MITIGATION_ITS) \
    $(wildcard include/config/CONSTRUCTORS) \
    $(wildcard include/config/FUNCTION_ERROR_INJECTION) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/list.h \
    $(wildcard include/config/DEBUG_LIST) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/types.h \
  arch/x86/include/generated/uapi/asm/types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/int-ll64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/int-ll64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/bitsperlong.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitsperlong.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/bitsperlong.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/posix_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/stddef.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/stddef.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/posix_types.h \
    $(wildcard include/config/X86_32) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/posix_types_64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/posix_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/poison.h \
    $(wildcard include/config/ILLEGAL_POINTER_VALUE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/const.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/const.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/const.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kernel.h \
    $(wildcard include/config/PREEMPT_VOLUNTARY) \
    $(wildcard include/config/PREEMPT_DYNAMIC) \
    $(wildcard include/config/PREEMPT_) \
    $(wildcard include/config/DEBUG_ATOMIC_SLEEP) \
    $(wildcard include/config/MMU) \
    $(wildcard include/config/PROVE_LOCKING) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/stdarg.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/align.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/array_size.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/compiler.h \
    $(wildcard include/config/TRACE_BRANCH_PROFILING) \
    $(wildcard include/config/PROFILE_ALL_BRANCHES) \
    $(wildcard include/config/STACK_VALIDATION) \
  arch/x86/include/generated/asm/rwonce.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/rwonce.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kasan-checks.h \
    $(wildcard include/config/KASAN_GENERIC) \
    $(wildcard include/config/KASAN_SW_TAGS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kcsan-checks.h \
    $(wildcard include/config/KCSAN) \
    $(wildcard include/config/KCSAN_IGNORE_ATOMICS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/limits.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/limits.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/limits.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/linkage.h \
    $(wildcard include/config/FUNCTION_ALIGNMENT) \
    $(wildcard include/config/ARCH_USE_SYM_ANNOTATIONS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/stringify.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/export.h \
    $(wildcard include/config/MODVERSIONS) \
    $(wildcard include/config/MODULE_REL_CRCS) \
    $(wildcard include/config/HAVE_ARCH_PREL32_RELOCATIONS) \
    $(wildcard include/config/TRIM_UNUSED_KSYMS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/linkage.h \
    $(wildcard include/config/RETHUNK) \
    $(wildcard include/config/SLS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/bitops.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/bits.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/bits.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/build_bug.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/typecheck.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/kernel.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/sysinfo.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/bitops.h \
    $(wildcard include/config/X86_64) \
    $(wildcard include/config/X86_CMOV) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/alternative.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/asm.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/extable_fixup_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/bug.h \
    $(wildcard include/config/DEBUG_BUGVERBOSE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/instrumentation.h \
    $(wildcard include/config/DEBUG_ENTRY) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bug.h \
    $(wildcard include/config/BUG) \
    $(wildcard include/config/GENERIC_BUG_RELATIVE_POINTERS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/once_lite.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/panic.h \
    $(wildcard include/config/PANIC_TIMEOUT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/printk.h \
    $(wildcard include/config/MESSAGE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_QUIET) \
    $(wildcard include/config/EARLY_PRINTK) \
    $(wildcard include/config/PRINTK) \
    $(wildcard include/config/DYNAMIC_DEBUG) \
    $(wildcard include/config/DYNAMIC_DEBUG_CORE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/init.h \
    $(wildcard include/config/STRICT_KERNEL_RWX) \
    $(wildcard include/config/STRICT_MODULE_RWX) \
    $(wildcard include/config/LTO_CLANG) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kern_levels.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/cache.h \
    $(wildcard include/config/ARCH_HAS_CACHE_LINE_SIZE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/cache.h \
    $(wildcard include/config/X86_L1_CACHE_SHIFT) \
    $(wildcard include/config/X86_INTERNODE_CACHE_SHIFT) \
    $(wildcard include/config/X86_VSMP) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/ratelimit_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/param.h \
  arch/x86/include/generated/uapi/asm/param.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/param.h \
    $(wildcard include/config/HZ) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/param.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/spinlock_types.h \
    $(wildcard include/config/PREEMPT_RT) \
    $(wildcard include/config/DEBUG_LOCK_ALLOC) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/spinlock_types_raw.h \
    $(wildcard include/config/DEBUG_SPINLOCK) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/spinlock_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/qspinlock_types.h \
    $(wildcard include/config/NR_CPUS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/qrwlock_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/byteorder.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/byteorder/little_endian.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/byteorder/little_endian.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/swab.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/swab.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/swab.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/byteorder/generic.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/lockdep_types.h \
    $(wildcard include/config/PROVE_RAW_LOCK_NESTING) \
    $(wildcard include/config/PREEMPT_LOCK) \
    $(wildcard include/config/LOCKDEP) \
    $(wildcard include/config/LOCK_STAT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rwlock_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/dynamic_debug.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/jump_label.h \
    $(wildcard include/config/HAVE_ARCH_JUMP_LABEL_RELATIVE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/jump_label.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/nops.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/rmwcc.h \
    $(wildcard include/config/CC_HAS_ASM_GOTO) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/barrier.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/barrier.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/find.h \
    $(wildcard include/config/GENERIC_FIND_FIRST_BIT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/sched.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/arch_hweight.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/cpufeatures.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/required-features.h \
    $(wildcard include/config/X86_MINIMUM_CPU_FAMILY) \
    $(wildcard include/config/MATH_EMULATION) \
    $(wildcard include/config/X86_PAE) \
    $(wildcard include/config/X86_CMPXCHG64) \
    $(wildcard include/config/X86_USE_3DNOW) \
    $(wildcard include/config/X86_P6_NOP) \
    $(wildcard include/config/MATOM) \
    $(wildcard include/config/PARAVIRT_XXL) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/disabled-features.h \
    $(wildcard include/config/X86_SMAP) \
    $(wildcard include/config/X86_UMIP) \
    $(wildcard include/config/X86_INTEL_MEMORY_PROTECTION_KEYS) \
    $(wildcard include/config/X86_5LEVEL) \
    $(wildcard include/config/PAGE_TABLE_ISOLATION) \
    $(wildcard include/config/CPU_UNRET_ENTRY) \
    $(wildcard include/config/X86_SGX) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/const_hweight.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/instrumented-atomic.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/instrumented.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/instrumented-non-atomic.h \
    $(wildcard include/config/KCSAN_ASSUME_PLAIN_WRITES_ATOMIC) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/instrumented-lock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/le.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kstrtox.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/log2.h \
    $(wildcard include/config/ARCH_HAS_ILOG2_U32) \
    $(wildcard include/config/ARCH_HAS_ILOG2_U64) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/math.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/div64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/div64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/minmax.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/static_call_types.h \
    $(wildcard include/config/HAVE_STATIC_CALL) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/stat.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/stat.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/stat.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/time.h \
    $(wildcard include/config/POSIX_TIMERS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/math64.h \
    $(wildcard include/config/ARCH_SUPPORTS_INT128) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/math64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/time64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/time64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/time.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/time_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/time32.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/timex.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/timex.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/timex.h \
    $(wildcard include/config/X86_TSC) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/processor.h \
    $(wildcard include/config/X86_VMX_FEATURE_NAMES) \
    $(wildcard include/config/X86_IOPL_IOPERM) \
    $(wildcard include/config/STACKPROTECTOR) \
    $(wildcard include/config/VM86) \
    $(wildcard include/config/X86_DEBUGCTLMSR) \
    $(wildcard include/config/CPU_SUP_AMD) \
    $(wildcard include/config/XEN) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/processor-flags.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/processor-flags.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mem_encrypt.h \
    $(wildcard include/config/ARCH_HAS_MEM_ENCRYPT) \
    $(wildcard include/config/AMD_MEM_ENCRYPT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/mem_encrypt.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/cc_platform.h \
    $(wildcard include/config/ARCH_HAS_CC_PLATFORM) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/bootparam.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/screen_info.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/screen_info.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/apm_bios.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/apm_bios.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/ioctl.h \
  arch/x86/include/generated/uapi/asm/ioctl.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/ioctl.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/ioctl.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/edd.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/edd.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/ist.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/ist.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/video/edid.h \
    $(wildcard include/config/X86) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/video/edid.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/math_emu.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/ptrace.h \
    $(wildcard include/config/PARAVIRT) \
    $(wildcard include/config/IA32_EMULATION) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/segment.h \
    $(wildcard include/config/XEN_PV) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/page_types.h \
    $(wildcard include/config/PHYSICAL_START) \
    $(wildcard include/config/PHYSICAL_ALIGN) \
    $(wildcard include/config/DYNAMIC_PHYSICAL_MASK) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/page_64_types.h \
    $(wildcard include/config/KASAN) \
    $(wildcard include/config/DYNAMIC_MEMORY_LAYOUT) \
    $(wildcard include/config/RANDOMIZE_BASE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/kaslr.h \
    $(wildcard include/config/RANDOMIZE_MEMORY) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/ptrace.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/ptrace-abi.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/paravirt_types.h \
    $(wildcard include/config/PGTABLE_LEVELS) \
    $(wildcard include/config/PARAVIRT_DEBUG) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/desc_defs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/pgtable_types.h \
    $(wildcard include/config/MEM_SOFT_DIRTY) \
    $(wildcard include/config/HAVE_ARCH_USERFAULTFD_WP) \
    $(wildcard include/config/PROC_FS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/pgtable_64_types.h \
    $(wildcard include/config/DEBUG_KMAP_LOCAL_FORCE_MAP) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/sparsemem.h \
    $(wildcard include/config/SPARSEMEM) \
    $(wildcard include/config/NUMA_KEEP_MEMINFO) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/nospec-branch.h \
    $(wildcard include/config/CPU_SRSO) \
    $(wildcard include/config/CPU_IBPB_ENTRY) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/static_key.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/objtool.h \
    $(wildcard include/config/FRAME_POINTER) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/msr-index.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/unwind_hints.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/orc_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/percpu.h \
    $(wildcard include/config/X86_64_SMP) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/percpu.h \
    $(wildcard include/config/DEBUG_PREEMPT) \
    $(wildcard include/config/HAVE_SETUP_PER_CPU_AREA) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/threads.h \
    $(wildcard include/config/BASE_SMALL) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/percpu-defs.h \
    $(wildcard include/config/DEBUG_FORCE_WEAK_PER_CPU) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/GEN-for-each-reg.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/proto.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/ldt.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/sigcontext.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/current.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/page.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/page_64.h \
    $(wildcard include/config/DEBUG_VIRTUAL) \
    $(wildcard include/config/FLATMEM) \
    $(wildcard include/config/X86_VSYSCALL_EMULATION) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/range.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/memory_model.h \
    $(wildcard include/config/SPARSEMEM_VMEMMAP) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/pfn.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/getorder.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/msr.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/msr-index.h \
  arch/x86/include/generated/uapi/asm/errno.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/errno.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/errno-base.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/cpumask.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/cpumask.h \
    $(wildcard include/config/CPUMASK_OFFSTACK) \
    $(wildcard include/config/HOTPLUG_CPU) \
    $(wildcard include/config/DEBUG_PER_CPU_MAPS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/bitmap.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/string.h \
    $(wildcard include/config/BINARY_PRINTF) \
    $(wildcard include/config/FORTIFY_SOURCE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/err.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/errno.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/errno.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/overflow.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/string.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/string.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/string_64.h \
    $(wildcard include/config/ARCH_HAS_UACCESS_FLUSHCACHE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/fortify-string.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/atomic.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/atomic.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/cmpxchg.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/cmpxchg_64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/atomic64_64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/atomic/atomic-arch-fallback.h \
    $(wildcard include/config/GENERIC_ATOMIC64) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/atomic/atomic-long.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/atomic/atomic-instrumented.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/bug.h \
    $(wildcard include/config/BUG_ON_DATA_CORRUPTION) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/msr.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/tracepoint-defs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/paravirt.h \
    $(wildcard include/config/PARAVIRT_SPINLOCKS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/frame.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/special_insns.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/irqflags.h \
    $(wildcard include/config/TRACE_IRQFLAGS) \
    $(wildcard include/config/IRQSOFF_TRACER) \
    $(wildcard include/config/PREEMPT_TRACER) \
    $(wildcard include/config/DEBUG_IRQFLAGS) \
    $(wildcard include/config/TRACE_IRQFLAGS_SUPPORT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/cleanup.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/irqflags.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/fpu/types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/vmxfeatures.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/vdso/processor.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/personality.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/personality.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/tsc.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/cpufeature.h \
    $(wildcard include/config/X86_FEATURE_NAMES) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/time32.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/time.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/uidgid.h \
    $(wildcard include/config/MULTIUSER) \
    $(wildcard include/config/USER_NS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/highuid.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/buildid.h \
    $(wildcard include/config/CRASH_CORE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mm_types.h \
    $(wildcard include/config/HAVE_ALIGNED_STRUCT_PAGE) \
    $(wildcard include/config/ARCH_WANT_HUGE_PMD_SHARE) \
    $(wildcard include/config/MEMCG) \
    $(wildcard include/config/USERFAULTFD) \
    $(wildcard include/config/SWAP) \
    $(wildcard include/config/NUMA) \
    $(wildcard include/config/HAVE_ARCH_COMPAT_MMAP_BASES) \
    $(wildcard include/config/MEMBARRIER) \
    $(wildcard include/config/AIO) \
    $(wildcard include/config/MMU_NOTIFIER) \
    $(wildcard include/config/TRANSPARENT_HUGEPAGE) \
    $(wildcard include/config/NUMA_BALANCING) \
    $(wildcard include/config/ARCH_WANT_BATCHED_UNMAP_TLB_FLUSH) \
    $(wildcard include/config/HUGETLB_PAGE) \
    $(wildcard include/config/IOMMU_SUPPORT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mm_types_task.h \
    $(wildcard include/config/SPLIT_PTLOCK_CPUS) \
    $(wildcard include/config/ARCH_ENABLE_SPLIT_PMD_PTLOCK) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/tlbbatch.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/auxvec.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/auxvec.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/auxvec.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/spinlock.h \
    $(wildcard include/config/PREEMPTION) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/preempt.h \
    $(wildcard include/config/PREEMPT_COUNT) \
    $(wildcard include/config/TRACE_PREEMPT_TOGGLE) \
    $(wildcard include/config/PREEMPT_NOTIFIERS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/preempt.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/thread_info.h \
    $(wildcard include/config/THREAD_INFO_IN_TASK) \
    $(wildcard include/config/GENERIC_ENTRY) \
    $(wildcard include/config/HAVE_ARCH_WITHIN_STACK_FRAMES) \
    $(wildcard include/config/HARDENED_USERCOPY) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/restart_block.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/thread_info.h \
    $(wildcard include/config/COMPAT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/bottom_half.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/lockdep.h \
    $(wildcard include/config/DEBUG_LOCKING_API_SELFTESTS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/smp.h \
    $(wildcard include/config/UP_LATE_INIT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/smp_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/llist.h \
    $(wildcard include/config/ARCH_HAVE_NMI_SAFE_CMPXCHG) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/smp.h \
    $(wildcard include/config/X86_LOCAL_APIC) \
    $(wildcard include/config/DEBUG_NMI_SELFTEST) \
  arch/x86/include/generated/asm/mmiowb.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/mmiowb.h \
    $(wildcard include/config/MMIOWB) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/spinlock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/qspinlock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/qspinlock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/qrwlock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/qrwlock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rwlock.h \
    $(wildcard include/config/PREEMPT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/spinlock_api_smp.h \
    $(wildcard include/config/INLINE_SPIN_LOCK) \
    $(wildcard include/config/INLINE_SPIN_LOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK_BH) \
    $(wildcard include/config/UNINLINE_SPIN_UNLOCK) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/GENERIC_LOCKBREAK) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rwlock_api_smp.h \
    $(wildcard include/config/INLINE_READ_LOCK) \
    $(wildcard include/config/INLINE_WRITE_LOCK) \
    $(wildcard include/config/INLINE_READ_LOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_LOCK_BH) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_READ_TRYLOCK) \
    $(wildcard include/config/INLINE_WRITE_TRYLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_BH) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQRESTORE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rbtree.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rbtree_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rcupdate.h \
    $(wildcard include/config/PREEMPT_RCU) \
    $(wildcard include/config/TINY_RCU) \
    $(wildcard include/config/TASKS_RCU_GENERIC) \
    $(wildcard include/config/RCU_STALL_COMMON) \
    $(wildcard include/config/NO_HZ_FULL) \
    $(wildcard include/config/RCU_NOCB_CPU) \
    $(wildcard include/config/TASKS_RCU) \
    $(wildcard include/config/TASKS_TRACE_RCU) \
    $(wildcard include/config/TASKS_RUDE_RCU) \
    $(wildcard include/config/TREE_RCU) \
    $(wildcard include/config/DEBUG_OBJECTS_RCU_HEAD) \
    $(wildcard include/config/PROVE_RCU) \
    $(wildcard include/config/ARCH_WEAK_RELEASE_ACQUIRE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rcutree.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rwsem.h \
    $(wildcard include/config/RWSEM_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_RWSEMS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/osq_lock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/completion.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/swait.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/wait.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/wait.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/uprobes.h \
    $(wildcard include/config/UPROBES) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/page-flags-layout.h \
    $(wildcard include/config/KASAN_HW_TAGS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/numa.h \
    $(wildcard include/config/NODES_SHIFT) \
  include/generated/bounds.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/workqueue.h \
    $(wildcard include/config/DEBUG_OBJECTS_WORK) \
    $(wildcard include/config/FREEZER) \
    $(wildcard include/config/WQ_WATCHDOG) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/timer.h \
    $(wildcard include/config/DEBUG_OBJECTS_TIMERS) \
    $(wildcard include/config/NO_HZ_COMMON) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/ktime.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/jiffies.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/jiffies.h \
  include/generated/timeconst.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/vdso/ktime.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/timekeeping.h \
    $(wildcard include/config/GENERIC_CMOS_UPDATE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/clocksource_ids.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/debugobjects.h \
    $(wildcard include/config/DEBUG_OBJECTS) \
    $(wildcard include/config/DEBUG_OBJECTS_FREE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/seqlock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mutex.h \
    $(wildcard include/config/MUTEX_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_MUTEXES) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/debug_locks.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/ww_mutex.h \
    $(wildcard include/config/DEBUG_RT_MUTEXES) \
    $(wildcard include/config/DEBUG_WW_MUTEX_SLOWPATH) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rtmutex.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/mmu.h \
    $(wildcard include/config/MODIFY_LDT_SYSCALL) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kmod.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/umh.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/gfp.h \
    $(wildcard include/config/HIGHMEM) \
    $(wildcard include/config/ZONE_DMA) \
    $(wildcard include/config/ZONE_DMA32) \
    $(wildcard include/config/ZONE_DEVICE) \
    $(wildcard include/config/COMPACTION) \
    $(wildcard include/config/PM_SLEEP) \
    $(wildcard include/config/CONTIG_ALLOC) \
    $(wildcard include/config/CMA) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mmdebug.h \
    $(wildcard include/config/DEBUG_VM) \
    $(wildcard include/config/DEBUG_VM_PGFLAGS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/mmzone.h \
    $(wildcard include/config/FORCE_MAX_ZONEORDER) \
    $(wildcard include/config/MEMORY_ISOLATION) \
    $(wildcard include/config/ZSMALLOC) \
    $(wildcard include/config/SHADOW_CALL_STACK) \
    $(wildcard include/config/MEMORY_HOTPLUG) \
    $(wildcard include/config/PAGE_EXTENSION) \
    $(wildcard include/config/DEFERRED_STRUCT_PAGE_INIT) \
    $(wildcard include/config/HAVE_MEMORYLESS_NODES) \
    $(wildcard include/config/SPARSEMEM_EXTREME) \
    $(wildcard include/config/HAVE_ARCH_PFN_VALID) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/nodemask.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/pageblock-flags.h \
    $(wildcard include/config/HUGETLB_PAGE_SIZE_VARIABLE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/page-flags.h \
    $(wildcard include/config/ARCH_USES_PG_UNCACHED) \
    $(wildcard include/config/MEMORY_FAILURE) \
    $(wildcard include/config/PAGE_IDLE_FLAG) \
    $(wildcard include/config/THP_SWAP) \
    $(wildcard include/config/KSM) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/local_lock.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/local_lock_internal.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/memory_hotplug.h \
    $(wildcard include/config/ARCH_HAS_ADD_PAGES) \
    $(wildcard include/config/HAVE_ARCH_NODEDATA_EXTENSION) \
    $(wildcard include/config/MEMORY_HOTREMOVE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/notifier.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/srcu.h \
    $(wildcard include/config/TINY_SRCU) \
    $(wildcard include/config/SRCU) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rcu_segcblist.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/srcutree.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rcu_node_tree.h \
    $(wildcard include/config/RCU_FANOUT) \
    $(wildcard include/config/RCU_FANOUT_LEAF) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/mmzone.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/mmzone_64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/topology.h \
    $(wildcard include/config/USE_PERCPU_NUMA_NODE_ID) \
    $(wildcard include/config/SCHED_SMT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/arch_topology.h \
    $(wildcard include/config/GENERIC_ARCH_TOPOLOGY) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/percpu.h \
    $(wildcard include/config/NEED_PER_CPU_EMBED_FIRST_CHUNK) \
    $(wildcard include/config/NEED_PER_CPU_PAGE_FIRST_CHUNK) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/topology.h \
    $(wildcard include/config/SCHED_MC_PRIO) \
    $(wildcard include/config/ACPI_CPPC_LIB) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/mpspec.h \
    $(wildcard include/config/EISA) \
    $(wildcard include/config/X86_MPPARSE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/mpspec_def.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/x86_init.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/apicdef.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/topology.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sysctl.h \
    $(wildcard include/config/SYSCTL) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/sysctl.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/elf.h \
    $(wildcard include/config/ARCH_USE_GNU_PROPERTY) \
    $(wildcard include/config/ARCH_HAVE_ELF_PROT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/elf.h \
    $(wildcard include/config/X86_X32_ABI) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/user.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/user_64.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/fsgsbase.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/vdso.h \
    $(wildcard include/config/X86_X32) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/elf.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/elf-em.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kobject.h \
    $(wildcard include/config/UEVENT_HELPER) \
    $(wildcard include/config/DEBUG_KOBJECT_RELEASE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sysfs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kernfs.h \
    $(wildcard include/config/KERNFS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/idr.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/radix-tree.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/xarray.h \
    $(wildcard include/config/XARRAY_MULTI) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kconfig.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sched/mm.h \
    $(wildcard include/config/ARCH_HAS_MEMBARRIER_CALLBACKS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sched.h \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING_NATIVE) \
    $(wildcard include/config/SCHED_INFO) \
    $(wildcard include/config/SCHEDSTATS) \
    $(wildcard include/config/FAIR_GROUP_SCHED) \
    $(wildcard include/config/RT_GROUP_SCHED) \
    $(wildcard include/config/RT_MUTEXES) \
    $(wildcard include/config/UCLAMP_TASK) \
    $(wildcard include/config/UCLAMP_BUCKETS_COUNT) \
    $(wildcard include/config/KMAP_LOCAL) \
    $(wildcard include/config/SCHED_CORE) \
    $(wildcard include/config/CGROUP_SCHED) \
    $(wildcard include/config/BLK_DEV_IO_TRACE) \
    $(wildcard include/config/COMPAT_BRK) \
    $(wildcard include/config/CGROUPS) \
    $(wildcard include/config/BLK_CGROUP) \
    $(wildcard include/config/PSI) \
    $(wildcard include/config/PAGE_OWNER) \
    $(wildcard include/config/EVENTFD) \
    $(wildcard include/config/ARCH_HAS_SCALED_CPUTIME) \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING_GEN) \
    $(wildcard include/config/POSIX_CPUTIMERS) \
    $(wildcard include/config/POSIX_CPU_TIMERS_TASK_WORK) \
    $(wildcard include/config/KEYS) \
    $(wildcard include/config/SYSVIPC) \
    $(wildcard include/config/DETECT_HUNG_TASK) \
    $(wildcard include/config/IO_URING) \
    $(wildcard include/config/AUDIT) \
    $(wildcard include/config/AUDITSYSCALL) \
    $(wildcard include/config/UBSAN) \
    $(wildcard include/config/UBSAN_TRAP) \
    $(wildcard include/config/BLOCK) \
    $(wildcard include/config/TASK_XACCT) \
    $(wildcard include/config/CPUSETS) \
    $(wildcard include/config/X86_CPU_RESCTRL) \
    $(wildcard include/config/FUTEX) \
    $(wildcard include/config/PERF_EVENTS) \
    $(wildcard include/config/RSEQ) \
    $(wildcard include/config/TASK_DELAY_ACCT) \
    $(wildcard include/config/FAULT_INJECTION) \
    $(wildcard include/config/LATENCYTOP) \
    $(wildcard include/config/KUNIT) \
    $(wildcard include/config/FUNCTION_GRAPH_TRACER) \
    $(wildcard include/config/BCACHE) \
    $(wildcard include/config/VMAP_STACK) \
    $(wildcard include/config/SECURITY) \
    $(wildcard include/config/BPF_SYSCALL) \
    $(wildcard include/config/GCC_PLUGIN_STACKLEAK) \
    $(wildcard include/config/X86_MCE) \
    $(wildcard include/config/KRETPROBES) \
    $(wildcard include/config/ARCH_HAS_PARANOID_L1D_FLUSH) \
    $(wildcard include/config/ARCH_TASK_STRUCT_ON_STACK) \
    $(wildcard include/config/DEBUG_RSEQ) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/sched.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/pid.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rculist.h \
    $(wildcard include/config/PROVE_RCU_LIST) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/refcount.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sem.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/sem.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/ipc.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rhashtable-types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/ipc.h \
  arch/x86/include/generated/uapi/asm/ipcbuf.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/ipcbuf.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/sembuf.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/shm.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/shm.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/hugetlb_encode.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/shmbuf.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/shmbuf.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/shmparam.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/plist.h \
    $(wildcard include/config/DEBUG_PLIST) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/hrtimer.h \
    $(wildcard include/config/HIGH_RES_TIMERS) \
    $(wildcard include/config/TIME_LOW_RES) \
    $(wildcard include/config/TIMERFD) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/hrtimer_defs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/timerqueue.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/seccomp.h \
    $(wildcard include/config/SECCOMP) \
    $(wildcard include/config/HAVE_ARCH_SECCOMP_FILTER) \
    $(wildcard include/config/SECCOMP_FILTER) \
    $(wildcard include/config/CHECKPOINT_RESTORE) \
    $(wildcard include/config/SECCOMP_CACHE_DEBUG) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/seccomp.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/seccomp.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/unistd.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/unistd.h \
  arch/x86/include/generated/uapi/asm/unistd_64.h \
  arch/x86/include/generated/asm/unistd_64_x32.h \
  arch/x86/include/generated/asm/unistd_32_ia32.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/seccomp.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/unistd.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/resource.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/resource.h \
  arch/x86/include/generated/uapi/asm/resource.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/resource.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/resource.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/latencytop.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sched/prio.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sched/types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/signal_types.h \
    $(wildcard include/config/OLD_SIGACTION) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/signal.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/signal.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/signal.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/signal-defs.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/uapi/asm/siginfo.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/asm-generic/siginfo.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/syscall_user_dispatch.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/task_io_accounting.h \
    $(wildcard include/config/TASK_IO_ACCOUNTING) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/posix-timers.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/alarmtimer.h \
    $(wildcard include/config/RTC_CLASS) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/task_work.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/uapi/linux/rseq.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kcsan.h \
  arch/x86/include/generated/asm/kmap_size.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/kmap_size.h \
    $(wildcard include/config/DEBUG_KMAP_LOCAL) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/sync_core.h \
    $(wildcard include/config/ARCH_HAS_SYNC_CORE_BEFORE_USERMODE) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/sync_core.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kobject_ns.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/kref.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/moduleparam.h \
    $(wildcard include/config/ALPHA) \
    $(wildcard include/config/IA64) \
    $(wildcard include/config/PPC64) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/rbtree_latch.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/error-injection.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/error-injection.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/cfi.h \
    $(wildcard include/config/CFI_CLANG_SHADOW) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/module.h \
    $(wildcard include/config/UNWINDER_ORC) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/asm-generic/module.h \
    $(wildcard include/config/HAVE_MOD_ARCH_SPECIFIC) \
    $(wildcard include/config/MODULES_USE_ELF_REL) \
    $(wildcard include/config/MODULES_USE_ELF_RELA) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/orc_types.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/build-salt.h \
    $(wildcard include/config/BUILD_SALT) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/elfnote.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/elfnote-lto.h \
    $(wildcard include/config/LTO) \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/include/linux/vermagic.h \
  include/generated/utsrelease.h \
  /home/zzk/BinaryKernelCodeMapping/test/section65/build/native/linux-5.15.198/arch/x86/include/asm/vermagic.h \
    $(wildcard include/config/M486SX) \
    $(wildcard include/config/M486) \
    $(wildcard include/config/M586) \
    $(wildcard include/config/M586TSC) \
    $(wildcard include/config/M586MMX) \
    $(wildcard include/config/MCORE2) \
    $(wildcard include/config/M686) \
    $(wildcard include/config/MPENTIUMII) \
    $(wildcard include/config/MPENTIUMIII) \
    $(wildcard include/config/MPENTIUMM) \
    $(wildcard include/config/MPENTIUM4) \
    $(wildcard include/config/MK6) \
    $(wildcard include/config/MK7) \
    $(wildcard include/config/MK8) \
    $(wildcard include/config/MELAN) \
    $(wildcard include/config/MCRUSOE) \
    $(wildcard include/config/MEFFICEON) \
    $(wildcard include/config/MWINCHIPC6) \
    $(wildcard include/config/MWINCHIP3D) \
    $(wildcard include/config/MCYRIXIII) \
    $(wildcard include/config/MVIAC3_2) \
    $(wildcard include/config/MVIAC7) \
    $(wildcard include/config/MGEODEGX1) \
    $(wildcard include/config/MGEODE_LX) \

/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/vkso_sq_core.mod.o: $(deps_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/vkso_sq_core.mod.o)

$(deps_/home/zzk/BinaryKernelCodeMapping/test/section65/build/squashfs/optimization-cache-01/vkso_sq_core.mod.o):
