// SPDX-License-Identifier: GPL-2.0-or-later
/* Linux 5.15.198 SquashFS functions; original notices retained in generated source files. */
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/blkdev.h>
#include <linux/bio.h>
#include <linux/fs_context.h>
#include <linux/pagemap.h>
#include <linux/magic.h>
#include <linux/xattr.h>
#include "squashfs_fs.h"
#include "squashfs_fs_sb.h"
#include "squashfs_fs_i.h"
#include "squashfs.h"
#include "decompressor.h"
#include "page_actor.h"
#include "xattr.h"
#include "owner.h"
struct sq_support sq_support;
VKSO_DECLARE_OWNER(sq_owner);
static int __init core_init(void) { return vkso_initialize_owner(&sq_owner); }
static void __exit core_exit(void) { }
module_init(core_init);
module_exit(core_exit);
MODULE_LICENSE("GPL");
MODULE_VERSION("1");
EXPORT_SYMBOL_GPL(sq_bind_support);
EXPORT_SYMBOL_GPL(sq_support_address);
EXPORT_SYMBOL_GPL(squashfs_fill_super);
EXPORT_SYMBOL_GPL(squashfs_read_inode);
EXPORT_SYMBOL_GPL(squashfs_lookup);
EXPORT_SYMBOL_GPL(squashfs_readdir);
EXPORT_SYMBOL_GPL(read_blocklist);
EXPORT_SYMBOL_GPL(squashfs_copy_data);
EXPORT_SYMBOL_GPL(squashfs_read_metadata);
EXPORT_SYMBOL_GPL(squashfs_get_fragment);
EXPORT_SYMBOL_GPL(squashfs_get_datablock);
EXPORT_SYMBOL_GPL(squashfs_read_table);
EXPORT_SYMBOL_GPL(squashfs_frag_lookup);
EXPORT_SYMBOL_GPL(squashfs_read_fragment_index_table);
EXPORT_SYMBOL_GPL(squashfs_get_id);
EXPORT_SYMBOL_GPL(squashfs_read_id_index_table);
EXPORT_SYMBOL_GPL(squashfs_read_inode_lookup_table);
EXPORT_SYMBOL_GPL(squashfs_xattr_lookup);
EXPORT_SYMBOL_GPL(squashfs_read_xattr_id_table);
EXPORT_SYMBOL_GPL(squashfs_read_data);
EXPORT_SYMBOL_GPL(squashfs_decompressor_setup);
EXPORT_SYMBOL_GPL(squashfs_xz_comp_opts);
EXPORT_SYMBOL_GPL(lz4_comp_opts);
EXPORT_SYMBOL_GPL(squashfs_listxattr);
EXPORT_SYMBOL_GPL(squashfs_xattr_get);

extern int vkso_LZ4_decompress_safe(const char *,char *,int,int);
extern void sq_bind_lz4(void *(*)(void *,const void *,size_t),
                        void *(*)(void *,const void *,size_t),
                        void *(*)(void *,int,size_t));
EXPORT_SYMBOL_GPL(vkso_LZ4_decompress_safe);
EXPORT_SYMBOL_GPL(sq_bind_lz4);

#include "xz_services.h"
EXPORT_SYMBOL_GPL(vkso_xz_dec_init);
EXPORT_SYMBOL_GPL(vkso_xz_dec_reset);
EXPORT_SYMBOL_GPL(vkso_xz_dec_run);
EXPORT_SYMBOL_GPL(vkso_xz_dec_end);
EXPORT_SYMBOL_GPL(sq_bind_xz);
EXPORT_SYMBOL_GPL(sq_xz_support_address);
