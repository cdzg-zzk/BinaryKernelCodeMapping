#ifndef SQ_SHARED_TYPES_H
#define SQ_SHARED_TYPES_H
struct fs_context;
struct bio;
struct squashfs_decompressor;
enum Opt_errors {
	Opt_errors_continue,
	Opt_errors_panic,
};
struct squashfs_mount_opts {
	enum Opt_errors errors;
};
struct sq_support {
    void * (*alloc)(size_t, gfp_t);
    void * (*alloc_array)(size_t, size_t, gfp_t);
    void (*free)(const void *);
    void (*mutex_init)(struct mutex *);
    void (*mutex_lock)(struct mutex *);
    void (*mutex_unlock)(struct mutex *);
    struct squashfs_cache * (*cache_init)(char *, int, int);
    void (*cache_delete)(struct squashfs_cache *);
    struct squashfs_cache_entry * (*cache_get)(struct super_block *, struct squashfs_cache *, u64, int);
    void (*cache_put)(struct squashfs_cache_entry *);
    struct squashfs_page_actor * (*actor_init)(void **, int, int);
    struct inode * (*iget)(struct super_block *, long long, unsigned int);
    struct inode * (*new_inode)(struct super_block *);
    void (*bad_inode)(struct inode *);
    void (*insert_inode)(struct inode *);
    void (*iput)(struct inode *);
    void (*nlink)(struct inode *, unsigned int);
    void (*uid)(struct inode *, uid_t);
    void (*gid)(struct inode *, gid_t);
    void (*special_inode)(struct inode *, umode_t, dev_t);
    void (*nohighmem)(struct inode *);
    int (*blocksize)(struct super_block *, int);
    loff_t (*device_size)(struct super_block *);
    struct dentry * (*make_root)(struct inode *);
    struct dentry * (*splice_alias)(struct inode *, struct dentry *);
    const struct squashfs_decompressor * (*lookup_decompressor)(int);
    int (*max_decompressors)(void);
    void * (*decompressor_create)(struct squashfs_sb_info *, void *);
    void (*decompressor_destroy)(struct squashfs_sb_info *);
    int (*read_raw)(struct super_block *, u64, int, struct bio **, int *);
    int (*input_byte)(struct bio *, int);
    void (*free_raw)(struct bio *);
    int (*decompress)(struct squashfs_sb_info *, struct bio *, int, int, struct squashfs_page_actor *);
    int (*copy_raw)(struct bio *, struct squashfs_page_actor *, int, int);
    void (*error)(struct fs_context *, const char *, ...);
    int (*print)(const char *, ...);
    void (*dynamic_debug)(struct _ddebug *, const char *, ...);
    void (*fatal)(const char *);
    void * (*memcpy)(void *, const void *, size_t);
    void * (*memset)(void *, int, size_t);
    int (*memcmp)(const void *, const void *, size_t);
    int (*strcmp)(const char *, const char *);
    int (*strncmp)(const char *, const char *, size_t);
    char * (*strncpy)(char *, const char *, size_t);
    size_t (*strlen)(const char *);
    const struct xattr_handler * (*xattr_handler)(int);
    const struct super_operations * super_ops;
    const struct export_operations * export_ops;
    const struct xattr_handler ** xattr_handlers;
    const struct file_operations * ro_fops;
    const struct inode_operations * inode_ops;
    const struct inode_operations * dir_inode_ops;
    const struct file_operations * dir_ops;
    const struct inode_operations * symlink_ops;
    const struct address_space_operations * symlink_aops;
    const struct address_space_operations * aops;
};
extern struct sq_support sq_support;
void sq_bind_support(const struct sq_support *);
struct sq_support *sq_support_address(void);
int squashfs_fill_super(struct super_block *sb, struct fs_context *fc);
int squashfs_read_inode(struct inode *inode, long long ino);
struct dentry *squashfs_lookup(struct inode *dir, struct dentry *dentry,
				 unsigned int flags);
int squashfs_readdir(struct file *file, struct dir_context *ctx);
int read_blocklist(struct inode *inode, int index, u64 *block);
int squashfs_copy_data(void *buffer, struct squashfs_cache_entry *entry,
		int offset, int length);
int squashfs_read_metadata(struct super_block *sb, void *buffer,
		u64 *block, int *offset, int length);
struct squashfs_cache_entry *squashfs_get_fragment(struct super_block *sb,
				u64 start_block, int length);
struct squashfs_cache_entry *squashfs_get_datablock(struct super_block *sb,
				u64 start_block, int length);
void *squashfs_read_table(struct super_block *sb, u64 block, int length);
int squashfs_frag_lookup(struct super_block *sb, unsigned int fragment,
				u64 *fragment_block);
__le64 *squashfs_read_fragment_index_table(struct super_block *sb,
	u64 fragment_table_start, u64 next_table, unsigned int fragments);
int squashfs_get_id(struct super_block *sb, unsigned int index,
					unsigned int *id);
__le64 *squashfs_read_id_index_table(struct super_block *sb,
		u64 id_table_start, u64 next_table, unsigned short no_ids);
__le64 *squashfs_read_inode_lookup_table(struct super_block *sb,
		u64 lookup_table_start, u64 next_table, unsigned int inodes);
int squashfs_xattr_lookup(struct super_block *sb, unsigned int index,
		int *count, unsigned int *size, unsigned long long *xattr);
__le64 *squashfs_read_xattr_id_table(struct super_block *sb, u64 table_start,
		u64 *xattr_table_start, unsigned int *xattr_ids);
int squashfs_read_data(struct super_block *sb, u64 index, int length,
		       u64 *next_index, struct squashfs_page_actor *output);
void *squashfs_decompressor_setup(struct super_block *sb, unsigned short flags);
void *squashfs_xz_comp_opts(struct squashfs_sb_info *msblk,
	void *buff, int len);
void *lz4_comp_opts(struct squashfs_sb_info *msblk,
	void *buff, int len);
ssize_t squashfs_listxattr(struct dentry *d, char *buffer,
	size_t buffer_size);
int squashfs_xattr_get(struct inode *inode, int name_index,
	const char *name, void *buffer, size_t buffer_size);
#endif
